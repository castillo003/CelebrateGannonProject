<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class Approvedproposal extends Model
{
    // public function platformschedule(){

    // 	return this->belongsTo(App\Platformschedule);
    // }

    // public function posterschedule(){

    // 	return this->belongsTo(App\Posterschedule);
    // }

    // public function student(){

    // 	return this->belongsTo(App\Student);
    // }

  }

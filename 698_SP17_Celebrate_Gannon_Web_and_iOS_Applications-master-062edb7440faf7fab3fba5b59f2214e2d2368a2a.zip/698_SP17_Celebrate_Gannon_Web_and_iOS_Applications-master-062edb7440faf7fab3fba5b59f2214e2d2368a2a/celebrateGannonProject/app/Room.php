<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Room extends Model
{
    // public function posterchedule(){

    // 	return this->hasMany(App\Posterschedule);
    // }

    //  public function platformschedule(){

    // 	return this->belongsTo(App\Platformschedule);
    // }
}

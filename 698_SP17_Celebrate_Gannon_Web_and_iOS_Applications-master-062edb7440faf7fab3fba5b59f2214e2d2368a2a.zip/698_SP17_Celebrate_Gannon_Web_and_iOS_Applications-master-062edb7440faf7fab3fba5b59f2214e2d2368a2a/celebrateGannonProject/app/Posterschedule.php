<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\Model;

class Posterschedule extends Model
{
    
	// public function approvedproposal(){

 //    	return this->hasMany(App\Approvedproposal);
 //    }

 //     public function room(){

 //    	return this->belongsTo(App\Room);
 //    }
}

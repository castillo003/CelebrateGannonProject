<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Proposal extends Model
{

	protected $fillable = [
        'id','department_id', 'category_id', 'student_id',
        'title', 'type', 'advisors_names',
        'advisor_email', 'group_member_names', 'file',
        'status', 'notified',
    ];

    // public function category(){

    // 	return this->belongsTo(App\Category);
    // }

    // public function user(){

    // 	return this->belongsTo(App\User);
    // }

    
    // public function student(){

    // 	return this->belongsTo(App\Student);
    // }
    
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Coordinator extends Model
{

    // public function category(){

    // 	return this->belongsToMany(App\Category);
    // }

    // public function proposal(){

    // 	return this->hasMany(App\Proposal);
    // }
    
}

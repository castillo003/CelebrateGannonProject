<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\Model;

class Platformschedule extends Model
{
    

 //    public function room(){

 //    	return this->hasMany(App\Room);
 //    }
    
	// public function approvedproposal(){

 //    	return this->hasMany(App\Approvedproposal);
 //    }

 }

<?php





namespace App\Http\Controllers;

use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\RegistersUsers;

use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers;

use App\posterscoresheet;
use App\platformscoresheet;




use App\Finalgrade;
use App\Approvedproposal;
use App\Category;
use App\Department;
use App\Student;
use App\Posterschedule;

use App\Room;
use App\Proposal;
use App\User;

use Session;




use DB;
use Illuminate\Http\Request;



class ChairmanController extends Controller
{
  public function __construct(){
    $this->middleware('auth');

  }
    public function home(){
    	return view('chairman.chairman');
    }

    public function scores(){
    	 $posterscores = posterscoresheet::all();
    	 $platformscores = platformscoresheet::all();
       $judgesname = user::all();
       $studentname = student::all();
       $categories= category::all();
       $approvedproposals = Approvedproposal::all();

    
    	return view('chairman.scores')->with('posterscores',$posterscores)
                                    ->with('platformscores',$platformscores)
                                    ->with('judgesname',$judgesname)
                                    ->with('studentname',$studentname)
                                    ->with('categories',$categories)
                                    ->with('approvedproposals',$approvedproposals);
    	
    }

    public function manageschedule(){

      return view ('chairman.manageschedule');
    }

  
	public function platformscoresheetsdelete($id){

    	DB::table('platformscoresheets')->where('id','=', $id)->delete();

    	return redirect('chairman\scores');
    	
    }
    public function posterscoresheetsdelete($id){

      DB::table('posterscoresheets')->where('id','=', $id)->delete();

      return redirect('chairman\scores');
      
    }
    

    public function calculatescores(){
DB::table('finalgrades')->truncate();

         $platformstudenttotals = DB::table('platformscoresheets')->select('student_id','total')->get();
                                     

        $platformstudentids = DB::table('platformscoresheets')->select('student_id')
                                                        ->distinct()
                                                        ->get();

        //DB::table('finalgrades')->truncate();

        $studenttotals = DB::table('posterscoresheets')->select('student_id','total')
                                                      ->unionAll(DB::table('platformscoresheets')->select('student_id','total'))->get();
         // dd($studenttotals);

        $studentids = DB::table('posterscoresheets')->select('student_id')
                                                          ->union(DB::table('platformscoresheets')->select('student_id'))
                                                          ->get();
        //dd($posterstudentids);
        //$platformstudenttotals = DB::table('platformscoresheets')->select('student_id','total')->get();

        $posterstudenttotals = DB::table('posterscoresheets')->select('student_id','total')->get();
        $posterstudentids = DB::table('posterscoresheets')->select('student_id')
                                                          ->distinct()
                                                          ->get();

       

        //$platformstudentids = DB::table('platformscoresheets')->select('student_id') ->get();
        //dd($platformstudentids);


      
        // $studenttotals =$posterstudenttotals->union($platformstudenttotals);
        // //dd($studenttotals);
        // $studentids =$platformstudentids->union($posterstudentids);
        // dd($studentids);
       if (count($studenttotals) == 0) {
        DB::table('finalgrades')->truncate();
         
       }

        $approvedproposals= approvedproposal::all();
        $categoryname= category::all();
        $departmentname= department::all();
        $studentname= student::all();

        
    
        foreach ($studentids as $studentid){
            $result=0;
            $judgnumber=0;
        $var= DB::table('finalgrades')->select('student_id','average')->get();
   
        $sidexist=false;
        foreach ($var as $val) {
            if ($val->student_id == $studentid->student_id) {
                foreach ($approvedproposals as $approvedproposal) {
                         DB::table('finalgrades')
                            ->where('student_id', $approvedproposal->student_id)
                            ->update(['department_id' => $approvedproposal->department_id,'category_id' => $approvedproposal->category_id]);
            
        }
              $sidexist=true; 
            }
            
        }

            foreach ($studenttotals as $studenttotal){
                if($studentid->student_id == $studenttotal->student_id ){
                    $result = $result+$studenttotal->total;
                    if ($studenttotal->total != 0) {
                      $judgnumber=$judgnumber+1;
                    }
                    
                }

            }
           

          if ( !$sidexist ) {
            if ($judgnumber != 0) {
            
             DB::table('finalgrades')->insert(['student_id' => $studentid->student_id , 'average' => $result/$judgnumber]);
           }

          }else{
            DB::table('finalgrades')->where('student_id',$studentid->student_id)
                                    ->update(['average'  => $result/$judgnumber]);
                                    
          }
              
          
        
         
 
      
     }
    
     return $this->viewwinners();
   
       
    }


    public function viewwinners(){

$approvedproposals= approvedproposal::all();
        $categoryname= category::all();
        $departmentname= department::all();
        $studentname= student::all();




 $studentscores = DB::table('finalgrades')->select('student_id','average')->orderBy('average', 'desc')->get();
    return view ('chairman.winners')->with('studentscores',$studentscores)
                                    ->with('categoryname',$categoryname)
                                    ->with('departmentname',$departmentname)
                                    ->with('studentname',$studentname)
                                    ->with('approvedproposals',$approvedproposals);


   }

    public function platformschedule(){

        //DB::table('finalgrades')->truncate();
        $approvedplatforms = DB::table('approvedproposals')
            ->leftJoin('proposals', 'approvedproposals.proposal_id', '=', 'proposals.id')
            ->leftJoin('students', 'approvedproposals.proposal_id', '=', 'students.id')
            ->orderBy('proposals.department_id', 'asc')
            ->get();

            $judgesname = user::all();
             $categories= category::all();

        // $platformexist = DB::table('platformSchedule')->select('approvedproposals_id')->get();
    

        $departments = department::all();
       

        $platformschedule = DB::table('platformSchedule')->select('approvedproposals_id','room_code','time','judge_one','judge_two','judge_three')->get();
        return view ('chairman.platformschedule')->with('platformschedule',$platformschedule)
                                                ->with('approvedplatforms',$approvedplatforms)
                                                ->with('departments',$departments)
                                                ->with('judgesname',$judgesname)
                                                ->with('categories',$categories);
    }
    public function platformscheduleedit(){

      $approvedplatforms = DB::table('approvedproposals')
            ->leftJoin('proposals', 'approvedproposals.proposal_id', '=', 'proposals.id')
            ->leftJoin('students', 'approvedproposals.proposal_id', '=', 'students.id')
            ->orderBy('proposals.department_id', 'asc')
            ->get();

            $judgesname = user::all();
             $categories= category::all();

        $departments = department::all();
        $rooms= room::all();
        $judges = DB::table('users')->where('user_type','Judge')->get();
       

        $platformschedule = DB::table('platformSchedule')->select('approvedproposals_id','room_code','time','judge_one','judge_two','judge_three')->get();
        return view ('chairman.platformscheduleedit')->with('platformschedule',$platformschedule)
                                                ->with('approvedplatforms',$approvedplatforms)
                                                ->with('departments',$departments)
                                                ->with('judgesname',$judgesname)
                                                ->with('categories',$categories)
                                                ->with('rooms',$rooms)
                                                ->with('judges',$judges);


    }

    public function platformscheduleeditstore(Request $request){
      DB::table('finalgrades')->truncate();

      
      for ($i=0; $i <count($request->get('approvedproposals_id')) ; $i++) { 
        

        DB::table('platformSchedule')->where('approvedproposals_id',$request->approvedproposals_id[$i])
                                     ->update(['room_code' =>$request->room_code[$i],
                                                'time' => $request->eventtimes_id[$i],
                                                'judge_one' =>$request->judge_onelname[$i],
                                                'judge_two' =>$request->judge_twolname[$i],
                                                'judge_three' =>$request->judge_threelname[$i]]);

          DB::table('platformscoresheets')->where('student_id','=',$request->approvedproposals_id[$i])->delete();

        DB::table('platformscoresheets')->insert([['student_id' => $request->approvedproposals_id[$i],
                                                  'judge_id' =>$request->judge_onelname[$i]],
                                                  ['student_id' => $request->approvedproposals_id[$i],
                                                  'judge_id' =>$request->judge_twolname[$i]],
                                                  ['student_id' => $request->approvedproposals_id[$i],
                                                  'judge_id' =>$request->judge_threelname[$i]]]);


      }
      $fineartproposals=DB::table('platformscoresheets')
       ->leftJoin('proposals', 'platformscoresheets.student_id', '=', 'proposals.id')
       ->select('platformscoresheets.student_id')
       ->where('proposals.category_id',7)->get();

       foreach ($fineartproposals as $fineartproposal) {
        DB::table('platformscoresheets')
                            ->where('student_id', $fineartproposal->student_id)
                            ->update(['fineart' =>  1 ]);
         
       }

     DB::table('finalgrades')->truncate();

      return redirect ('chairman/platformschedule');
    }


    public function posterscheduleedit(){

      $approvedposters = DB::table('approvedproposals')
            ->leftJoin('proposals', 'approvedproposals.proposal_id', '=', 'proposals.id')
            ->leftJoin('students', 'approvedproposals.proposal_id', '=', 'students.id')
            ->orderBy('proposals.department_id', 'asc')
            ->get();

            $judgesname = user::all();
             $categories= category::all();

        $departments = department::all();
        $rooms= room::all();
        $judges = DB::table('users')->where('user_type','Judge')->get();
       

        $posterschedule = DB::table('posterSchedule')->select('approvedproposals_id','room_code','time','judge_one','judge_two','judge_three')->get();
        return view ('chairman.posterscheduleedit')->with('posterschedule',$posterschedule)
                                                ->with('approvedposters',$approvedposters)
                                                ->with('departments',$departments)
                                                ->with('judgesname',$judgesname)
                                                ->with('categories',$categories)
                                                ->with('rooms',$rooms)
                                                ->with('judges',$judges);


    }

    public function posterscheduleeditstore(Request $request){
      
      for ($i=0; $i <count($request->get('approvedproposals_id')) ; $i++) { 
        //print_r($request->approvedproposals_id[$i]);
        //print_r($request->eventtimes_id[$i]);
        
        //dd($request->all());
        //dd($request->all());
        DB::table('posterSchedule')->where('approvedproposals_id',$request->approvedproposals_id[$i])
                                     ->update(['room_code' =>$request->room_code[$i],
                                                'time' => $request->eventtimes_id[$i],
                                                'judge_one' =>$request->judge_onelname[$i],
                                                'judge_two' =>$request->judge_twolname[$i],
                                                'judge_three' =>$request->judge_threelname[$i]]);

        DB::table('posterscoresheets')->where('student_id','=',$request->approvedproposals_id[$i])->delete();
        DB::table('posterscoresheets')->insert([['student_id' => $request->approvedproposals_id[$i],
                                                  'judge_id' =>$request->judge_onelname[$i]],
                                                  ['student_id' => $request->approvedproposals_id[$i],
                                                  'judge_id' =>$request->judge_twolname[$i]],
                                                  ['student_id' => $request->approvedproposals_id[$i],
                                                  'judge_id' =>$request->judge_threelname[$i]]]);

      }
      DB::table('finalgrades')->truncate();
      return redirect ('chairman/posterschedule');
    }

    public function createplatformschedule(){

      $applatforms = DB::table('approvedproposals')
            ->leftJoin('proposals', 'approvedproposals.proposal_id', '=', 'proposals.id')
            ->leftJoin('students', 'approvedproposals.proposal_id', '=', 'students.id')
            ->orderBy('proposals.department_id', 'asc')
            ->get();

        $platformexist = DB::table('platformSchedule')->get();
    

        //$departments = department::all();


         
        $enterd=false;
        foreach ( $applatforms as $applatform) {
        foreach ($platformexist as $k) {
          
        if ($applatform->id == $k->approvedproposals_id){
            $enterd=true;
        }
        
        }
        if(!$enterd){       
        if($applatform->type =='PL')
        DB::table('platformSchedule')->insert(['approvedproposals_id' => $applatform->id ]);


        if($applatform->type =='FA')

        DB::table('platformSchedule')->insert(['approvedproposals_id' => $applatform->id ]);
            
    }




}




       $approvedplatforms = DB::table('platformSchedule')->select('approvedproposals_id')
       ->leftJoin('approvedproposals', 'platformSchedule.approvedproposals_id', '=', 'approvedproposals.proposal_id')
       ->select('platformSchedule.*','approvedproposals.proposal_id','approvedproposals.department_id')
       ->orderBy('approvedproposals.department_id')
       ->whereNull('platformSchedule.room_code')->get();

       // print_r($approvedplatforms);

      //  print("<pre>".print_r($approvedplatforms,true)."</pre>");
     
       $rooms = room::all();

       // $roomcapasity=7;
       // foreach ($rooms as $room) {
       // $count = DB::table('platformSchedule')->pluck('room_code')->where('room_code', $room->room_code)->count();
       
       // $roomcapasity=$roomcapasity - $count;
       
         
       // }


       $departments = department::all();
       $judges=DB::table('users')->select('id','fname','lname')
                                 ->where('user_type','Judge')->get();
                              

       


      return view ('chairman.createplatformschedule',compact('approvedplatforms','rooms','departments','judges'));
    }

    public function store(Request $request)
    {
       //dd($request->all());
      $proposalsid = $request->get('approvedproposals_id');
      $judgesid=$request->get('lname');
      $roomcode=$request->get('room_code');

      //dd($request->get('room_code'));

      for ($j=0; $j <count($proposalsid) ; $j++) {

        for ($i=0; $i <count($judgesid) ; $i++) { 
          if (count($judgesid) == 1){
          DB::table('platformSchedule')
                            ->where('approvedproposals_id', $proposalsid[$j])
                            ->update(['judge_one' => $judgesid[$i]]);
          DB::table('platformscoresheets')->insert(['student_id' => $proposalsid[$j],'judge_id' => $judgesid[$i] ]);

                            break;
                          }
          if (count($judgesid) == 2) {
            DB::table('platformSchedule')
                            ->where('approvedproposals_id', $proposalsid[$j])
                            ->update(['judge_one' => $judgesid[$i],'judge_two' => $judgesid[$i+1] ]);
                  $k=0;
                while ( $k < 2) {
                  
            DB::table('platformscoresheets')->insert(['student_id' => $proposalsid[$j],'judge_id' => $judgesid[$k] ]);
                  $k=$k+1;

                }
                            break;
          }
          if (count($judgesid) == 3) {
            DB::table('platformSchedule')
                            ->where('approvedproposals_id', $proposalsid[$j])
                            ->update(['judge_one' => $judgesid[$i],'judge_two' => $judgesid[$i+1],'judge_three' => $judgesid[$i+2]]);

                  $k=0;
                while ( $k < 3) {
                  
            DB::table('platformscoresheets')->insert(['student_id' => $proposalsid[$j],'judge_id' => $judgesid[$k] ]);
                  $k=$k+1;

                }
                            break;
          }

          
        }
        DB::table('platformSchedule')
                            ->where('approvedproposals_id', $proposalsid[$j])
                            ->update(['room_code' =>  $request->get('room_code') ]);


        
      }

      $fineartproposals=DB::table('platformscoresheets')
       ->leftJoin('proposals', 'platformscoresheets.student_id', '=', 'proposals.id')
       ->select('platformscoresheets.student_id')
       ->where('proposals.category_id',7)->get();

       foreach ($fineartproposals as $fineartproposal) {
        DB::table('platformscoresheets')
                            ->where('student_id', $fineartproposal->student_id)
                            ->update(['fineart' =>  1 ]);
         
       }
      
      return redirect('chairman\platformschedule');

    }

    public function posterschedule(){

        $approvedposters = DB::table('approvedproposals')
            ->leftJoin('proposals', 'approvedproposals.proposal_id', '=', 'proposals.id')
            ->leftJoin('students', 'approvedproposals.proposal_id', '=', 'students.id')
            ->orderBy('proposals.department_id', 'asc')
            ->get();

        $judgesname = user::all();
        $categories= category::all();

       

        $departments = department::all();



        $posterschedule = DB::table('posterSchedule')->select('approvedproposals_id','room_code','eventtimes_id','time','judge_one','judge_two','judge_three')->whereNotNull('room_code')->get();
        return view ('chairman.posterschedule')->with('posterschedule',$posterschedule)
                                                ->with('approvedposters',$approvedposters)
                                                ->with('departments',$departments)
                                                ->with('judgesname',$judgesname)
                                                ->with('categories',$categories);
    }
    public function createposterschedule(){

      $apposters = DB::table('approvedproposals')
            ->leftJoin('proposals', 'approvedproposals.proposal_id', '=', 'proposals.id')
            ->leftJoin('students', 'approvedproposals.proposal_id', '=', 'students.id')
            ->orderBy('proposals.department_id', 'asc')
            ->get();

        $platformexist = DB::table('posterSchedule')->get();
       // $platformexist = posterSchedule::all();
    

        //$departments = department::all();


         
        $enterd=false;
        foreach ( $apposters as $apposter) {
        foreach ($platformexist as $k) {
          
        if ($apposter->id == $k->approvedproposals_id){
            $enterd=true;
        }
        
        }
        if(!$enterd){       
        if($apposter->type =='PO')
        DB::table('posterSchedule')->insert(['approvedproposals_id' => $apposter->id ]);
            
    }


}




       $approvedposters = DB::table('posterSchedule')->select('approvedproposals_id')
       ->leftJoin('approvedproposals', 'posterSchedule.approvedproposals_id', '=', 'approvedproposals.proposal_id')
       ->select('posterSchedule.*','approvedproposals.proposal_id','approvedproposals.department_id')
       ->orderBy('approvedproposals.department_id')
       ->whereNull('posterSchedule.room_code')->get();

     
       $rooms = room::all();


       $departments = department::all();
       $judges=DB::table('users')->select('id','fname','lname')
                                 ->where('user_type','Judge')->get();
                              

       


      return view ('chairman.createposterschedule',compact('approvedposters','rooms','departments','judges'));
    }

    public function storeposter(Request $request)
    {
      $proposalsid = $request->get('approvedproposals_id');
      $judgesid=$request->get('lname');
      $roomcode=$request->get('room_code');

      //dd($request->get('room_code'));

      for ($j=0; $j <count($proposalsid) ; $j++) {

        for ($i=0; $i <count($judgesid) ; $i++) { 
          if (count($judgesid) == 1){
          DB::table('posterSchedule')
                            ->where('approvedproposals_id', $proposalsid[$j])
                            ->update(['judge_one' => $judgesid[$i]]);
          DB::table('posterscoresheets')->insert(['student_id' => $proposalsid[$j],'judge_id' => $judgesid[$i] ]);

                            break;
                          }
          if (count($judgesid) == 2) {
            DB::table('posterSchedule')
                            ->where('approvedproposals_id', $proposalsid[$j])
                            ->update(['judge_one' => $judgesid[$i],'judge_two' => $judgesid[$i+1] ]);
                  $k=0;
                while ( $k < 2) {
                  
            DB::table('posterscoresheets')->insert(['student_id' => $proposalsid[$j],'judge_id' => $judgesid[$k] ]);
                  $k=$k+1;

                }
                            break;
          }
          if (count($judgesid) == 3) {
            DB::table('posterSchedule')
                            ->where('approvedproposals_id', $proposalsid[$j])
                            ->update(['judge_one' => $judgesid[$i],'judge_two' => $judgesid[$i+1],'judge_three' => $judgesid[$i+2]]);

                  $k=0;
                while ( $k < 3) {
                  
            DB::table('posterscoresheets')->insert(['student_id' => $proposalsid[$j],'judge_id' => $judgesid[$k] ]);
                  $k=$k+1;

                }
                            break;
          }

          
        }
        DB::table('posterSchedule')
                            ->where('approvedproposals_id', $proposalsid[$j])
                            ->update(['room_code' =>  $request->get('room_code') ]);


        
      }
      
      return redirect('chairman\posterschedule');

    }

    public function posterscoresheetsview($id){
      $posterscores =  DB::table('posterscoresheets')->where('id', $id)->get();
       $judgesname = user::all();
       $studentname = student::all();
       $categories= category::all();
       $approvedproposals = Approvedproposal::all();

      return view ('chairman.posterscoresheetsview')->with('posterscores',$posterscores)
                                                    ->with('judgesname',$judgesname)
                                                    ->with('studentname',$studentname)
                                                    ->with('categories',$categories)
                                                    ->with('approvedproposals',$approvedproposals);


    }

      public function platformscoresheetsview($id){
      $platformscores =  DB::table('platformscoresheets')->where('id', $id)->get();
       $judgesname = user::all();
       $studentname = student::all();
       $categories= category::all();
       $approvedproposals = Approvedproposal::all();

      return view ('chairman.platformscoresheetsview')->with('platformscores',$platformscores)
                                                    ->with('judgesname',$judgesname)
                                                    ->with('studentname',$studentname)
                                                    ->with('categories',$categories)
                                                    ->with('approvedproposals',$approvedproposals);


    }

    public function posterscoresheetsedit($id){

      $posterscores =  DB::table('posterscoresheets')->where('id', $id)->get();
       $judgesname = user::all();
       $studentname = student::all();

      return view ('chairman.posterscoresheetsedit')->with('posterscores',$posterscores)
                                                    ->with('judgesname',$judgesname)
                                                    ->with('studentname',$studentname);

    }

    public function editposterstore(Request $request){

      $this->validate($request,[
                'criteria_one' => 'required|integer|min:0',
                'criteria_two' => 'required|integer|min:0',
                'criteria_three' => 'required|integer|min:0',
                'criteria_four' => 'required|integer|min:0',
                'criteria_five' => 'required|integer|min:0',
                'criteria_six' => 'required|integer|min:0',
                

             ],[
                'criteria_one.integer' => ' The value should be numbers',
                'criteria_one.min' => ' The value should be positive numbers',
                'criteria_two.integer' => ' The value should be numbers',
                'criteria_two.min' => ' The value should be positive numbers',
                'criteria_three.integer' => ' The value should be numbers',
                'criteria_three.min' => ' The value should be positive numbers',
                'criteria_four.integer' => ' The value should be numbers',
                'criteria_four.min' => ' The value should be positive numbers',
                'criteria_five.integer' => ' The value should be numbers',
                'criteria_five.min' => ' The value should be positive numbers',
                'criteria_six.integer' => ' The value should be numbers',
                'criteria_six.min' => ' The value should be positive numbers',
               
                
          ]);

      
     DB::table('posterscoresheets')
                            ->where('id', $request->get('id'))
                            ->update(['criteria_one' => $request->get('criteria_one'),
                                      'criteria_two' => $request->get('criteria_two'),
                                      'criteria_three' => $request->get('criteria_three'),
                                      'criteria_four' => $request->get('criteria_four'),
                                      'criteria_five' => $request->get('criteria_five'),
                                      'experience' => $request->get('experience'),
                                      'criteria_six' => $request->get('criteria_six')]);

    $total = $request->get('criteria_one') + $request->get('criteria_two')+$request->get('criteria_three')+$request->get('criteria_four')+$request->get('criteria_five')+ $request->get('criteria_six');

       DB::table('posterscoresheets')
                            ->where('id', $request->get('id'))
                            ->update(['total' => $total]);
      return redirect('chairman\scores');

    }


     public function platformscoresheetsedit($id){

      $platformscores =  DB::table('platformscoresheets')->where('id', $id)->get();
       $judgesname = user::all();
       $studentname = student::all();

      return view ('chairman.platformscoresheetsedit')->with('platformscores',$platformscores)
                                                    ->with('judgesname',$judgesname)
                                                    ->with('studentname',$studentname);

    }

    public function editplatformstore(Request $request){
      //dd($request->all());

      $this->validate($request,[
                'criteria_one' => 'required|integer|min:0',
                'criteria_two' => 'required|integer|min:0',
                'criteria_three' => 'required|integer|min:0',
                'criteria_four' => 'required|integer|min:0',
                'criteria_five' => 'required|integer|min:0',
                'criteria_six' => 'required|integer|min:0',
                'criteria_seven' => 'required|integer|min:0',

             ],[
                'criteria_one.integer' => ' The value should be numbers',
                'criteria_one.min' => ' The value should be positive numbers',
                'criteria_two.integer' => ' The value should be numbers',
                'criteria_two.min' => ' The value should be positive numbers',
                'criteria_three.integer' => ' The value should be numbers',
                'criteria_three.min' => ' The value should be positive numbers',
                'criteria_four.integer' => ' The value should be numbers',
                'criteria_four.min' => ' The value should be positive numbers',
                'criteria_five.integer' => ' The value should be numbers',
                'criteria_five.min' => ' The value should be positive numbers',
                'criteria_six.integer' => ' The value should be numbers',
                'criteria_six.min' => ' The value should be positive numbers',
                'criteria_seven.integer' => ' The value should be numbers',
                'criteria_seven.min' => ' The value should be positive numbers',
                
          ]);


      
     DB::table('platformscoresheets')
                            ->where('id', $request->get('id'))
                            ->update(['criteria_one' => $request->get('criteria_one'),
                                      'criteria_two' => $request->get('criteria_two'),
                                      'criteria_three' => $request->get('criteria_three'),
                                      'criteria_four' => $request->get('criteria_four'),
                                      'criteria_five' => $request->get('criteria_five'),
                                      'criteria_six' => $request->get('criteria_six'),
                                      'experience' => $request->get('experience'),
                                      'criteria_seven' => $request->get('criteria_seven')]);

    $total = $request->get('criteria_one') + $request->get('criteria_two')+$request->get('criteria_three')+$request->get('criteria_four')+$request->get('criteria_five')+ $request->get('criteria_six')+$request->get('criteria_seven');

       DB::table('platformscoresheets')
                            ->where('id', $request->get('id'))
                            ->update(['total' => $total]);
      return redirect('chairman\scores');

    }
    public function judges(){
      $users = user::all();
      return view('chairman.users')->with('users',$users);
    }
    public function approve($id){
       $approveed = user::find($id);

       Session::flash('approve_message','Done. user: '."$approveed->lname".' has been approveed');

      DB::table('users')->where('id',$id)
                        ->update(['status'=>1]);
       


        return redirect('chairman/judges');

    }
    public function reject($id){
      $rejected = user::find($id);
      Session::flash('reject_message','Done. user: '."$rejected->lname".' has been rejected');

      
      DB::table('users')->where('id',$id)
                        ->update(['status'=>0]);

        return redirect('chairman/judges');

    }

    public function manageusers(){
      

        return view ('chairman.manageusers');

    }

     public function coordinators(){
      $users = user::all();
      //$categories= category::all();

      $categorycoordinators = DB::table('category_coordinator')->get();
      $users = user::all();

      $categories= category::all();

      return view('chairman.coordinators')->with('users',$users)->with('categorycoordinators',$categorycoordinators)->with('categories',$categories);
    }

    public function coordinatorview($id){

      $id=$id;

      $coordinator = DB::table('category_coordinator')->where('coordinator_id',$id)->get();
      $users = user::all();

      $categories= category::all();


      return view('chairman.viewcoordinator')->with('id',$id)->with('coordinator',$coordinator)->with('users',$users)->with('categories',$categories);

    }

     public function create(Request $request)
    {   
      //dd($request->all());

        DB::table('users')->insert(['fname'=>$request->fname,
                                    'lname'=>$request->lname,
                                    'email'=>$request->email,
                                    'password'=>bcrypt($request->password),
                                    'appPass'=>sha1($request->password),
                                    'user_type'=> 'Coordinator']);

        return redirect ('chairman/coordinators');
       
    }

    public function assigncategory()
    {
       $users = user::all();

      $categories= category::all();

      return view('chairman.assigncategory')->with('users',$users)->with('categories',$categories);
    }

    public function assign(Request $request){
      //dd($request->get('coordinators'));
      $coordinatorsnum = count($request->get('coordinators'));
      $categoriesnum=count($request->get('categories'));
      if ($coordinatorsnum > $coordinatorsnum ){ 
      for ($i=0; $i <count($request->get('coordinators')) ; $i++) { 
        for ($j=0; $j <count($request->get('categories')) ; $j++) { 
          DB::table('category_coordinator')->insert(['coordinator_id'=>$request->coordinators[$i],
                                                      'category_id'=>$request->categories[$j]]);
        }
          
      }
    }else{

      for ($i=0; $i <count($request->get('categories')) ; $i++) { 
          for ($j=0; $j <count($request->get('coordinators')) ; $j++) { 
          DB::table('category_coordinator')->insert(['coordinator_id'=>$request->coordinators[$j],
                                                      'category_id'=>$request->categories[$i]]);
        }
      }


    }


      return redirect ('chairman/coordinators');
    }

    public function coordinatorsdelete($id){
      DB::table('category_coordinator')->where('coordinator_id',$id)->delete();
      DB::table('users')->where('id',$id)->delete();

      return redirect('chairman/coordinators');


    }


    
}

<?php

namespace App\Http\Controllers;
use Illuminate\Http\UploadedFile;
use App\Mobile;
//use Illuminate\Http\Request;
use App\Student;
use App\Category;
use App\Department;
use Illuminate\Http\Request;
use DB;
use Illuminate\Foundation\Auth\RegistersUsers;
//use Illuminate\Support\Facades\Validator;

class StudentController extends Controller
{
    var $uniId;


    public function index(){

    	$students = Student::all();
        


    	//return $categories;

    	return view('students.index')->with('students', $students);
    	//return view('categories.index', compact('categories'));

    }



    public function create(){

        $categories = Category::all();
        $departments =  Department::all();

    	return view('students/create')->with('categories', $categories)
                                     ->with('departments', $departments);
    }



    public function validation(Request $request)
    {
        $this->validate($request,[
                'name' => 'required|min:3|max:35',
                'email' => 'required|email|max:255|unique:students',
                'universityId' => 'required|min:7|numeric|unique:students',
         ],[
                'universityId.numeric' => ' This university ID should be numbers ',
                'universityId.unique' => ' This university ID has been taken ',
            ]);

        return $this->store($request);

        // dd('You are successfully added all fields.');
}


    public function store(Request $request){

        $uniId = $request->universityId;

        DB::table('students')->insert(['name' => $request->name , 'email' => $request->email , 'universityId' => $request->universityId]);

       return $this->createPr($uniId);


    }


        public function createPr($uniId){

       // echo $uniId;

        $categories = Category::all();
        $departments =  Department::all();
        $students =  Student::all()->where('universityId', $uniId);

        

        return view('students.createPrpopsal')->with('categories', $categories)
                                              ->with('departments', $departments)
                                              ->with('students', $students);
    }



    public function delete($id){

       // $uniId = $request->universityId;
       // global $newVar;
        // $id = $request->st_id;

        $student= Student::find($id);

         $student->delete();

       // DB::table('students')->delete()->where('id', $id);

       return view('welcome');


        //return redirect('students/{$uniId}/createPr');

    }

// public function validationPr(Request $request)
//     {
//         //dd("yaaaaaaaao");

//         $this->validate($request,[
//                 'dep_name' => 'required',
//                 'cat_name' => 'required',
//                 'title' => 'required',
//                 'type' => 'required',
//                 'advisor' => 'required',
//                 'email' => 'required|email',
//                 'Gr_mem_name' => 'required',
//                 'file' => 'required'
//             ]);

//         return $this->storePr($request);

//         // dd('You are successfully added all fields.');
// }


        public function storePr(Request $request)
        {

         
            $file = $request->file('file');
            $fileName = $request->st_id.$file->getClientOriginalName();
            //echo "$file";
            //echo "$fileName";


             $request->file('file')->move(base_path().'/storage/app/files/',$fileName);


        DB::table('proposals')->insert(['id' => $request->st_id,'department_id' => $request->dep_name, 
                                        'category_id' => $request->cat_name, 
                                        'student_id' => $request->st_id, 'title' => $request->title,
                                        'type' => $request->type, 'advisors_names' => $request->advisor,
                                        'advisor_email' => $request->ad_email,'group_member_names' => $request->Gr_mem_name, 
                                        'file' => $fileName, 'status' => "NR" , 'notified' => 0]);

        return view('thanks');

    }

}

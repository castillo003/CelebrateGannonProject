<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Room;
use DB;

class RoomCoordinatorController extends Controller
{
     public function home(){
     	$rooms = room::all();
    	return view('roomcoordinator.roomcoordinator')->with('rooms',$rooms);
    }

    public function addroom(Request $request){


    	
    	 DB::table('rooms')->insert(['room_code' => $request->get('room_code')]);
    	 return redirect('roomcoordinator');
    }

    public function deleteroom($id){



    	DB::table('rooms')->where('id','=', $id)->delete();

     return redirect('roomcoordinator');
    }

    public function editroom( $id){

    	$room = DB::table('rooms')->where('id',$id)->get();


    

     return view('roomcoordinator.editroom')->with('room',$room);
    }
    public function updateroom(Request $request){

    	
    	DB::table('rooms')->where('id',$request->get('id'))
    					  ->update(['room_code' => $request->get('room_code')]);
    	return redirect('roomcoordinator');


    }



}

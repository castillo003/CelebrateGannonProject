<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Student;
use App\Proposal;

use App\User;

use App\platformscoresheet;
use DB;

use App\posterscoresheet;


class JudgeController extends Controller
{
    

     public function index(){


        $user = Auth::user();
     	$platformscoresheets = platformscoresheet::all()->where('judge_id', $user->id);
     	$posterscoresheets = posterscoresheet::all()->where('judge_id', $user->id);
        $students = Student::all();
       // $users = User::all();
        $proposals = Proposal::all(); 

        $plSchedule = DB::table('platformSchedule')->select()->get();

        $poSchedule = DB::table('posterSchedule')->select()->get();
    
        return view('judge.judge')->with('platformscoresheets',$platformscoresheets)
                                ->with('posterscoresheets',$posterscoresheets)
                                ->with('students',$students)
                                ->with('proposals', $proposals)
                                ->with('plSchedule', $plSchedule)
                                ->with('poSchedule', $poSchedule);
    	//return view('judge.judge');
    }


}

<?php
use App\Mail\approvedmail;

use Illuminate\Http\UploadedFile;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


use App\Mobile;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('chairman', 'ChairmanController@home');
Route::get('chairman/scores', 'ChairmanController@scores');
Route::get('chairman/calculatescores', 'ChairmanController@calculatescores');

Route::get('chairman/platformschedule', 'ChairmanController@platformschedule');
Route::get('chairman/posterschedule', 'ChairmanController@posterschedule');
Route::get('chairman/createplatformschedule', 'ChairmanController@createplatformschedule');
Route::get('chairman/createposterschedule', 'ChairmanController@createposterschedule');
Route::get('chairman/judges', 'ChairmanController@judges');
Route::get('chairman/coordinators', 'ChairmanController@coordinators');
Route::post('chairman/addcoordinator', 'ChairmanController@create');


Route::get('chairman/assigncategory', 'ChairmanController@assigncategory');

Route::post('chairman/assign', 'ChairmanController@assign');

Route::get('chairman/manageusers', 'ChairmanController@manageusers');

Route::get('chairman/manageschedule', 'ChairmanController@manageschedule');

Route::get('chairman/platformscheduleedit', 'ChairmanController@platformscheduleedit');
Route::post('chairman/platformscheduleedit', 'ChairmanController@platformscheduleeditstore');



Route::get('chairman/posterscheduleedit', 'ChairmanController@posterscheduleedit');
Route::post('chairman/posterscheduleedit', 'ChairmanController@posterscheduleeditstore');


Route::post('chairman', 'ChairmanController@store');


Route::post('chairman/createposterschedule', 'ChairmanController@storeposter');
Route::get('chairman/coordinatorsview/{id}', 'ChairmanController@coordinatorview');
Route::get('chairman/coordinatorsdelete/{id}', 'ChairmanController@coordinatorsdelete');


Route::get('chairman/{id}/approve', 'ChairmanController@approve');
Route::get('chairman/{id}/reject', 'ChairmanController@reject');

Route::get('chairman/{id}/posterscoresheetsview', 'ChairmanController@posterscoresheetsview');
Route::get('chairman/{id}/posterscoresheetsdelete', 'ChairmanController@posterscoresheetsdelete');

Route::get('chairman/{id}/posterscoresheetsedit', 'ChairmanController@posterscoresheetsedit');
Route::post('chairman/scores', 'ChairmanController@editposterstore');


Route::get('chairman/{id}/platformscoresheetsdelete', 'ChairmanController@platformscoresheetsdelete');
Route::get('chairman/{id}/platformscoresheetsview', 'ChairmanController@platformscoresheetsview');

Route::get('chairman/{id}/platformscoresheetsedit', 'ChairmanController@platformscoresheetsedit');
Route::post('chairman/editplatformstore', 'ChairmanController@editplatformstore');



Route::get('coordinator', 'CoordinatorController@index');
Route::get('roomcoordinator', 'RoomCoordinatorController@home');
Route::post('roomcoordinator/addroom', 'RoomCoordinatorController@addroom');
Route::get('roomcoordinator/{id}/deleteroom', 'RoomCoordinatorController@deleteroom');
Route::get('roomcoordinator/{id}/editroom', 'RoomCoordinatorController@editroom');
Route::post('roomcoordinator/updateroom', 'RoomCoordinatorController@updateroom');





Route::get('student', 'StudentController@home');
Route::get('coordinator/{id}/reject', 'CoordinatorController@reject');
Route::get('coordinator/{id}/approve', 'CoordinatorController@approve');



Auth::routes();

Route::get('/home', 'HomeController@index');

//Categories::routes();
Route::get('/categories/index', 'CategoriesController@index');
Route::get('/categories/create', 'CategoriesController@create');
Route::get('/categories/{id}', 'CategoriesController@show');
Route::post('/categories', 'CategoriesController@store');


Route::get('/departments/index', 'DepartmentController@index');
Route::get('/departments/create', 'DepartmentController@create');
Route::post('/departments', 'DepartmentController@store');


Route::get('/students/index', 'StudentController@index');
Route::get('/students/create', 'StudentController@create');
Route::post('/students', 'StudentController@store');



Route::get('/platformScoreSheets/index', 'PlatformScoreSheetController@index');
Route::get('/platformScoreSheets/{id}/evaluate', 'PlatformScoreSheetController@evaluate');
Route::post('/platformScoreSheets/{id}/update', 'PlatformScoreSheetController@update');
Route::get('/platformScoreSheets/{id}/edit', 'PlatformScoreSheetController@edit');
Route::post('/platformScoreSheets/{id}/storeEdit', 'PlatformScoreSheetController@storeEdit');

Route::get('/posterScoreSheets/index', 'PosterScoreSheetController@index');
Route::get('/posterScoreSheets/{id}/evaluate', 'PosterScoreSheetController@evaluate');
Route::post('/posterScoreSheets/{id}/update', 'PosterScoreSheetController@update');
Route::get('/posterScoreSheets/{id}/edit', 'PosterScoreSheetController@edit');
Route::post('/posterScoreSheets/{id}/storeEdit', 'PosterScoreSheetController@storeEdit');

Route::get('/judge', 'JudgeController@index');



Route::get('/students/index', 'StudentController@index');

Route::get('/students/create', 'StudentController@create');
Route::post('/students/store', 'StudentController@validation');
Route::get('/students/{st_id}/delete', 'StudentController@delete');

Route::get('/students/{$uniId}/createPr', 'StudentController@createPr');
Route::post('/students/storepr', 'StudentController@storePr');


Route::post('files',function(Request $request){
       

    $imageName = "1.".$request->file('image')->getClientOriginalExtension();

    $request->file('image')->move(base_path().'/storage/app/files/',$imageName);

    return redirect('students/index');
   });


Route::get('{id}','CoordinatorController@download');

Auth::routes();

Route::get('/home', 'HomeController@index');

Auth::routes();

Route::get('/home', 'HomeController@index');

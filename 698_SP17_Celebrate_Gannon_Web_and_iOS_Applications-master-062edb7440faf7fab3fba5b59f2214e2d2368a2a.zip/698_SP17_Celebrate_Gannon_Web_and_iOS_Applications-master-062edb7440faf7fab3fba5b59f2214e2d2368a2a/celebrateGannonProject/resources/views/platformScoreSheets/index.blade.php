@extends('layouts.app')

@section('content')
<div class="container">

<h3 align="center"> Platforms Schedule </h3>

 <div class="table-responsive">          
<table class="table ">
  <thead>
   
    <tr>
      <th>Student Name</th>
      <th>Title</th>
      <th>Room</th>
      <th>Time</th>
      <th>Total</th>
      
    </tr>
  </thead>
    @foreach ( $platformscoresheets as $platformscoresheet )

  <tbody>

    <tr>
      @foreach ($students as $student)
      @if ($platformscoresheet->student_id == $student->id )
      
      <td>{{$student->name}}</td>
      @endif
      @endforeach
    

      @foreach ($proposals as $proposal)
      @if ($platformscoresheet->student_id == $proposal->student_id )
      
      <td>{{$proposal->title}}</td>
      @endif
      @endforeach

      @foreach ($plSchedule as $plSchedules)
      @if ($platformscoresheet->student_id == $plSchedules->approvedproposals_id )
      
      <td>{{$plSchedules->room_code}}</td>

      @endif
      @endforeach


      @foreach ($plSchedule as $plSchedules)
      @if ($platformscoresheet->student_id == $plSchedules->approvedproposals_id )
      
      <td>{{$plSchedules->time}}</td>
      @endif
      @endforeach

      <td>{{$platformscoresheet->total}}</td>
      <td> 

    

     <a href="{{$platformscoresheet->id}}\evaluate" class="btn btn-primary " role="button">Evaluate</a>
   <!--     <button type="button" class="btn btn-default"><a href="{{$platformscoresheet->id}}\edit">edit</a>
      </button> -->

    </td>

    </tr>

  </tbody>
  @endforeach

</table>
</div>
</div>

<script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);
        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>

@endsection

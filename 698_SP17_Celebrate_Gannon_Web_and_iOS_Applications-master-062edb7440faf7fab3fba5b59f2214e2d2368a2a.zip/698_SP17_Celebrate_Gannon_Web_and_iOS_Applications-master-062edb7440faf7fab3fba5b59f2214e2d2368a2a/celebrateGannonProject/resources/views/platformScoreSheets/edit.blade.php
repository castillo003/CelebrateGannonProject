@extends('layouts.app')

@section('content')

<div class="container">

<p class="h3">Student Name: </p>{{ $studentName }}

<p class="h3">Propsal title: </p>  @foreach ($proposals as $proposal)
                                  @if ($platformscoresheets->student_id == $proposal->student_id )
      
                                      {{$proposal->title}}
                                  @endif
                                   @endforeach

</div>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Platform Rubric</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="/platformScoreSheets/{{$platformscoresheets->id}}/storeEdit">
                        {{ csrf_field() }}

                        
                        <h4> ORGANIZATION </h4>

                        <div class="container">
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Presentation is clear, logical and organized. 
                                              2- Listener can follow the line of reasoning."> Sophisticated (5)</a>

                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Presentation is generally clear and well organized. 
                                              2- A few minor points may be confusing."> Competent (3)</a>
                                             

                                             
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Listener can follow presentation only with effort. 
                                              2- Some arguments are not clear. 
                                              3- Organization seems haphazard."> Not Yet Competent (1)</a>
                        </div>



                        <div class="form-group{{ $errors->has('criteria_one') ? ' has-error' : '' }}">

                            <div class="col-md-4">

                                <div class="radio">
                                      <label><input type="radio" name="criteria_one" id="criteria_one" value="1" required> 1 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_one" id="criteria_one" value="2"> 2 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_one" id="criteria_one" value="3"> 3 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_one" id="criteria_one" value="4"> 4 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_one" id="criteria_one" value="5"> 5 </label>
                                </div>
                            

                            </div>
                        </div>


                        <h4> STYLE </h4>

                        <div class="container">
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Level of presentation is appropriate for the audience. 
                                              2- Presentation is a planned conversation, paced for audience understanding. It is not a reading of a paper. 
                                              3- Speaker is clearly comfortable in front of the group and can be heard by all."> Sophisticated (5)</a>

                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Level of presentation is generally appropriate. Pacing is sometimes too 
                                              fast or slow. 
                                              2- The presenter seems slightly uncomfortable at times, and the audience occasionally has trouble hearing him/her."> Competent (3)</a>
                                             

                                             
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Aspects of presentation are too elementary or too sophisticated for audience.
                                              2- Presenter seems uncomfortable and can be heard only if listener is very attentive. 
                                              3- Much of the information is read."> Not Yet Competent (1)</a>
                        </div>



                        <div class="form-group{{ $errors->has('criteria_two') ? ' has-error' : '' }}">

                            <div class="col-md-4">

                                <div class="radio">
                                      <label><input type="radio" name="criteria_two" id="criteria_two" value="1" required> 1 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_two" id="criteria_two" value="2"> 2 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_two" id="criteria_two" value="3"> 3 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_two" id="criteria_two" value="4"> 4 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_two" id="criteria_two" value="5"> 5 </label>
                                </div>
                            

                            </div>
                        </div>



                         <h4> USE OF COMMUNICATION AIDS </h4>

                        <div class="container">
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Communication aids enhance the presentation. They are prepared in a professional manner. 2- Font on visuals is large enough to be seen by all. 3- Information is organized to maximize audience understanding. 4- Details are minimized so that the main points stand out."> Sophisticated (5)</a>

                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Communication aids contribute to the quality of the presentation. 2- Font size is appropriate for reading. 3- Appropriate information is included. 4- Some material is not supported by visual aids."> Competent (3)</a>
                                             

                                             
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Communication aids are poorly prepared or used inappropriately. Font is too small to be easily seen. Too much information is included. Unimportant material is highlighted. Listeners may be confused."> Not Yet Competent (1)</a>
                        </div>



                        <div class="form-group{{ $errors->has('criteria_three') ? ' has-error' : '' }}">

                            <div class="col-md-4">

                                <div class="radio">
                                      <label><input type="radio" name="criteria_three" id="criteria_three" value="1" required> 1 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_three" id="criteria_three" value="2"> 2 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_three" id="criteria_three" value="3"> 3 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_three" id="criteria_three" value="4"> 4 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_three" id="criteria_three" value="5"> 5 </label>
                                </div>
                            

                            </div>
                        </div>



                        <h4> DEPTH OF CONTENT </h4>

                        <div class="container">
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Speaker provides an accurate and complete explanation of key concepts and theories, drawing upon the relevant literature. 2- Applications of theory are included to illuminate issues. 3- Listeners gain insight."> Sophisticated (5)</a>

                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- For the most part, explanations of concepts and theories are accurate and complete. 2- Some helpful applications are included."> Competent (3)</a>
                                             

                                             
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Explanations of concepts and/or theories are inaccurate or incomplete. 2- Little attempt is made to tie theory to practice. 3- Listeners gain little from the presentation."> Not Yet Competent (1)</a>
                        </div>



                        <div class="form-group{{ $errors->has('criteria_four') ? ' has-error' : '' }}">

                            <div class="col-md-4">

                                <div class="radio">
                                      <label><input type="radio" name="criteria_four" id="criteria_four" value="1" required> 1 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_four" id="criteria_four" value="2"> 2 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_four" id="criteria_four" value="3"> 3 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_four" id="criteria_four" value="4"> 4 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_four" id="criteria_four" value="5"> 5 </label>
                                </div>
                            

                            </div>
                        </div>

   

                        <h4> GRAMMAR AND WORD CHOICE </h4>

                        <div class="container">
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Sentences are complete, grammatically correct and flow together easily. 2- Words are chosen for their precise meaning."> Sophisticated (5)</a>

                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- For the most part, sentences are complete, grammatically correct and flow together easily. 2- With a few exceptions, words are chosen for their precise meaning."> Competent (3)</a>
                                             

                                             
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Listeners can follow the presentation, but they are distracted by some grammatical errors and use of slang. 2- Some sentences are incomplete/halting/, and/or vocabulary is somewhat limited or inappropriate."> Not Yet Competent (1)</a>
                        </div>



                        <div class="form-group{{ $errors->has('criteria_five') ? ' has-error' : '' }}">

                            <div class="col-md-4">

                                <div class="radio">
                                      <label><input type="radio" name="criteria_five" id="criteria_five" value="1" required> 1 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_five" id="criteria_five" value="2"> 2 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_five" id="criteria_five" value="3"> 3 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_five" id="criteria_five" value="4"> 4 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_five" id="criteria_five" value="5"> 5 </label>
                                </div>
                            

                            </div>
                        </div>


                        <h4> PROFESSIONALISM </h4>

                        <div class="container">
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="Conduct and mannerisms are appropriate for the occasion and the audience."> Sophisticated (5)</a>

                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Conduct and mannerisms are appropriate for the occasion and audience. 2- However, some aspects of conduct reflect a lack of sensitivity to nuances of the occasion or expectations of the audience."> Competent (3)</a>
                                             

                                             
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="Conduct and mannerisms are inappropriate for the occasion and audience."> Not Yet Competent (1)</a>
                        </div>



                        <div class="form-group{{ $errors->has('criteria_six') ? ' has-error' : '' }}">

                            <div class="col-md-4">

                                <div class="radio">
                                      <label><input type="radio" name="criteria_six" id="criteria_six" value="1" required> 1 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_six" id="criteria_six" value="2"> 2 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_six" id="criteria_six" value="3"> 3 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_six" id="criteria_six" value="4"> 4 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_six" id="criteria_six" value="5"> 5 </label>
                                </div>
                            

                            </div>
                        </div>

            

                        <h4> VERBAL INTERACTION </h4>

                        <div class="container">
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Consistently clarifies, restates, and responds to questions. 2- Summarizes when needed."> Sophisticated (5)</a>

                                <a href="#" data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="1- Generally responds to audience comments, questions and needs. 2- Misses some opportunities for interaction."> Competent (3)</a>
                                             

                                             
                                <a data-toggle="Popover" data-placement="bottom" title="Popover Header" 
                                data-content="Responds to questions inadequately."> Not Yet Competent (1)</a>
                        </div>



                        <div class="form-group{{ $errors->has('criteria_seven') ? ' has-error' : '' }}">

                            <div class="col-md-4">

                                <div class="radio">
                                      <label><input type="radio" name="criteria_seven" id="criteria_seven" value="1" required> 1 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_seven" id="criteria_seven" value="2"> 2 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_seven" id="criteria_seven" value="3"> 3 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_seven" id="criteria_seven" value="4"> 4 </label>
                                </div>
                                <div class="radio">
                                      <label><input type="radio" name="criteria_seven" id="criteria_seven" value="5"> 5 </label>
                                </div>
                            

                            </div>
                        </div>


                        <hr>


                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-default">
                                    submit
                               
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);
        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>


@endsection


<script src="/js/app.js"></script>
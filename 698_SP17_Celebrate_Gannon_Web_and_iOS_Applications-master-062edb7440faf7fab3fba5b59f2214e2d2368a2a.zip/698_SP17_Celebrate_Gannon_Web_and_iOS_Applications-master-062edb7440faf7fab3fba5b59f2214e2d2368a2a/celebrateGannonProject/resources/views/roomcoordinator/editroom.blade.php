@extends('layouts.app')

@section('content')


<div class="container" style="padding: 20px 30px 30px 40px;">


<div style="border: 3px groove black; padding: 10px 30px 30px 40px; " >
<h2>Edit an Existing Room:</h2>
<form method="POST" action="/celebrateGannon/celebrateGannonProject/public/roomcoordinator/updateroom">

{{ csrf_field() }}
@foreach ($room as $selectedroom)
<label> Room Name:  </label>  <input type="text" name="room_code"  required value="{{$selectedroom->room_code}}">
<input type="hidden" name="id" required value="{{$selectedroom->id}}">
@endforeach
<button type="submit" class="btn btn-primary">Submit</button>


<a href="\roomcoordinator" class="btn btn-default " role="button">Cnacel</a>

  </div>

</form>
      </div>
  

      
      <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


@endsection


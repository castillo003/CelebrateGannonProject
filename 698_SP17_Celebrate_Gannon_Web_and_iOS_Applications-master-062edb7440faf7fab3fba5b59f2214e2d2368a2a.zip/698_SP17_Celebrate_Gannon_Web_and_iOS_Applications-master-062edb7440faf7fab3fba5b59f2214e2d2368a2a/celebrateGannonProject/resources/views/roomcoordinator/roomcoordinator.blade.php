@extends('layouts.app')

@section('content')

<div class="container" style="padding: 20px 30px 30px 40px;">


<div style="border: 3px groove black; padding: 10px 30px 30px 40px; " >
<h2>Add a New Room:</h2>
<form method="POST" action="/celebrateGannon/celebrateGannonProject/public/roomcoordinator/addroom">

{{ csrf_field() }}
<label> Room Name:  </label>  <input type="text" name="room_code" required>
<button type="submit" class="btn btn-primary">Add</button>
	</div>

</form>

  <div class="table-responsive">

<table class="table ">
 <h1>Rooms:</h1>
  <thead>
    <tr>

      <th>Room </th>
      <th>Action</th>
      
      
    </tr>
  </thead>
  
  <tbody>
	@foreach ($rooms as $room)
    <tr>
  


      <td>{{$room->room_code}}</td>
      <td> 


      <a href="roomcoordinator/{{$room->id}}/editroom" class="btn btn-primary " role="button">Edit</a>

       <a href="roomcoordinator/{{$room->id}}/deleteroom" class="btn btn-danger " role="button">Delete</a>
    


      </td>
      
     
    </tr>
     @endforeach
      

  </tbody>
      

</table>





      </div>
      </div>
  

      
      <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


@endsection


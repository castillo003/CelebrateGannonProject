@extends('layouts.app')

@section('content')
<div class="container">

<h3 align="center"> Posters Schedule </h3>

 <div class="table-responsive">          
<table class="table ">
  <thead>
    <tr>

      <th>Student Name</th>
      <th>Title</th>
      <th>Room</th>
      <th>Time</th>
      <th>Total</th>
      
    </tr>
  </thead>
    @foreach ( $posterscoresheets as $posterscoresheet )

  <tbody>

    <tr>

      @foreach ($students as $student)
      @if ($posterscoresheet->student_id == $student->id ) 
      <td>{{$student->name}}</td>
      @endif
      @endforeach
    

      @foreach ($proposals as $proposal)
      @if ($posterscoresheet->student_id == $proposal->student_id )
      
      <td>{{$proposal->title}}</td>
      @endif
      @endforeach

      @foreach ($poSchedule as $poSchedules)
      @if ($posterscoresheet->student_id == $poSchedules->approvedproposals_id )
      
      <td>{{$poSchedules->room_code}}</td>

      @endif
      @endforeach


      @foreach ($poSchedule as $poSchedules)
      @if ($posterscoresheet->student_id == $poSchedules->approvedproposals_id )
      
      <td>{{$poSchedules->time}}</td>

      @endif
      @endforeach

      <td>{{$posterscoresheet->total}}</td>


      <td> 


      <a href="{{$posterscoresheet->id}}\evaluate" class="btn btn-primary " role="button">Evaluate</a>

    </td>

    </tr>

  </tbody>
  @endforeach

</table>
</div>
</div>

<script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);
        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>

@endsection

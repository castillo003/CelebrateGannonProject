@extends('layouts.app')

@section('content')



<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"> Proposal Information </div>




                
                <div class="panel-body">
                   
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('/students/storepr') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}


                       


            

                         <div class="form-group{{ $errors->has('dep_name') ? ' has-error' : '' }}">
                            <label for="dep_name" class="col-md-4 control-label">Departments</label>

                            <div class="col-md-6">

                                <select class="form-group"  name="dep_name">

                                  @foreach($departments as $department)
                                  <option name="dep_name" value="{{$department->id}}">{{$department->name}}
                                  </option>
                                  @endforeach

                          </select>

                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('cat_name') ? ' has-error' : '' }}">
                            <label for="cat_name" class="col-md-4 control-label">Category: </label>

                            <div class="col-md-6">

                                <select class="form-group"  name="cat_name">
    

                                  @foreach($categories as $category)
                                  <option name="cat_name" value="{{$category->id}}">{{$category->name}}
                                  </option>
                                  @endforeach

                          </select>

                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('title') ? ' has-error' : '' }}">
                            <label for="title" class="col-md-4 control-label">Proposal title: </label>

                            <div class="col-md-6">
                                <input id="title" type="text" class="form-control" name="title" value="{{ old('title') }}"  autofocus required>

                                  @if ($errors->has('title'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('title') }}</strong>
                                    </span>
                                @endif

                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('type') ? ' has-error' : '' }}">
                            <label for="type" class="col-md-4 control-label">Proposal type: </label>

                            <div class="col-md-4">
                                <select class="form-group"  name="type" >
                                      <option value="PL">Platform
                                      </option>
                                      <option  value="PO">Poster
                                      </option>
                                      </select>

                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('advisor') ? ' has-error' : '' }}">
                            <label for="advisor" class="col-md-4 control-label">Advisor Name: </label>

                            <div class="col-md-6">
                                <input id="advisor" type="text" class="form-control" name="advisor" value="{{ old('advisor') }}"  autofocus required>

                            </div>
                        </div>



                        <div class="form-group{{ $errors->has('ad_email') ? ' has-error' : '' }}">
                            <label for="ad_email" class="col-md-4 control-label">Advisor E-Mail Address: </label>

                            <div class="col-md-6">
                                <input id="ad_email" type="ad_email" class="form-control" name="ad_email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" value="{{ old('ad_email') }}" required>

                                @if ($errors->has('ad_email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('ad_email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('Gr_mem_name') ? ' has-error' : '' }}">
                            <label for="Gr_mem_name" class="col-md-4 control-label">Group member names: </label>

                            <div class="col-md-6">
                                <input id="Gr_mem_name" type="text" class="form-control" name="Gr_mem_name" value="{{ old('Gr_mem_name') }}"  autofocus>

                            </div>
                        </div>


                         <div class="form-group{{ $errors->has('file') ? ' has-error' : '' }}">
                            <label for="file" class="col-md-4 control-label">file: </label>

                            <div class="col-md-6">
                                <input id="file" type="file" class="form-control" name="file" required autofocus>

                                @if ($errors->has('file'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('file') }}</strong>
                                    </span>
                                @endif

                            </div>
                        </div>
                  

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Submit
                                </button>
                         
                            </div>
                        </div>
                         @foreach($students as $student)

                        <input type="hidden" name="st_id" value="{{ $student->id}}" >
                         <button type="button" class="btn btn-default"><a href="/celebrateGannon/celebrateGannonProject/public/students/{{$student->id}}/delete">Cancel</a>


                        @endforeach
                       
                    </form>
                       


                </div>
            </div>
        </div>
    </div>
</div>

<script>
var uploadfield = document.getElementById("file");
var fileName = uploadfield.value;
//var ext = fileName.substr(filename.lastIndexOf('.')+1);
var allowedFiles = [".doc", ".docx", ".pdf"];

uploadfield.onchange = function() {
    if(this.files[0].size > 204800 ){
       alert("File is too big!");
       this.value = "";
    };
    };
</script>


@endsection

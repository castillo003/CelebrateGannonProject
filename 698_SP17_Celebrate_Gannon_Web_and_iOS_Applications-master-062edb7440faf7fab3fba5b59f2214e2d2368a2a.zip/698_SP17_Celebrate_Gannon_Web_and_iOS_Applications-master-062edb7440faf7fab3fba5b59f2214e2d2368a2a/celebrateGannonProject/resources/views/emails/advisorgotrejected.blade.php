<!DOCTYPE html>
<h1> Your student {{$student}} Got rejected </h1>


</html>
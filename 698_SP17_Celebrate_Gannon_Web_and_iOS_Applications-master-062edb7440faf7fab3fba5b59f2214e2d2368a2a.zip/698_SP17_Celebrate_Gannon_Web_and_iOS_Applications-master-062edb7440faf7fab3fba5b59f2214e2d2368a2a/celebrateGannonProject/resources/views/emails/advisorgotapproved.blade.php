<!DOCTYPE html>
<h1> Your student {{$student}} Got Approved </h1>


</html>
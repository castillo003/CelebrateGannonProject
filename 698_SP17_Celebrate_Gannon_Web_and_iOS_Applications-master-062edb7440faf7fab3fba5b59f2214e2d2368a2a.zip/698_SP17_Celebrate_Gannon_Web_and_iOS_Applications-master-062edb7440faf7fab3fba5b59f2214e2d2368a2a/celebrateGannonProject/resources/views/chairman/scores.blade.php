@extends('layouts.app')

@section('content')

<div class="container">

  <div class="table-responsive">

<table class="table ">
 <col width="130">
  <col width="130">
 <h1>Poster Scores</h1>
  <thead>
    <tr>

      <th>Student Name </th>
      <th>Judge Name</th>
      <th>Cr1</th>
      <th>Cr2</th>
      <th>Cr3</th>
      <th>Cr4</th>
      <th>Cr5</th>
      <th>Cr6</th>
      <th>Judge Experience</th>
      <th>Total</th>

      
    </tr>
  </thead>
  
  <tbody>

    <tr>
   
    @foreach ($posterscores as $posterscore)
    @if ($posterscore->judge_id != 0)

      
    @foreach ($studentname as $name)
    @if ($posterscore->student_id == $name->id)

      <td>{{$name->name}}</td>
    @endif
    @endforeach
    @foreach ($judgesname as $judgename)
    @if ($posterscore->judge_id == $judgename->id)
      <td>{{$judgename->lname}}, {{$judgename->fname}}</td>
    @endif
    @endforeach

    



      <td>{{$posterscore->criteria_one}}</td>
      <td>{{$posterscore->criteria_two}}</td>
      <td>{{$posterscore->criteria_three}}</td>
      <td>{{$posterscore->criteria_four}}</td>
      <td>{{$posterscore->criteria_five}}</td>
      <td>{{$posterscore->criteria_six}}</td>
      <td>{{$posterscore->experience}}</td>
      <td>{{$posterscore->total}}</td>
      <td> 

    
     
      <a href="{{$posterscore->id}}\posterscoresheetsview" class="btn btn-primary " role="button">View</a>

      

    </td>

    </tr>
      

  </tbody>
  @endif
      @endforeach

</table>


<table class="table ">
 <col width="130">
  <col width="130">
  <h1>Platform Scores</h1>

  <thead>
    <tr>

      <th>Student Name </th>
      <th>Judge Name</th>
      <th>Cr1</th>
      <th>Cr2</th>
      <th>Cr3</th>
      <th>Cr4</th>
      <th>Cr5</th>
      <th>Cr6</th>
      <th>Cr7</th>
      <th>Judge Experience</th>
      <th>Total</th>

      
    </tr>
  </thead>
  
  <tbody>

    <tr>
   
    @foreach ($platformscores as $platformscore)
    @if ($platformscore->judge_id != 0)

    @foreach ($studentname as $name)
    @if ($platformscore->student_id == $name->id)

      <td>{{$name->name}}</td>
    @endif
    @endforeach
    @foreach ($judgesname as $judgename)
    @if ($platformscore->judge_id == $judgename->id)
      <td>{{$judgename->lname}}, {{$judgename->fname}}</td>
    @endif
    @endforeach
      <td>{{$platformscore->criteria_one}}</td>
      <td>{{$platformscore->criteria_two}}</td>
      <td>{{$platformscore->criteria_three}}</td>
      <td>{{$platformscore->criteria_four}}</td>
      <td>{{$platformscore->criteria_five}}</td>
      <td>{{$platformscore->criteria_six}}</td>
      <td>{{$platformscore->criteria_seven}}</td>
      <td>{{$platformscore->experience}}</td>
      <td>{{$platformscore->total}}</td>
      <td> 

     

    <a href="{{$platformscore->id}}\platformscoresheetsview" class="btn btn-primary " role="button">View</a>
     
      

    </td>

    </tr>
      

  </tbody>
    @endif
      @endforeach

</table>




      </div>
      </div>
   <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>

      
      


@endsection
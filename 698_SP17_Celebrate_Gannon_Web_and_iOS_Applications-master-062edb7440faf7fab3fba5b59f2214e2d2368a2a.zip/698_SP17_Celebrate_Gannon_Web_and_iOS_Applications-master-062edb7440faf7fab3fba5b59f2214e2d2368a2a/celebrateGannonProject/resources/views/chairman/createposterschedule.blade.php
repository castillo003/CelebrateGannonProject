@extends('layouts.app')

@section('content')


<div class="container">

<form method="POST" action="/celebrateGannon/celebrateGannonProject/public/chairman/createposterschedule"  >

<h1>Create Posters Schedule</h1>

 {{ csrf_field() }}

 


  <div class="form-group">
    <label >Posters:</label>
    <select multiple class="form-control"  name="approvedproposals_id[]"  >
    @foreach ($approvedposters as $approvedposter)
      <option value="{{$approvedposter->approvedproposals_id}}">{{$approvedposter->approvedproposals_id}} <label > Department:
      @foreach ($departments as $department) 
      @if($approvedposter->department_id == $department->id)
      {{$department->name}}
      @endif
      @endforeach
      </label>
      </option>
     @endforeach
      
    </select>
    </div>
     <div class="form-group">

     <label >Room</label>
    <select class="form-control"  name="room_code"  default >
    
      <option  value="{{'Hammermill Center'}}">{{'Hammermill Center'}} 


      </option>
   
    </select>

     </div>


     <div class="form-group">
    <label >Judges:</label>
    <select multiple class="form-control" name="lname[]" >
    @foreach ($judges as $judge)
      <option value="{{$judge->id}}">{{$judge->lname}}, {{$judge->fname}}
      
      </option>
     @endforeach
      
    </select>
    </div>

     <div class="form-group">

    <button type="submit" class="btn btn-primary">Add To Schedule</button>
  </div>
  
  
 
</form>

</div>
 <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
   

@endsection

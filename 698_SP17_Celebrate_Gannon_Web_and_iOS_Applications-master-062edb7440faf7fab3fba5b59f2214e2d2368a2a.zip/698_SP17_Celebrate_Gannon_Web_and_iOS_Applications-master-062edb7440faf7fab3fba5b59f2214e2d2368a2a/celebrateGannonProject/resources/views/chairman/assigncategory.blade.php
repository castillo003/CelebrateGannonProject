@extends('layouts.app')

@section('content')

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Assign Category</div>
                <div class="panel-body">
<form class="form-horizontal" method="POST" action="/celebrateGannon/celebrateGannonProject/public/chairman/assign">
{{ csrf_field() }}
<div class="form-group">
 <label for="name" class="col-md-4 control-label">Coordinator</label>

    <div class="col-md-6">
        <select multiple class="form-control"  name="coordinators[]"  >
            @foreach ($users as $user)
            @if ($user->user_type == 'Coordinator')
                <option value="{{$user->id}}">{{$user->fname}}, {{$user->lname}}             
                </option>
            @endif
             @endforeach
                              
        </select>
    </div>

    </div>
          <div class="form-group">
            <label for="name" class="col-md-4 control-label">Category</label>

            <div class="col-md-6">
            <select multiple class="form-control"  name="categories[]"  >
                @foreach ($categories as $category)
                    <option value="{{$category->id}}">{{$category->name}}  </option>
                @endforeach
                              
            </select>
        </div>
    </div>
     <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    ADD
                                </button>
                            </div>
                        </div>

</form>
</div>
</div>
</div>
</div>
 <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>



@endsection

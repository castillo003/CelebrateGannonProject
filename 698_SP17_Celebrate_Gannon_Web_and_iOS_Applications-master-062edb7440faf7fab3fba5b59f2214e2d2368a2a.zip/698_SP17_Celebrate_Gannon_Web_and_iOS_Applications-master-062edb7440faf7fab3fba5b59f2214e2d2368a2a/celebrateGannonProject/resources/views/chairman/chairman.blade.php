@extends('layouts.app')

@section('content')
<div class="container">
<h1> Welcome Celebrate Gannon Chairman</h1>
<a href="/celebrateGannon/celebrateGannonProject/public/chairman/scores" class="btn btn-lg btn-primary " role="button">Scores</a>
<a href="/celebrateGannon/celebrateGannonProject/public/chairman/calculatescores" class="btn btn-lg btn-primary " role="button">Winners</a>

<a href="/celebrateGannon/celebrateGannonProject/public/chairman/manageschedule" class="btn btn-lg btn-primary " role="button">Manage Schedule</a>

<a href="/celebrateGannon/celebrateGannonProject/public/chairman/manageusers" class="btn btn-lg btn-primary " role="button">Manage Users</a>


</div>
 <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>

@endsection
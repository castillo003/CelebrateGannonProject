@extends('layouts.app')

@section('content')
<div class="container" style="padding: 20px 30px 30px 40px;">
<h2>Coordinator Name:</h2>

 @foreach ($coordinator as $selected)
 @if($selected->coordinator_id  == $id)
 @foreach ($users as $user)
 @if ($selected->coordinator_id == $user->id)
 <label><h4> {{$user->lname}},{{$user->fname}} </h4></label>

 @endif

 @endforeach
 @endif
 <?php break; ?>

 @endforeach

<h2>Category:</h2>
 @foreach ($coordinator as $selected)



 @foreach ($categories as $category)
 @if ($selected->category_id == $category->id)
  <h4> {{$category->name}} </h4>
 @endif
 @endforeach

 

 @endforeach
</div>
 <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
@endsection
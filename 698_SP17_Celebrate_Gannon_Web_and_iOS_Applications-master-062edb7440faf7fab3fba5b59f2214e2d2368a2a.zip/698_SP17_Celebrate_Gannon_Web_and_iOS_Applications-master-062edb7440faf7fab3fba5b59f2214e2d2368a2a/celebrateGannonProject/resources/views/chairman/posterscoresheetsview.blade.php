@extends('layouts.app')

@section('content')



<div class="container">
@foreach ($posterscores as $posterscore)

      
    	
      @foreach ($studentname as $name)
    @if ($posterscore->student_id == $name->id)

      <h3>Student Name:	 </h3><h5> {{$name->name}}</h5>
    @endif
    @endforeach
    @foreach ($judgesname as $judgename)
    @if ($posterscore->judge_id == $judgename->id)
      <h3>Judge Name:	</h3><h5>{{$judgename->lname}}, {{$judgename->fname}}</h5>
    @endif
    @endforeach

    @foreach ($approvedproposals as $approvedproposal)
    @if ($posterscore->student_id == $approvedproposal->student_id)
    @foreach ($categories as $category)
    @if ($approvedproposal->category_id == $category->id)

      <h3>Category: </h3><h3>{{$category->name}}</h3>
    @endif  
    @endforeach
    @endif
    @endforeach

    <h3>Judge Experience:	 </h3><h5> {{$posterscore->experience}}</h5>
 @endforeach

  <div class="table-responsive">

<table class="table ">
 
  <thead>
    <tr>

      
      <th>Criteria</th>
      <th>Score</th>
      <th>Comment</th>
      

      
    </tr>
  </thead>
  
  <tbody>

   
   
   
 @foreach ($posterscores as $posterscore)
 <tr>
      
    <tr>
      <td>ORGANIZATION</td>
       
      <td>{{$posterscore->criteria_one}}</td>
      <td>{{$posterscore->criteria_one_comment}}</td>
     
      </tr>
      <tr>
      <td>PRESENTATION OF POSTER</td>
     
      <td>{{$posterscore->criteria_two}}</td>
      <td>{{$posterscore->criteria_two_comment}}</td>
       </tr>

       <tr>

      <td>DEPTH OF CONTENT</td>
      <td>{{$posterscore->criteria_three}}</td>
      <td>{{$posterscore->criteria_three_comment}}</td>
      </tr>

      <tr>

      <td>GRAMMAR AND WORD CHOICE</td>
      <td>{{$posterscore->criteria_four}}</td>
      <td>{{$posterscore->criteria_four_comment}}</td>
      </tr>

      <tr>

      <td>PROFESSIONALISM</td>
      <td>{{$posterscore->criteria_five}}</td>
      <td>{{$posterscore->criteria_five_comment}}</td>
      </tr>

      <tr>

      <td>VERBAL INTERACTION</td>
      <td>{{$posterscore->criteria_six}}</td>
      <td>{{$posterscore->criteria_six_comment}}</td>
      </tr>

      <tr>

      <td><b>Total</b></td>
      <td><b>{{$posterscore->total}}</b></td>
      <td>{{$posterscore->general_comment}}</td>
      </tr>

        <td> 


       <a href="\celebrateGannon\celebrateGannonProject\public\chairman\{{$posterscore->id}}\posterscoresheetsedit" class="btn btn-primary " role="button">Edit</a>

      <a href="\celebrateGannon\celebrateGannonProject\public\chairman\{{$posterscore->id}}\posterscoresheetsdelete" class="btn btn-danger " role="button">Delete</a>

    </td>


</tr>
    @endforeach
      

  </tbody>
    

</table>
</div>
      </div>
       <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
  

@endsection

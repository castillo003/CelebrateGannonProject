@extends('layouts.app')

@section('content')

<div class="container">

  <div class="table-responsive">

  
<form method="POST" action="/celebrateGannon/celebrateGannonProject/public/chairman/posterscheduleedit">
{{ csrf_field() }}
<table class="table ">

 <h1>Poster Schedule Edit</h1>
  <thead>
    <tr>
      <th>Student Name </th>
      <th>Department</th>
      <th>Category</th>
   
      
      <th>Room</th>
      <th>Time</th>
      <th>Ju1</th>
      <th>Ju2</th>
      <th>Ju3</th>
     

      
    </tr>
  </thead>
  
  <tbody>
  
      @foreach ($posterschedule as $slot)

    <tr>
 
	
	@foreach ( $approvedposters as $approvedposter)

		@if($approvedposter->id == $slot->approvedproposals_id)
		<td> {{$approvedposter->name}}</td>

			@foreach ($departments as $department)
			@if ($department->id == $approvedposter->department_id)
			<td>{{$department->name}}</td>
			@endif
			@endforeach

      @foreach ($categories as $category)
      @if ($category->id == $approvedposter->category_id)
      <td>{{$category->name }}</td>
      @endif
      @endforeach
		@endif
    @endforeach


		 <input type="hidden" name="approvedproposals_id[]" value="{{$slot->approvedproposals_id}}">
    
      <td><select class="form-control"  name="room_code[]"  >
       <option  value="{{'Hammermill Center'}}">{{'Hammermill Center'}} 
      
      </select>
      </td>

      <td><select class="form-control"  name="eventtimes_id[]"  >
      <option name="eventtimes_id[]" value="{{$slot->time}}">{{$slot->time}}
      </option>
      <option value="1:00">1:00
      </option>
      <option value="1:15">1:15
      </option>
      <option value="1:30">1:30
      </option>
      <option value="1:45">1:45
      </option>
      <option value="2:00">2:00
      </option>
      <option  value="2:15">2:15
      </option>
      <option  value="2:30">2:30
      </option>
      <option value="2:45">2:45
      </option>
      <option  value="3:00">3:00
      </option>
      <option  value="3:15">3:15
      </option>
      <option  value="3:30">3:30
      </option>
      <option  value="3:45">3:45
      </option>
       <option  value="4:00">4:00
      </option>

      </select>
      </td>
      
      <td><select class="form-control"  name="judge_onelname[]">
      @if($slot->judge_one == NULL)
      <option name="judge_onelname[]" value="null" selected="selected">
      </option>
      @endif
     

      @foreach ($judgesname as $judgename)
      @if($slot->judge_one == $judgename->id)
      <option name="judge_onelname[]" value="null" selected="selected">
      </option>
      <option name="judge_onelname[]" value="{{$judgename->id}}" selected="selected">{{$judgename->lname}}, {{$judgename->fname}}
      </option>
      @endif
      @endforeach    
      
      @foreach($judges as $judge)
      <option name="judge_onelname[]" value="{{$judge->id}}">{{$judge->lname}},{{$judge->fname}}
      </option>
      @endforeach

      </select></td>
     
     <td><select class="form-control"  name="judge_twolname[]">
      @if($slot->judge_two == NULL)
      <option name="judge_twolname[]" value="null" selected="selected">
      </option>
      @endif
      @foreach ($judgesname as $judgename)
      @if($slot->judge_two == $judgename->id)
      
      <option name="judge_twolname[]" value="{{$judgename->id}}" selected="selected">{{$judgename->lname}}, {{$judgename->fname}}
      </option>
      @endif
      @endforeach

      @foreach($judges as $judge)
      <option name="judge_twolname[]" value="{{$judge->id}}">{{$judge->lname}},{{$judge->fname}}
      </option>
      @endforeach

      </select></td>

     <td><select class="form-control"  name="judge_threelname[]">
      @if($slot->judge_three == NULL)
      <option name="judge_threelname[]" value="null" selected="selected">
      </option>
      @endif

      @foreach ($judgesname as $judgename)

      @if($slot->judge_three == $judgename->id)
      
      <option name="judge_threelname[]" value="{{$judgename->id}}" selected="selected">{{$judgename->lname}}, {{$judgename->fname}}
      </option>
      
      
      @endif
      @endforeach

      @foreach($judges as $judge)
      <option name="judge_threelname[]" value="{{$judge->id}}">{{$judge->lname}},{{$judge->fname}}
      </option>
      @endforeach

     
      </select></td>
     

    

    </tr>

	@endforeach

  </tbody>

  




</table>
 <button type="submit" class="btn btn-primary">Submit</button>
 </form>
      </div>
      </div>
       <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
  

 
@endsection

@extends('layouts.app')

@section('content')




<div class="container">
@foreach ($posterscores as $posterscore)

      
    	
      @foreach ($studentname as $name)
    @if ($posterscore->student_id == $name->id)

      <h3>Student Name:	 </h3><h5> {{$name->name}}</h5>
    @endif
    @endforeach
    @foreach ($judgesname as $judgename)
    @if ($posterscore->judge_id == $judgename->id)
      <h3>Judge Name:	</h3><h5>{{$judgename->lname}}, {{$judgename->fname}}</h5>
    @endif
    @endforeach
    <h3>Judge Experience:	 </h3><h5> {{$posterscore->experience}}</h5>
 @endforeach

  <div class="table-responsive">
  <form method="POST" action="/celebrateGannon/celebrateGannonProject/public/chairman/scores"  >
 {{ csrf_field() }}


<table class="table ">
 
  <thead>
    <tr>

      
      <th>Criteria</th>
      <th>Weighted Score</th>
      <th>Comment</th>
      

      
    </tr>
  </thead>
  
  <tbody>

   
   
   
 @foreach ($posterscores as $posterscore)
 <tr>
      
    <tr>
      <td>ORGANIZATION</td>
     
      <input type="hidden" name="id" value="{{$posterscore->id}}">


       <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_one') ? ' has-error' : '' }}">
      <td><input type="text" id="criteria_one" name="criteria_one" value="{{$posterscore->criteria_one}}">
      @if ($errors->has('criteria_one'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_one') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$posterscore->criteria_one_comment}}</td>
     
      </tr>
      <tr>
      <td>PRESENTATION OF POSTER</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_two') ? ' has-error' : '' }}">
     
      <td><input type="text" id="criteria_two" name="criteria_two" value="{{$posterscore->criteria_two}}">
      @if ($errors->has('criteria_two'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_two') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$posterscore->criteria_two_comment}}</td>
       </tr>

       <tr>

      <td>DEPTH OF CONTENT</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_three') ? ' has-error' : '' }}">
      <td><input type="text" id="criteria_three" name="criteria_three" value="{{$posterscore->criteria_three}}"> @if ($errors->has('criteria_three'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_three') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$posterscore->criteria_three_comment}}</td>
      </tr>

      <tr>

      <td>GRAMMAR AND WORD CHOICE</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_four') ? ' has-error' : '' }}">
      <td><input type="text"  id="criteria_four" name="criteria_four" value="{{$posterscore->criteria_four}}">
       @if ($errors->has('criteria_four'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_four') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$posterscore->criteria_four_comment}}</td>
      </tr>

      <tr>

      <td>PROFESSIONALISM</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_five') ? ' has-error' : '' }}">
      <td><input type="text" id="criteria_five" name="criteria_five" value="{{$posterscore->criteria_five}}">
       @if ($errors->has('criteria_five'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_five') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$posterscore->criteria_five_comment}}</td>
      </tr>

      <tr>

      <td>VERBAL INTERACTION</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_six') ? ' has-error' : '' }}">
      <td><input type="text" id="criteria_six" name="criteria_six" value="{{$posterscore->criteria_six}}">
       @if ($errors->has('criteria_six'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_six') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$posterscore->criteria_six_comment}}</td>
      </tr>

        <tr>
     <td>Judge Experience </td>
        <td><select class="form-control"  name="experience"  >
      <option name="experience" value="Area of my experties">Area of my experties
      </option>
      <option name="experience" value="Expert in allied field">Expert in allied field
      </option>
      <option name="experience" value="Not my area">Not my area
      </option>
      
      </select>
      </td>
      </tr>

      <tr>

      <td><b>Total</b></td>
      <td><b>{{$posterscore->total}}</b></td>
      <td>{{$posterscore->general_comment}}</td>
      </tr>

        <td> 

    
     
       <button type="submit" class="btn btn-primary">Submit</button>
     
    <button type="button" class="btn btn-default"><a href="\celebrateGannon\celebrateGannonProject\public\chairman\scores">Cnacel</a>
      </button>

    </td>


</tr>
    @endforeach
      

  </tbody>
    

</table>
</form>
</div>
      </div>
       <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
  


@endsection

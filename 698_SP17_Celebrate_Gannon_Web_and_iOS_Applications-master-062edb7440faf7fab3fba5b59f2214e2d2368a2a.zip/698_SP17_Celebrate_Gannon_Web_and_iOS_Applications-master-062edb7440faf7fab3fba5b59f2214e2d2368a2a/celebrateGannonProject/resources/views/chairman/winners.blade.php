@extends('layouts.app')

@section('content')

<div class="container">

  <div class="table-responsive">

                @foreach ($categoryname as $caname)

                <h2>Category: {{$caname->name}}</h2>

 
  
<table class="table ">

  <thead>
    <tr>
  		
  	  
      <th>Student</th>
      <th>Department </th>
      <th>AVG</th>
       </tr>
  </thead>
 

  
  <tbody>
         @foreach ($studentscores as $studentscore)
         @foreach ($approvedproposals as $approvedproposal)

        

         @if($approvedproposal->category_id == $caname->id )


         @if($approvedproposal->student_id == $studentscore->student_id )
          
<tr>
        


               @foreach ($studentname as $stuname)
		@if ($studentscore->student_id == $stuname->id )
		<td>{{$stuname->name}}</td>

		@endif
		@endforeach  


                @foreach ($departmentname as $depname)
		@if ($approvedproposal->department_id == $depname->id )
		<td>{{$depname->name}}</td>

		@endif
		@endforeach

         <td>{{$studentscore->average}}</td>

 

</tr>

@endif
@endif

@endforeach

@endforeach

</tbody>
    
</table>

 @endforeach



</div>
</div>

 <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>

@endsection


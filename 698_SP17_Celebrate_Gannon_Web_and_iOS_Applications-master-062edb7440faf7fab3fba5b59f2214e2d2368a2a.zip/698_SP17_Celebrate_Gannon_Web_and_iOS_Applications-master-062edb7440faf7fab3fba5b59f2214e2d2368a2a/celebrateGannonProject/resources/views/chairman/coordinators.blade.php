@extends('layouts.app')

@section('content')

<div class="container">


<div class="container" style="padding: 20px 30px 30px 40px;">

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add Coordinator</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="/celebrateGannon/celebrateGannonProject/public/chairman/addcoordinator">
                        {{ csrf_field() }}

                         <div class="form-group{{ $errors->has('fname') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">First Name</label>

                            <div class="col-md-6">
                                <input id="fname" type="text" class="form-control" name="fname" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('fname'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('fname') }}</strong>
                                    </span>
                                @endif
                            </div>

                        </div>
                        

                    <div class="form-group{{ $errors->has('lname') ? ' has-error' : '' }}">
                         <label for="name" class="col-md-4 control-label">Last Name</label>

                         <div class="col-md-6">
                                <input id="lname" type="text" class="form-control" name="lname" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('lname'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('lname') }}</strong>
                                    </span>
                                @endif
                            </div>
                    </div>

                    
                        

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>



                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>



                        <div class="form-group{{ $errors->has('user_type') ? ' has-error' : '' }}">
                            

                            <div class="col-md-6" type="hidden">
                              

                               
                                    <div class="radio" type="hidden">
                                      <label><input  type="hidden" name="user_type" id="user_type" value="Coordinator">  </label>
                                    </div>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    ADD
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

  <div class="table-responsive">

<table class="table ">
 <h1>Coordinators:</h1>
  <thead>
    <tr>

      <th>Name </th>
      <th>Category</th>
      <th>Action</th>
      
      
    </tr>
  </thead>
  
  <tbody>
	@foreach ($users as $user)
	@if($user->user_type == 'Coordinator')
    <tr>
  


      <td>{{$user->lname}},{{$user->fname}}</td>
      <td>
      @foreach($categorycoordinators as $categorycoordinator)
       @if($user->id == $categorycoordinator->coordinator_id)
       @foreach ($categories as $category)
       @if ($categorycoordinator->category_id == $category->id)
        {{$category->name}}  </br> 
       @endif
       @endforeach
       @endif
       @endforeach

      </td>

     
      <td> 


      
      <a href="/celebrateGannon/celebrateGannonProject/public/chairman/coordinatorsview/{{$user->id}}" class="btn  btn-primary " role="button">View</a>

      <a href="/celebrateGannon/celebrateGannonProject/public/chairman/assigncategory" class="btn  btn-primary " role="button">Assign Category</a>


      <a href="/celebrateGannon/celebrateGannonProject/public/chairman/coordinatorsdelete/{{$user->id}}" class="btn btn-default btn-danger " role="button">Delete</a>


      
    
       </td>
     
     
      
      
     
    </tr>
    @endif
     @endforeach
      

  </tbody>
      

</table>





      </div>
      </div>
       <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
  

      
     

@endsection


@extends('layouts.app')

@section('content')
<div class="container">
<h1>Manage Schedule</h1>


<h2><label>Platform:</label></h2><br>
<a href="/celebrateGannon/celebrateGannonProject/public/chairman/createplatformschedule" class="btn btn-lg btn-primary " role="button">Create Platform Schedule</a>
<a href="/celebrateGannon/celebrateGannonProject/public/chairman/platformscheduleedit" class="btn btn-lg btn-primary " role="button">Edit Platform Schedule</a>
<a href="/celebrateGannon/celebrateGannonProject/public/chairman/platformschedule" class="btn btn-lg btn-primary " role="button">View Platform Schedule</a>

<br><h2><label>Poster:</label></h2><br>

<a href="/celebrateGannon/celebrateGannonProject/public/chairman/createposterschedule" class="btn btn-lg btn-primary " role="button">Create Poster Schedule</a>
<a href="/celebrateGannon/celebrateGannonProject/public/chairman/posterscheduleedit" class="btn btn-lg btn-primary " role="button">Edit Poster Schedule</a>
<a href="/celebrateGannon/celebrateGannonProject/public/chairman/posterschedule" class="btn btn-lg btn-primary " role="button">View Poster Schedule</a>


</div>
 <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
@endsection

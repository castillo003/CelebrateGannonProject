@extends('layouts.app')

@section('content')

<div class="container">
 <h1>Poster Schedule</h1>

  <div class="table-responsive">

  

<table class="table ">

  <thead>
    <tr>
      <th>Student Name </th>
      <th>Department</th>
      <th>Category</th>
      
      <th>Room</th>
      <th>Time</th>
      <th>Ju1</th>
      <th>Ju2</th>
      <th>Ju3</th>
     

      
    </tr>
  </thead>
  
  <tbody>
  
      @foreach ($posterschedule as $slot)
     

    <tr>
 
	
	@foreach ( $approvedposters as $approvedposter)

		@if($approvedposter->id == $slot->approvedproposals_id)
		<td> {{$approvedposter->name}}</td>

			@foreach ($departments as $department)
			@if ($department->id == $approvedposter->department_id)
			<td>{{$department->name}}</td>
			@endif
			@endforeach

      @foreach ($categories as $category)
      @if ($category->id == $approvedposter->category_id)
      <td>{{$category->name }}</td>
      @endif
      @endforeach
		@endif


    @endforeach


		 
      
      <td>{{$slot->room_code}}</td>
      <td>{{$slot->time}}</td>
      @foreach ($judgesname as $judgename)
      @if($slot->judge_one == $judgename->id)
      <td>{{$judgename->lname}}</td>
      @endif
      @endforeach

       @foreach ($judgesname as $judgename)
       @if($slot->judge_two == $judgename->id)
      <td>{{$judgename->lname}}</td>
      @endif
      @endforeach

        @foreach ($judgesname as $judgename)

      @if($slot->judge_three == $judgename->id)
      <td>{{$judgename->lname}}</td>
      @endif
      @endforeach
      
     

   

    </tr>
    

	@endforeach
  </tbody>

  




</table>
      </div>
      </div>
       <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
  

      

@endsection
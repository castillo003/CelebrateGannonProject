@extends('layouts.app')

@section('content')
<div class="container">
@if (Session::has('approve_message'))
<div class="alert alert-success">{{Session::get('approve_message')}}</div>

@endif
@if (Session::has('reject_message'))
<div class="alert alert-danger">{{Session::get('reject_message')}}</div>

@endif
<div class="container" style="padding: 20px 30px 30px 40px;">


<button type="button"><a href="#id_of_div" class="links" id="link_1" >Approved</a> </button>

<button type="button"><a href="#id_of_div2" class="links" id="link_2">Not Reviewed</a> </button>






  <div class="table-responsive">
  <div id="id_of_div" class="divs "  >

<table class="table ">
 <h1>Judges:</h1>
  <thead>
    <tr>

      <th>Name </th>
      <th>Action</th>
      
      
    </tr>
  </thead>
  
  <tbody>
	@foreach ($users as $user)
	@if($user->user_type == 'Judge')
  @if($user->status == 1)
    <tr>
  


      <td>{{$user->lname}},{{$user->fname}}</td>
      @if ($user->status == 0)
      <td> 

    

      <a href="{{$user->id}}\approve" class="btn btn-primary " role="button">Approve</a>
       </td>
      @else
       <td>
    
            <a href="{{$user->id}}\reject" class="btn btn-danger " role="button">Reject</a>

		@endif
      </td>
      
      
     
    </tr>
    @endif
    @endif
     @endforeach
      

  </tbody>
      

</table>
</div>




  <div class="table-responsive">
        <div id="id_of_div2" class="divs" style="display:none">


<table class="table ">
 <h1>Judges:</h1>
  <thead>
    <tr>

      <th>Name </th>
      <th>Action</th>
      
      
    </tr>
  </thead>
  
  <tbody>
  @foreach ($users as $user)
  @if($user->user_type == 'Judge')
  @if($user->status == 0)
    <tr>
  


      <td>{{$user->lname}},{{$user->fname}}</td>
      @if ($user->status == 0)
      <td> 

    

      <a href="{{$user->id}}\approve" class="btn btn-primary " role="button">Approve</a>
       </td>
      @else
       <td>
    
        <a href="{{$user->id}}\reject" class="btn btn-danger " role="button">Reject</a>

    @endif
      </td>
      
      
     
    </tr>
    @endif
    @endif
     @endforeach
      

  </tbody>
      

</table>
</div>



      </div>
      </div>
      </div>
      </div>
       <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
  

      

@endsection
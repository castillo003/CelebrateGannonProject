@extends('layouts.app')

@section('content')
<div class="container">
<h1>Manage Users</h1>



<a href="/celebrateGannon/celebrateGannonProject/public/chairman/judges" class="btn btn-lg btn-primary " role="button">Manage Judges</a>
<a href="/celebrateGannon/celebrateGannonProject/public/chairman/coordinators" class="btn btn-lg btn-primary" role="button">Manage Coordinators</a>


</div>
 <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
@endsection

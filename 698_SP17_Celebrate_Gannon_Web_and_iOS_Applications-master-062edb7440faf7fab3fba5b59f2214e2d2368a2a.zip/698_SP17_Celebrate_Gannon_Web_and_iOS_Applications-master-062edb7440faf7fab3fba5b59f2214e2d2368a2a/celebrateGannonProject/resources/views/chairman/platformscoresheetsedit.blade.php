@extends('layouts.app')

@section('content')



<div class="container">
@foreach ($platformscores as $platformscore)

      
    	
      @foreach ($studentname as $name)
    @if ($platformscore->student_id == $name->id)

      <h3>Student Name:	 </h3><h5> {{$name->name}}</h5>
    @endif
    @endforeach
    @foreach ($judgesname as $judgename)
    @if ($platformscore->judge_id == $judgename->id)
      <h3>Judge Name:	</h3><h5>{{$judgename->lname}}, {{$judgename->fname}}</h5>
    @endif
    @endforeach
    <h3>Judge Experience:	 </h3><h5> {{$platformscore->experience}}</h5>
 @endforeach

  <div class="table-responsive">
   <form method="POST" action="/celebrateGannon/celebrateGannonProject/public/chairman/editplatformstore"  >

 {{ csrf_field() }}

<table class="table ">
 
  <thead>
    <tr>

      
      <th>Criteria</th>
      <th>Weighted Score</th>
      <th>Comment</th>
      

      
    </tr>
  </thead>
  
  <tbody>

   
   
   
 @foreach ($platformscores as $platformscore)
 @if($platformscore->fineart == 0)
 <tr>
      
    <tr>
      <td>ORGANIZATION</td>
      <input type="hidden" name="id" value="{{$platformscore->id}}">


      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_one') ? ' has-error' : '' }}"> 
      <td><input type="text"  id="criteria_one" name="criteria_one" value="{{$platformscore->criteria_one}}">
      @if ($errors->has('criteria_one'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_one') }}</strong>
                                    </span>
       @endif


      <td>{{$platformscore->criteria_one_comment}}</td>
      </div>
      </div>
      </tr>


      <tr>
      <td>STYLE</td>

      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_two') ? ' has-error' : '' }}"> 
     
      <td><input type="text" id="criteria_two" name="criteria_two" value="{{$platformscore->criteria_two}}">

      @if ($errors->has('criteria_two'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_two') }}</strong>
                                    </span>
       @endif

      <td>{{$platformscore->criteria_two_comment}}</td>

      </div>
      </div>
       </tr>

       <tr>

      <td>USE OF COMMUNICATION AIDS</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_three') ? ' has-error' : '' }}"> 
      <td><input type="text" id="criteria_three" name="criteria_three" value="{{$platformscore->criteria_three}}">

 @if ($errors->has('criteria_three'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_three') }}</strong>
                                    </span>
       @endif

      <td>{{$platformscore->criteria_three_comment}}</td>
      
      </div>
      </div>
      </tr>

      <tr>

      <td>DEPTH OF CONTENT</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_four') ? ' has-error' : '' }}"> 
      <td><input type="text" id= "criteria_four" name="criteria_four" value="{{$platformscore->criteria_four}}"> @if ($errors->has('criteria_four'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_four') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_four_comment}}</td>
      </tr>

      <tr>

      <td>GRAMMAR AND WORD CHOICE</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_five') ? ' has-error' : '' }}"> 
      <td><input type="text" id="criteria_five" name="criteria_five" value="{{$platformscore->criteria_five}}">
      @if ($errors->has('criteria_five'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_five') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_five_comment}}</td>
      </tr>

      <tr>

      <td>PERSONAL APPEARANCE</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_six') ? ' has-error' : '' }}"> 
      <td><input type="text" id="criteria_six" name="criteria_six" value="{{$platformscore->criteria_six}}">
       @if ($errors->has('criteria_six'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_six') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_six_comment}}</td>
      </tr>

      <tr>

      <td>VERBAL INTERACTION</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_seven') ? ' has-error' : '' }}"> 
      <td><input type="text" id="criteria_seven" name="criteria_seven" value="{{$platformscore->criteria_seven}}">
       @if ($errors->has('criteria_seven'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_seven') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_seven_comment}}</td>
      </tr>
       <tr>
     <td>Judge Experience </td>
        <td><select class="form-control"  name="experience"  >
      <option name="experience" value="Area of my experties">Area of my experties
      </option>
      <option name="experience" value="Expert in allied field">Expert in allied field
      </option>
      <option name="experience" value="Not my area">Not my area
      </option>
      
      </select>
      </td>
      </tr>

      <tr>

      <td><b>Total</b></td>
      <td><b>{{$platformscore->total}}</b></td>
      <td>{{$platformscore->general_comment}}</td>
      </tr>

        <td> 

    
     <button type="submit" class="btn btn-primary">Submit</button>
     
    <button type="button" class="btn btn-default"><a href="\celebrateGannon\celebrateGannonProject\public\chairman\scores">Cnacel</a>

    </td>


</tr>
  @else
<tr>
      
    <tr>
      <td>ORGANIZATION</td>

           <input type="hidden" name="id" value="{{$platformscore->id}}">

       <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_one') ? ' has-error' : '' }}"> 
      <td><input type="text" id="criteria_one" name="criteria_one" value="{{$platformscore->criteria_one}}">
      @if ($errors->has('criteria_one'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_one') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_one_comment}}</td>
     
      </tr>
      <tr>
      <td>DESIGN PRESENTATION AND VISUAL PERFORMANCE</td>
       <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_two') ? ' has-error' : '' }}"> 
     
      <td><input type="text" id="criteria_two" name="criteria_two" value="{{$platformscore->criteria_two}}">
      @if ($errors->has('criteria_two'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_two') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_two_comment}}</td>
       </tr>

       <tr>

      <td>DEPTH OF CONTENT</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_three') ? ' has-error' : '' }}"> 
      <td><input type="text" id="criteria_three" name="criteria_three" value="{{$platformscore->criteria_three}}">
      @if ($errors->has('criteria_three'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_three') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_three_comment}}</td>
      </tr>

      <tr>

      <td>GRAMMAR AND WORD CHOICE</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_four') ? ' has-error' : '' }}"> 

      <td><input type="text" id="criteria_four" name="criteria_four" value="{{$platformscore->criteria_four}}">
      @if ($errors->has('criteria_four'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_four') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_four_comment}}</td>
      </tr>

      <tr>

      <td>PRESENTATION And PROFESSIONAL APPEARANCE</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_five') ? ' has-error' : '' }}"> 
      <td><input type="text" id="criteria_five" name="criteria_five" value="{{$platformscore->criteria_five}}">
      @if ($errors->has('criteria_five'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_five') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_five_comment}}</td>
      </tr>

      <tr>

      <td>VERBAL INTERACTION</td>
      <div class="panel-body">

      <div class="form-group{{ $errors->has('criteria_six') ? ' has-error' : '' }}"> 
      <td><input type="text" id="criteria_six" name="criteria_six" value="{{$platformscore->criteria_six}}">
        @if ($errors->has('criteria_six'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('criteria_six') }}</strong>
                                    </span>
       @endif
       </div>
       </div>
      <td>{{$platformscore->criteria_six_comment}}</td>
      </tr>

        <tr>
     <td>Judge Experience </td>
        <td><select class="form-control"  name="experience"  >
      <option name="experience" value="Area of my experties">Area of my experties
      </option>
      <option name="experience" value="Expert in alied field">Expert in alied field
      </option>
      <option name="experience" value="Not my area">Not my area
      </option>
      
      </select>
      </td>
      </tr>

      <tr>

      <td><b>Total</b></td>
      <td><b>{{$platformscore->total}}</b></td>
      <td>{{$platformscore->general_comment}}</td>
      </tr>

      <td> 

    
     
      <button type="submit" class="btn btn-primary">Submit</button>
     
    <button type="button" class="btn btn-default"><a href="\chairman\scores">Cnacel</a>

    </td>


</tr>


  
    @endif
    @endforeach
      

  </tbody>
    

</table>
</form>
</div>
      </div>
       <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>
  

@endsection

@extends('layouts.app')

@section('content')

<div class="container">

  <div class="table-responsive">

  

<table class="table ">
 <h1>Platform Schedule</h1>
  <thead>
    <tr>
      <th>Student Name </th>
      <th>Department</th>
      <th>Category</th>
   
      
      <th>Room</th>
      <th>Time</th>
      <th>Ju1</th>
      <th>Ju2</th>
      <th>Ju3</th>
     

      
    </tr>
  </thead>
  
  <tbody>
  
      @foreach ($platformschedule as $slot)

    <tr>
 
	
	@foreach ( $approvedplatforms as $approvedplatform)

		@if($approvedplatform->id == $slot->approvedproposals_id)
		<td> {{$approvedplatform->name}}</td>

			@foreach ($departments as $department)
			@if ($department->id == $approvedplatform->department_id)
			<td>{{$department->name}}</td>
			@endif
			@endforeach

      @foreach ($categories as $category)
      @if ($category->id == $approvedplatform->category_id)
      <td>{{$category->name }}</td>
      @endif
      @endforeach
		@endif
    @endforeach


		 
     
      <td>{{$slot->room_code}}</td>
      <td>{{$slot->time}}</td>
      
      @foreach ($judgesname as $judgename)

      @if($slot->judge_one == $judgename->id)
      <td>{{$judgename->lname}}</td>
      @endif
      @endforeach

      @foreach ($judgesname as $judgename)

      @if($slot->judge_two == $judgename->id)
      <td>{{$judgename->lname}}</td>
      @endif
      @endforeach


      @foreach ($judgesname as $judgename)

      @if($slot->judge_three == $judgename->id)
      <td>{{$judgename->lname}}</td>
      @endif
      @endforeach
     

   

    </tr>

	@endforeach
  </tbody>

  




</table>
      </div>
      </div>
  
   <script src="https://code.jquery.com/jquery.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

      <script >
  
        $('div.alert').delay(3000).slideUp(300);

        $('a.links').click(function (e){
          e.preventDefault();
          var div_id = $('a.links').index($(this))
           $('.divs').hide().eq(div_id).show();
          });
        </script>

    

@endsection
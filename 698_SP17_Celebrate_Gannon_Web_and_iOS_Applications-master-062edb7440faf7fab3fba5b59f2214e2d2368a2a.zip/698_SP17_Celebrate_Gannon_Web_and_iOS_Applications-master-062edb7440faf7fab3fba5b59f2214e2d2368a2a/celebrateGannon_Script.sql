-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 21, 2017 at 09:20 PM
-- Server version: 5.7.17-0ubuntu0.16.04.1
-- PHP Version: 7.0.15-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `celebrateGannon_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `approvedproposals`
--

CREATE TABLE `approvedproposals` (
  `id` int(10) UNSIGNED NOT NULL,
  `department_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `proposal_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `approvedproposals`
--

INSERT INTO `approvedproposals` (`id`, `department_id`, `student_id`, `category_id`, `proposal_id`, `created_at`, `updated_at`) VALUES
(58, 6, 58, 4, 58, NULL, NULL),
(59, 7, 59, 4, 59, NULL, NULL),
(60, 8, 60, 4, 60, NULL, NULL),
(61, 9, 61, 4, 61, NULL, NULL),
(62, 10, 62, 4, 62, NULL, NULL),
(63, 7, 63, 4, 63, NULL, NULL),
(64, 7, 64, 4, 64, NULL, NULL),
(65, 11, 65, 4, 65, NULL, NULL),
(66, 12, 66, 4, 66, NULL, NULL),
(67, 9, 67, 4, 67, NULL, NULL),
(68, 7, 68, 4, 68, NULL, NULL),
(69, 10, 69, 4, 69, NULL, NULL),
(70, 8, 70, 4, 70, NULL, NULL),
(71, 10, 71, 4, 71, NULL, NULL),
(72, 10, 72, 4, 72, NULL, NULL),
(73, 10, 73, 4, 73, NULL, NULL),
(74, 7, 74, 4, 74, NULL, NULL),
(75, 10, 75, 4, 75, NULL, NULL),
(76, 10, 76, 4, 76, NULL, NULL),
(77, 13, 77, 4, 77, NULL, NULL),
(78, 7, 78, 4, 78, NULL, NULL),
(79, 9, 79, 4, 79, NULL, NULL),
(80, 7, 80, 4, 80, NULL, NULL),
(81, 14, 81, 4, 81, NULL, NULL),
(82, 7, 82, 4, 82, NULL, NULL),
(83, 15, 83, 1, 83, NULL, NULL),
(84, 15, 84, 1, 84, NULL, NULL),
(85, 16, 85, 1, 85, NULL, NULL),
(86, 16, 86, 1, 86, NULL, NULL),
(87, 15, 87, 1, 87, NULL, NULL),
(88, 15, 88, 1, 88, NULL, NULL),
(89, 15, 89, 1, 89, NULL, NULL),
(90, 6, 90, 1, 90, NULL, NULL),
(91, 6, 91, 1, 91, NULL, NULL),
(92, 17, 92, 1, 92, NULL, NULL),
(93, 43, 93, 1, 93, NULL, NULL),
(94, 13, 94, 1, 94, NULL, NULL),
(95, 13, 95, 1, 95, NULL, NULL),
(96, 13, 96, 1, 96, NULL, NULL),
(97, 13, 97, 1, 97, NULL, NULL),
(98, 13, 98, 1, 98, NULL, NULL),
(99, 13, 99, 1, 99, NULL, NULL),
(100, 15, 100, 1, 100, NULL, NULL),
(101, 6, 101, 1, 101, NULL, NULL),
(102, 13, 102, 1, 102, NULL, NULL),
(103, 13, 103, 1, 103, NULL, NULL),
(104, 13, 104, 1, 104, NULL, NULL),
(105, 13, 105, 1, 105, NULL, NULL),
(106, 18, 106, 1, 106, NULL, NULL),
(107, 19, 107, 1, 107, NULL, NULL),
(108, 13, 108, 1, 108, NULL, NULL),
(109, 13, 109, 1, 109, NULL, NULL),
(110, 19, 110, 1, 110, NULL, NULL),
(111, 13, 111, 1, 111, NULL, NULL),
(112, 17, 112, 1, 112, NULL, NULL),
(113, 17, 113, 1, 113, NULL, NULL),
(114, 15, 114, 1, 114, NULL, NULL),
(115, 20, 115, 1, 115, NULL, NULL),
(116, 21, 116, 1, 116, NULL, NULL),
(117, 13, 117, 1, 117, NULL, NULL),
(118, 13, 118, 1, 118, NULL, NULL),
(119, 13, 119, 1, 119, NULL, NULL),
(120, 13, 120, 1, 120, NULL, NULL),
(121, 13, 121, 1, 121, NULL, NULL),
(122, 22, 122, 1, 122, NULL, NULL),
(123, 27, 123, 1, 123, NULL, NULL),
(124, 23, 124, 1, 124, NULL, NULL),
(125, 23, 125, 1, 125, NULL, NULL),
(126, 23, 126, 1, 126, NULL, NULL),
(127, 23, 127, 4, 127, NULL, NULL),
(128, 24, 128, 2, 128, NULL, NULL),
(129, 25, 129, 2, 129, NULL, NULL),
(130, 25, 130, 2, 130, NULL, NULL),
(131, 25, 131, 2, 131, NULL, NULL),
(132, 25, 132, 2, 132, NULL, NULL),
(133, 25, 133, 2, 133, NULL, NULL),
(134, 15, 134, 2, 134, NULL, NULL),
(135, 26, 135, 2, 135, NULL, NULL),
(137, 27, 137, 2, 137, NULL, NULL),
(138, 24, 138, 2, 138, NULL, NULL),
(139, 25, 139, 2, 139, NULL, NULL),
(140, 28, 140, 2, 140, NULL, NULL),
(141, 25, 141, 2, 141, NULL, NULL),
(142, 25, 142, 2, 142, NULL, NULL),
(143, 27, 143, 2, 143, NULL, NULL),
(144, 27, 144, 2, 144, NULL, NULL),
(145, 25, 145, 2, 145, NULL, NULL),
(146, 15, 146, 2, 146, NULL, NULL),
(147, 29, 147, 2, 147, NULL, NULL),
(148, 27, 148, 2, 148, NULL, NULL),
(149, 27, 149, 2, 149, NULL, NULL),
(150, 27, 150, 2, 150, NULL, NULL),
(151, 29, 151, 2, 151, NULL, NULL),
(152, 29, 152, 2, 152, NULL, NULL),
(153, 29, 153, 3, 153, NULL, NULL),
(154, 30, 154, 3, 154, NULL, NULL),
(155, 29, 155, 3, 155, NULL, NULL),
(156, 29, 156, 3, 156, NULL, NULL),
(157, 29, 157, 3, 157, NULL, NULL),
(158, 29, 158, 3, 158, NULL, NULL),
(159, 29, 159, 3, 159, NULL, NULL),
(160, 31, 160, 3, 160, NULL, NULL),
(161, 31, 161, 3, 161, NULL, NULL),
(162, 31, 162, 3, 162, NULL, NULL),
(163, 27, 163, 3, 163, NULL, NULL),
(164, 27, 164, 3, 164, NULL, NULL),
(165, 32, 165, 5, 165, NULL, NULL),
(166, 33, 166, 5, 166, NULL, NULL),
(167, 34, 167, 5, 167, NULL, NULL),
(168, 34, 168, 5, 168, NULL, NULL),
(169, 35, 169, 5, 169, NULL, NULL),
(170, 34, 170, 5, 170, NULL, NULL),
(171, 44, 171, 5, 171, NULL, NULL),
(172, 35, 172, 5, 172, NULL, NULL),
(173, 34, 173, 5, 173, NULL, NULL),
(174, 36, 174, 5, 174, NULL, NULL),
(175, 36, 175, 5, 175, NULL, NULL),
(176, 36, 176, 5, 176, NULL, NULL),
(177, 36, 177, 5, 177, NULL, NULL),
(178, 29, 178, 5, 178, NULL, NULL),
(179, 34, 179, 5, 179, NULL, NULL),
(180, 37, 180, 5, 180, NULL, NULL),
(181, 32, 181, 5, 181, NULL, NULL),
(182, 29, 182, 5, 182, NULL, NULL),
(183, 34, 183, 5, 183, NULL, NULL),
(184, 38, 184, 5, 184, NULL, NULL),
(185, 39, 185, 5, 185, NULL, NULL),
(186, 32, 186, 5, 186, NULL, NULL),
(187, 40, 187, 5, 187, NULL, NULL),
(188, 41, 188, 5, 188, NULL, NULL),
(189, 34, 189, 5, 189, NULL, NULL),
(190, 38, 190, 5, 190, NULL, NULL),
(191, 38, 191, 5, 191, NULL, NULL),
(192, 7, 192, 6, 192, NULL, NULL),
(193, 32, 193, 6, 193, NULL, NULL),
(194, 8, 194, 6, 194, NULL, NULL),
(195, 38, 195, 6, 195, NULL, NULL),
(196, 42, 196, 7, 196, NULL, NULL),
(197, 29, 197, 7, 197, NULL, NULL),
(198, 29, 198, 7, 198, NULL, NULL),
(199, 29, 199, 7, 199, NULL, NULL),
(200, 29, 200, 7, 200, NULL, NULL),
(201, 29, 201, 7, 201, NULL, NULL),
(202, 29, 202, 7, 202, NULL, NULL),
(203, 29, 203, 7, 203, NULL, NULL),
(204, 29, 204, 7, 204, NULL, NULL),
(207, 1, 207, 1, 207, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Undergraduate Research', NULL, NULL, NULL),
(2, 'Undergraduate Scholarship', NULL, NULL, NULL),
(3, 'Graduate Scholarship', NULL, NULL, NULL),
(4, 'Graduate Research', NULL, NULL, NULL),
(5, 'Undergraduate Engagement', NULL, NULL, NULL),
(6, 'Graduate Engagement', NULL, NULL, NULL),
(7, 'Fine Arts', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_coordinator`
--

CREATE TABLE `category_coordinator` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `coordinator_id` int(10) UNSIGNED NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category_coordinator`
--

INSERT INTO `category_coordinator` (`id`, `category_id`, `coordinator_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(11, 1, 4, NULL, NULL, NULL),
(12, 3, 4, NULL, NULL, NULL),
(13, 4, 4, NULL, NULL, NULL),
(14, 1, 32, NULL, NULL, NULL),
(15, 2, 32, NULL, NULL, NULL),
(16, 3, 32, NULL, NULL, NULL),
(17, 4, 32, NULL, NULL, NULL),
(18, 5, 32, NULL, NULL, NULL),
(19, 6, 32, NULL, NULL, NULL),
(20, 7, 32, NULL, NULL, NULL),
(21, 1, 34, NULL, NULL, NULL),
(25, 4, 5, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Engineering', NULL, NULL, NULL),
(2, 'Adminstration', NULL, NULL, NULL),
(3, 'Since', NULL, NULL, NULL),
(4, 'Arts', NULL, NULL, NULL),
(5, 'Religion', NULL, NULL, NULL),
(6, 'Mechanical Engineering', NULL, NULL, NULL),
(7, 'OT', NULL, NULL, NULL),
(8, 'PT', NULL, NULL, NULL),
(9, 'Computer and Information Science', NULL, NULL, NULL),
(10, 'OTD', NULL, NULL, NULL),
(11, 'PT/Biomed Engineering', NULL, NULL, NULL),
(12, 'Sport and Exercise', NULL, NULL, NULL),
(13, 'Biomedical Engineering', NULL, NULL, NULL),
(14, 'MBA', NULL, NULL, NULL),
(15, 'biology', NULL, NULL, NULL),
(16, 'psychology', NULL, NULL, NULL),
(17, 'chemistry', NULL, NULL, NULL),
(18, 'electrical and computer enginneering/bio/physics', NULL, NULL, NULL),
(19, 'Mechanical and Biomedical Engineering ', NULL, NULL, NULL),
(20, 'electrical and biomedical engineering', NULL, NULL, NULL),
(21, 'biomedical engineering and biology', NULL, NULL, NULL),
(22, 'math', NULL, NULL, NULL),
(23, 'CJ', NULL, NULL, NULL),
(24, 'Comm. & Fine Arts', NULL, NULL, NULL),
(25, 'History', NULL, NULL, NULL),
(26, 'Finance', NULL, NULL, NULL),
(27, 'Philosophy', NULL, NULL, NULL),
(28, 'Social Work', NULL, NULL, NULL),
(29, 'English', NULL, NULL, NULL),
(30, 'Occupational Therapy', NULL, NULL, NULL),
(31, 'M. in Athletic Training', NULL, NULL, NULL),
(32, 'Business', NULL, NULL, NULL),
(33, 'School of Ed', NULL, NULL, NULL),
(34, 'CSC: ABST', NULL, NULL, NULL),
(35, 'CSC', NULL, NULL, NULL),
(36, 'SEECS', NULL, NULL, NULL),
(37, 'Theology: CST Immersion', NULL, NULL, NULL),
(38, 'University Wellness', NULL, NULL, NULL),
(39, 'Morosky', NULL, NULL, NULL),
(40, 'Accounting', NULL, NULL, NULL),
(41, 'Nursing', NULL, NULL, NULL),
(42, 'School of Communication and The Arts', NULL, NULL, NULL),
(43, 'biomedical and mechanical engineering', NULL, NULL, NULL),
(44, 'Student Government Association', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `eventtimes`
--

CREATE TABLE `eventtimes` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `first` tinyint(1) NOT NULL DEFAULT '1',
  `second` tinyint(1) NOT NULL DEFAULT '1',
  `third` tinyint(1) NOT NULL DEFAULT '1',
  `fourth` tinyint(1) NOT NULL DEFAULT '1',
  `fifth` tinyint(1) NOT NULL DEFAULT '1',
  `sixth` tinyint(1) NOT NULL DEFAULT '1',
  `seventh` tinyint(1) NOT NULL DEFAULT '1',
  `eighth` tinyint(1) NOT NULL DEFAULT '1',
  `ninth` tinyint(1) NOT NULL DEFAULT '1',
  `tenth` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eventtime_judge`
--

CREATE TABLE `eventtime_judge` (
  `id` int(10) UNSIGNED NOT NULL,
  `eventtime_id` int(10) UNSIGNED NOT NULL,
  `judge_id` int(10) UNSIGNED NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `finalgrades`
--

CREATE TABLE `finalgrades` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `department_id` int(10) UNSIGNED DEFAULT NULL,
  `student_id` int(10) UNSIGNED DEFAULT NULL,
  `average` double DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2013_01_15_232852_creat_categories_table', 1),
(2, '2013_01_15_232949_departments', 1),
(3, '2014_10_12_000000_create_users_table', 1),
(4, '2014_10_12_100000_create_password_resets_table', 1),
(5, '2017_01_15_232949_creat_students_table', 1),
(6, '2017_01_16_010731_creat_proposals_table', 1),
(7, '2017_01_17_044556_platformscoresheets', 1),
(8, '2017_01_17_044615_posterscoresheets', 1),
(9, '2017_01_18_175854_create_approvedproposals_table', 1),
(10, '2017_01_18_223905_create_eventTime_table', 1),
(11, '2017_01_18_235654_create_platformSchedule_table', 1),
(12, '2017_01_18_235801_create_posterSchedule_table', 1),
(13, '2017_01_19_082649_create_room_table', 1),
(14, '2017_01_21_155250_create_category_coordinator_table', 1),
(15, '2017_01_21_155849_create_eventtime_judge_table', 1),
(16, '2017_02_05_165441_create_finalGrades_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `platformSchedule`
--

CREATE TABLE `platformSchedule` (
  `id` int(10) UNSIGNED NOT NULL,
  `approvedproposals_id` int(10) UNSIGNED DEFAULT NULL,
  `room_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `eventtimes_id` int(10) UNSIGNED DEFAULT NULL,
  `judge_one` int(10) UNSIGNED DEFAULT NULL,
  `judge_two` int(10) UNSIGNED DEFAULT NULL,
  `judge_three` int(10) UNSIGNED DEFAULT NULL,
  `time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `platformSchedule`
--

INSERT INTO `platformSchedule` (`id`, `approvedproposals_id`, `room_code`, `eventtimes_id`, `judge_one`, `judge_two`, `judge_three`, `time`) VALUES
(1, 90, '', NULL, 38, 10, 0, '2:30'),
(2, 58, '', NULL, 67, 10, 0, '2:30'),
(3, 91, '', NULL, 38, 10, 0, '2:45'),
(4, 68, '', NULL, 44, 42, 0, ''),
(5, 59, '', NULL, 44, 42, 0, ''),
(6, 64, '', NULL, 44, 42, 0, ''),
(7, 192, '', NULL, 44, 42, 0, ''),
(8, 63, '', NULL, 44, 42, 0, ''),
(9, 60, '', NULL, 67, 10, 0, '2:45'),
(10, 67, '', NULL, 67, 10, 0, '2:15'),
(11, 61, '', NULL, 67, 10, 0, '2:00'),
(12, 62, '', NULL, 44, 42, 0, ''),
(13, 65, '', NULL, 67, 10, 0, '3:00'),
(14, 66, '', NULL, 67, 10, 0, '3:15'),
(15, 88, '', NULL, 38, 10, 0, '2:00'),
(16, 134, '', NULL, 40, 10, 0, '2:00'),
(17, 113, '', NULL, 38, 10, 0, '2:15'),
(18, 138, '', NULL, 40, 10, 0, '2:45'),
(19, 128, '', NULL, 40, 10, 0, '3:15'),
(20, 133, '', NULL, 44, 42, 0, ''),
(21, 130, '', NULL, 44, 42, 0, ''),
(22, 139, '', NULL, 40, 10, 0, '3:00'),
(23, 132, '', NULL, 44, 42, 0, ''),
(24, 129, '', NULL, 44, 42, 0, ''),
(25, 131, '', NULL, 44, 42, 0, ''),
(26, 135, '', NULL, 40, 10, 0, '2:15'),
(27, 137, '', NULL, 40, 10, 0, '2:30'),
(28, 140, '', NULL, 40, 10, 0, '3:15'),
(29, 203, '', NULL, 44, 42, 0, ''),
(30, 158, '', NULL, 44, 42, 0, ''),
(31, 155, '', NULL, 44, 42, 0, ''),
(32, 200, '', NULL, 44, 42, 0, ''),
(33, 197, '', NULL, 44, 42, 0, ''),
(34, 202, '', NULL, 44, 42, 0, ''),
(35, 157, '', NULL, 44, 42, 0, ''),
(36, 199, '', NULL, 44, 42, 0, ''),
(37, 159, '', NULL, 44, 42, 0, ''),
(38, 204, '', NULL, 44, 42, 0, ''),
(39, 156, '', NULL, 44, 42, 0, ''),
(40, 201, '', NULL, 44, 42, 0, ''),
(41, 153, '', NULL, 44, 42, 0, ''),
(42, 198, '', NULL, 44, 42, 0, ''),
(43, 154, '', NULL, 44, 42, 0, ''),
(44, 165, '', NULL, 44, 42, 0, ''),
(45, 166, '', NULL, 44, 42, 0, ''),
(46, 173, '', NULL, 44, 42, 0, ''),
(47, 170, '', NULL, 44, 42, 0, ''),
(48, 167, '', NULL, 44, 42, 0, ''),
(49, 168, '', NULL, 44, 42, 0, ''),
(50, 172, '', NULL, 44, 42, 0, ''),
(51, 169, '', NULL, 44, 42, 0, ''),
(52, 196, '', NULL, 44, 42, 0, ''),
(53, 171, '', NULL, 44, 42, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `platformscoresheets`
--

CREATE TABLE `platformscoresheets` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED DEFAULT NULL,
  `judge_id` int(10) UNSIGNED DEFAULT NULL,
  `fineart` tinyint(1) NOT NULL DEFAULT '0',
  `criteria_one` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_one_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_two` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_two_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_three` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_three_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_four` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_four_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_five` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_five_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_six` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_six_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_seven` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_seven_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `general_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `experience` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `platformscoresheets`
--

INSERT INTO `platformscoresheets` (`id`, `student_id`, `judge_id`, `fineart`, `criteria_one`, `criteria_one_comment`, `criteria_two`, `criteria_two_comment`, `criteria_three`, `criteria_three_comment`, `criteria_four`, `criteria_four_comment`, `criteria_five`, `criteria_five_comment`, `criteria_six`, `criteria_six_comment`, `criteria_seven`, `criteria_seven_comment`, `general_comment`, `experience`, `total`, `remember_token`, `created_at`, `updated_at`) VALUES
(160, 90, 38, 0, '12', '', '8', '', '8', '', '35', '', '8', '', '10', '', '10', '', '', 'area of my experties', '91', NULL, NULL, NULL),
(161, 90, 10, 0, '9', NULL, '8', NULL, '6', NULL, '0', NULL, '8', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '51', NULL, NULL, NULL),
(163, 58, 67, 0, '15', '', '10', '', '8', '', '21', '', '8', '', '8', '', '0', '', '', 'expert in allied field', '70', NULL, NULL, NULL),
(164, 58, 10, 0, '9', NULL, '4', NULL, '2', NULL, '0', NULL, '4', NULL, '4', NULL, '4', NULL, NULL, 'Area of my experties', '27', NULL, NULL, NULL),
(166, 91, 38, 0, '15', '', '10', '', '8', '', '35', '', '10', '', '10', '', '10', '', '', 'area of my experties', '98', NULL, NULL, NULL),
(167, 91, 10, 0, '15', NULL, '6', NULL, '6', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '57', NULL, NULL, NULL),
(169, 68, 44, 0, '15', NULL, '8', NULL, '8', NULL, '0', NULL, '10', NULL, '10', NULL, '8', NULL, NULL, 'Area of my experties', '59', NULL, NULL, NULL),
(170, 68, 42, 0, '12', NULL, '8', NULL, '8', NULL, '0', NULL, '8', NULL, '10', NULL, '4', NULL, NULL, 'Area of my experties', '50', NULL, NULL, NULL),
(172, 59, 44, 0, '15', NULL, '10', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '8', NULL, NULL, 'Area of my experties', '63', NULL, NULL, NULL),
(173, 59, 42, 0, '12', NULL, '6', NULL, '10', NULL, '0', NULL, '6', NULL, '10', NULL, '8', NULL, NULL, 'Area of my experties', '52', NULL, NULL, NULL),
(175, 64, 44, 0, '12', NULL, '8', NULL, '10', NULL, '0', NULL, '8', NULL, '10', NULL, '4', NULL, NULL, 'Area of my experties', '52', NULL, NULL, NULL),
(176, 64, 42, 0, '12', NULL, '6', NULL, '6', NULL, '0', NULL, '6', NULL, '6', NULL, '6', NULL, NULL, 'Area of my experties', '42', NULL, NULL, NULL),
(178, 192, 44, 0, '15', NULL, '8', NULL, '8', NULL, '0', NULL, '8', NULL, '8', NULL, '10', NULL, NULL, 'Area of my experties', '57', NULL, NULL, NULL),
(179, 192, 42, 0, '12', NULL, '8', NULL, '10', NULL, '0', NULL, '8', NULL, '10', NULL, '4', NULL, NULL, 'Area of my experties', '52', NULL, NULL, NULL),
(181, 63, 44, 0, '15', NULL, '8', NULL, '10', NULL, '0', NULL, '8', NULL, '8', NULL, '10', NULL, NULL, 'Area of my experties', '59', NULL, NULL, NULL),
(182, 63, 42, 0, '15', NULL, '8', NULL, '10', NULL, '0', NULL, '8', NULL, '10', NULL, '8', NULL, NULL, 'Area of my experties', '59', NULL, NULL, NULL),
(184, 60, 67, 0, '12', '', '8', '', '4', '', '21', '', '10', '', '10', '', '0', '', 'The presentation is right on time.', 'not my area', '65', NULL, NULL, NULL),
(185, 60, 10, 0, '6', NULL, '2', NULL, '4', NULL, '0', NULL, '4', NULL, '4', NULL, '4', NULL, NULL, 'Area of my experties', '24', NULL, NULL, NULL),
(187, 67, 67, 0, '9', '', '8', '', '6', '', '21', '', '8', '', '6', '', '6', '', 'the slides are too wordy.', 'expert in allied field', '64', NULL, NULL, NULL),
(188, 67, 10, 0, '9', NULL, '6', NULL, '6', NULL, '0', NULL, '8', NULL, '10', NULL, '6', NULL, NULL, 'Area of my experties', '45', NULL, NULL, NULL),
(190, 61, 67, 0, '12', '', '8', '', '8', '', '21', '', '10', '', '10', '', '8', '', 'slides are not very professional for example using dark background with dark font color which makes hard to read.', 'expert in allied field', '77', NULL, NULL, NULL),
(191, 61, 10, 0, '12', NULL, '8', NULL, '6', NULL, '0', NULL, '8', NULL, '10', NULL, '8', NULL, NULL, 'Area of my experties', '52', NULL, NULL, NULL),
(196, 65, 67, 0, '15', '', '10', '', '10', '', '28', '', '10', '', '10', '', '10', '', '', 'expert in allied field', '93', NULL, NULL, NULL),
(197, 65, 10, 0, '6', NULL, '4', NULL, '4', NULL, '0', NULL, '4', NULL, '2', NULL, '4', NULL, NULL, 'Area of my experties', '24', NULL, NULL, NULL),
(199, 66, 67, 0, '15', '', '8', '', '8', '', '28', '', '10', '', '8', '', '10', '', '', 'not my area', '87', NULL, NULL, NULL),
(200, 66, 10, 0, '6', NULL, '4', NULL, '4', NULL, '0', NULL, '4', NULL, '2', NULL, '4', NULL, NULL, 'Area of my experties', '24', NULL, NULL, NULL),
(202, 88, 38, 0, '15', '', '10', '', '8', '', '35', '', '6', '', '8', '', '8', '', '', 'expert in allied field', '90', NULL, NULL, NULL),
(203, 88, 10, 0, '15', NULL, '6', NULL, '6', NULL, '0', NULL, '10', NULL, '10', NULL, '6', NULL, NULL, 'Area of my experties', '53', NULL, NULL, NULL),
(205, 134, 40, 0, '12', 'Easy to follow', '8', 'Strong speaking skills', '8', 'Good powerpoint, easy to follow', '28', 'This was not on my paper rubric', '10', '', '10', '', '8', 'Very good answers', 'A great presentation. Very clearly organized and well presented.', 'not my area', '84', NULL, NULL, NULL),
(206, 134, 10, 0, '15', NULL, '6', NULL, '8', NULL, '0', NULL, '8', NULL, '10', NULL, '8', NULL, NULL, 'Area of my experties', '55', NULL, NULL, NULL),
(208, 113, 38, 0, '15', '', '10', '', '10', '', '35', '', '10', '', '10', '', '10', '', '', 'area of my experties', '100', NULL, NULL, NULL),
(209, 113, 10, 0, '15', NULL, '8', NULL, '10', NULL, '0', NULL, '10', NULL, '8', NULL, '10', NULL, NULL, 'Area of my experties', '61', NULL, NULL, NULL),
(211, 138, 40, 0, '12', '', '10', '', '10', '', '21', '', '8', 'Avoid colloquial lanaguage', '10', '', '8', '', 'Good job overall', 'area of my experties', '79', NULL, NULL, NULL),
(212, 138, 10, 0, '15', NULL, '10', NULL, '8', NULL, '0', NULL, '8', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '61', NULL, NULL, NULL),
(214, 128, 40, 0, '12', 'good overall', '6', 'A little polish needed', '8', 'Good overall', '35', '', '6', 'try to avoid colloquial lanaguage', '8', '', '8', '', 'Great job overall. Some presenters stronger than others. Ideas and content were very interesting.', 'area of my experties', '83', NULL, NULL, NULL),
(215, 128, 10, 0, '12', NULL, '8', NULL, '10', NULL, '0', NULL, '10', NULL, '8', NULL, '10', NULL, NULL, 'Area of my experties', '58', NULL, NULL, NULL),
(217, 133, 44, 0, '15', NULL, '8', NULL, '10', NULL, '35', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '98', NULL, NULL, NULL),
(218, 133, 42, 0, '15', NULL, '8', NULL, '10', NULL, '35', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '98', NULL, NULL, NULL),
(220, 130, 44, 0, '9', NULL, '6', NULL, '10', NULL, '21', NULL, '8', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '74', NULL, NULL, NULL),
(221, 130, 42, 0, '12', NULL, '8', NULL, '8', NULL, '35', NULL, '10', NULL, '8', NULL, '10', NULL, NULL, 'Area of my experties', '91', NULL, NULL, NULL),
(223, 139, 40, 0, '9', 'Generally easy to follow, needed stronger conclusion', '8', 'Good overall, a little polish needed', '6', 'Could have included more content, not just pictures', '21', 'A little hard to figure out main point', '8', '', '8', '', '6', 'Brief responses to questions but ok overall', '', 'not my area', '66', NULL, NULL, NULL),
(224, 139, 10, 0, '9', NULL, '10', NULL, '6', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '55', NULL, NULL, NULL),
(226, 132, 44, 0, '15', NULL, '10', NULL, '10', NULL, '35', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '100', NULL, NULL, NULL),
(227, 132, 42, 0, '12', NULL, '10', NULL, '10', NULL, '35', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '97', NULL, NULL, NULL),
(229, 129, 44, 0, '12', NULL, '8', NULL, '8', NULL, '35', NULL, '6', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '89', NULL, NULL, NULL),
(230, 129, 42, 0, '12', NULL, '6', NULL, '8', NULL, '21', NULL, '10', NULL, '10', NULL, '8', NULL, NULL, 'Area of my experties', '75', NULL, NULL, NULL),
(232, 131, 44, 0, '12', NULL, '6', NULL, '8', NULL, '35', NULL, '8', NULL, '10', NULL, '8', NULL, NULL, 'Area of my experties', '87', NULL, NULL, NULL),
(233, 131, 42, 0, '9', NULL, '4', NULL, '8', NULL, '28', NULL, '8', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '77', NULL, NULL, NULL),
(235, 135, 40, 0, '9', '', '8', 'Some of the presenters were excellent, others needed a bit more polish', '6', 'Some of the charts were hard to read', '35', 'This was not on my paper rubric', '8', '', '8', '', '8', 'Answers need to be more clear and concise', 'Presenters clearly knew what they were talking about but the presentation was a little unorganized. Great content, needs better structure and some polish in delivery.', 'not my area', '82', NULL, NULL, NULL),
(236, 135, 10, 0, '15', NULL, '8', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '63', NULL, NULL, NULL),
(238, 137, 40, 0, '6', 'great content but hard to follow', '6', 'watch your body langauage and don\'t lean on podium', '6', 'Use all of your powerpoint, don\'t skip so many slides', '28', 'This was not on my paper rubric', '8', 'good', '6', 'good, try not to be too informal', '6', 'Reponse to question was better and more clear than some of the presentation', 'Some great ideas but needed stronger structure and clear thesis statement.', 'not my area', '66', NULL, NULL, NULL),
(239, 137, 10, 0, '6', NULL, '6', NULL, '4', NULL, '0', NULL, '10', NULL, '8', NULL, '6', NULL, NULL, 'Area of my experties', '40', NULL, NULL, NULL),
(241, 140, 40, 0, '9', 'Hard to find thesis, main point', '8', 'good', '6', 'Good overall', '28', '', '10', '', '10', '', '10', '', 'Overall a very strong presentation. Presenters were well prepared and knowledgeable.', 'expert in allied field', '81', NULL, NULL, NULL),
(242, 140, 10, 0, '15', NULL, '8', NULL, '8', NULL, '0', NULL, '10', NULL, '8', NULL, '10', NULL, NULL, 'Area of my experties', '59', NULL, NULL, NULL),
(247, 158, 44, 0, '15', NULL, '6', NULL, '6', NULL, '0', NULL, '8', NULL, '10', NULL, '6', NULL, NULL, 'Area of my experties', '51', NULL, NULL, NULL),
(248, 158, 42, 0, '15', NULL, '10', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '65', NULL, NULL, NULL),
(250, 155, 44, 0, '9', NULL, '6', NULL, '6', NULL, '0', NULL, '10', NULL, '10', NULL, '6', NULL, NULL, 'Area of my experties', '47', NULL, NULL, NULL),
(251, 155, 42, 0, '12', NULL, '6', NULL, '8', NULL, '0', NULL, '8', NULL, '8', NULL, '6', NULL, NULL, 'Area of my experties', '48', NULL, NULL, NULL),
(262, 157, 44, 0, '15', NULL, '8', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '63', NULL, NULL, NULL),
(263, 157, 42, 0, '12', NULL, '4', NULL, '8', NULL, '35', NULL, '10', NULL, '10', NULL, '6', NULL, NULL, 'Area of my experties', '85', NULL, NULL, NULL),
(268, 159, 44, 0, '15', NULL, '10', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '65', NULL, NULL, NULL),
(269, 159, 42, 0, '12', NULL, '10', NULL, '10', NULL, '0', NULL, '8', NULL, '6', NULL, '6', NULL, NULL, 'Area of my experties', '52', NULL, NULL, NULL),
(274, 156, 44, 0, '15', NULL, '10', NULL, '10', NULL, '0', NULL, '8', NULL, '8', NULL, '10', NULL, NULL, 'Area of my experties', '61', NULL, NULL, NULL),
(275, 156, 42, 0, '12', NULL, '6', NULL, '8', NULL, '0', NULL, '8', NULL, '8', NULL, '8', NULL, NULL, 'Area of my experties', '50', NULL, NULL, NULL),
(280, 153, 44, 0, '15', NULL, '10', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '65', NULL, NULL, NULL),
(281, 153, 42, 0, '9', NULL, '10', NULL, '10', NULL, '0', NULL, '8', NULL, '10', NULL, '6', NULL, NULL, 'Area of my experties', '53', NULL, NULL, NULL),
(289, 165, 44, 0, '12', NULL, '8', NULL, '10', NULL, '0', NULL, '8', NULL, '8', NULL, '8', NULL, NULL, 'Area of my experties', '54', NULL, NULL, NULL),
(290, 165, 42, 0, '15', NULL, '8', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '63', NULL, NULL, NULL),
(292, 166, 44, 0, '12', NULL, '6', NULL, '10', NULL, '0', NULL, '8', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '56', NULL, NULL, NULL),
(293, 166, 42, 0, '12', NULL, '8', NULL, '6', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '56', NULL, NULL, NULL),
(295, 173, 44, 0, '12', NULL, '10', NULL, '8', NULL, '0', NULL, '10', NULL, '10', NULL, '8', NULL, NULL, 'Area of my experties', '58', NULL, NULL, NULL),
(296, 173, 42, 0, '12', NULL, '10', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '62', NULL, NULL, NULL),
(298, 170, 44, 0, '9', NULL, '6', NULL, '4', NULL, '0', NULL, '2', NULL, '6', NULL, '4', NULL, NULL, 'Area of my experties', '31', NULL, NULL, NULL),
(299, 170, 42, 0, '9', NULL, '8', NULL, '4', NULL, '0', NULL, '6', NULL, '4', NULL, '4', NULL, NULL, 'Area of my experties', '35', NULL, NULL, NULL),
(301, 167, 44, 0, '12', NULL, '8', NULL, '10', NULL, '0', NULL, '8', NULL, '8', NULL, '10', NULL, NULL, 'Area of my experties', '56', NULL, NULL, NULL),
(302, 167, 42, 0, '15', NULL, '10', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '65', NULL, NULL, NULL),
(307, 172, 44, 0, '12', NULL, '6', NULL, '6', NULL, '0', NULL, '6', NULL, '6', NULL, '6', NULL, NULL, 'Area of my experties', '42', NULL, NULL, NULL),
(308, 172, 42, 0, '12', NULL, '6', NULL, '6', NULL, '0', NULL, '6', NULL, '6', NULL, '6', NULL, NULL, 'Area of my experties', '42', NULL, NULL, NULL),
(310, 169, 44, 0, '12', NULL, '6', NULL, '6', NULL, '0', NULL, '6', NULL, '6', NULL, '0', NULL, NULL, 'Area of my experties', '36', NULL, NULL, NULL),
(311, 169, 42, 0, '12', NULL, '6', NULL, '6', NULL, '0', NULL, '6', NULL, '6', NULL, '0', NULL, NULL, 'Area of my experties', '36', NULL, NULL, NULL),
(316, 171, 44, 0, '12', NULL, '8', NULL, '8', NULL, '0', NULL, '8', NULL, '8', NULL, '8', NULL, NULL, 'Area of my experties', '52', NULL, NULL, NULL),
(317, 171, 42, 0, '15', NULL, '10', NULL, '10', NULL, '0', NULL, '10', NULL, '10', NULL, '10', NULL, NULL, 'Area of my experties', '65', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `posterSchedule`
--

CREATE TABLE `posterSchedule` (
  `id` int(10) UNSIGNED NOT NULL,
  `approvedproposals_id` int(10) UNSIGNED NOT NULL,
  `room_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `eventtimes_id` int(10) UNSIGNED DEFAULT NULL,
  `judge_one` int(10) UNSIGNED DEFAULT NULL,
  `judge_two` int(10) UNSIGNED DEFAULT NULL,
  `judge_three` int(10) UNSIGNED DEFAULT NULL,
  `time` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `posterSchedule`
--

INSERT INTO `posterSchedule` (`id`, `approvedproposals_id`, `room_code`, `eventtimes_id`, `judge_one`, `judge_two`, `judge_three`, `time`) VALUES
(1, 101, 'Hammermill Center', NULL, 57, 10, 11, '1:15'),
(2, 82, 'Hammermill Center', NULL, 10, 33, 0, ''),
(3, 78, 'Hammermill Center', NULL, 10, 11, 33, ''),
(4, 74, 'Hammermill Center', NULL, 56, 11, 0, '1:15'),
(5, 80, 'Hammermill Center', NULL, 33, 11, 0, ''),
(6, 194, 'Hammermill Center', NULL, 10, 33, 11, ''),
(7, 70, 'Hammermill Center', NULL, 33, 53, 0, ''),
(8, 79, 'Hammermill Center', NULL, 10, 33, 11, ''),
(9, 73, 'Hammermill Center', NULL, 10, 11, 33, ''),
(10, 76, 'Hammermill Center', NULL, 10, 11, 33, ''),
(11, 72, 'Hammermill Center', NULL, 11, 10, 33, ''),
(12, 69, 'Hammermill Center', NULL, 10, 11, 33, ''),
(13, 75, 'Hammermill Center', NULL, 10, 11, 33, ''),
(14, 71, 'Hammermill Center', NULL, 11, 10, 33, ''),
(15, 119, 'Hammermill Center', NULL, 10, 11, 33, ''),
(16, 108, 'Hammermill Center', NULL, 10, 33, 11, ''),
(17, 105, 'Hammermill Center', NULL, 11, 10, 33, ''),
(18, 102, 'Hammermill Center', NULL, 39, 11, 0, '1:15'),
(19, 99, 'Hammermill Center', NULL, 57, 56, 0, ''),
(20, 96, 'Hammermill Center', NULL, 56, 11, 0, '1:15'),
(21, 121, 'Hammermill Center', NULL, 53, 10, 11, '1:15'),
(22, 118, 'Hammermill Center', NULL, 53, 57, 0, '1:15'),
(23, 109, 'Hammermill Center', NULL, 10, 11, 33, ''),
(24, 104, 'Hammermill Center', NULL, 10, 33, 0, ''),
(25, 98, 'Hammermill Center', NULL, 11, 33, 10, ''),
(26, 95, 'Hammermill Center', NULL, 10, 11, 33, ''),
(27, 120, 'Hammermill Center', NULL, 11, 10, 33, '1:00'),
(28, 117, 'Hammermill Center', NULL, 57, 11, 0, '1:15'),
(29, 111, 'Hammermill Center', NULL, 33, 10, 11, ''),
(30, 103, 'Hammermill Center', NULL, 39, 11, 0, '1:30'),
(31, 97, 'Hammermill Center', NULL, 11, 33, 0, ''),
(32, 94, 'Hammermill Center', NULL, 33, 10, 11, ''),
(33, 77, 'Hammermill Center', NULL, 10, 33, 11, ''),
(34, 81, 'Hammermill Center', NULL, 33, 11, 0, ''),
(35, 146, 'Hammermill Center', NULL, 33, 10, 0, ''),
(36, 87, 'Hammermill Center', NULL, 10, 33, 11, ''),
(37, 84, 'Hammermill Center', NULL, 39, 10, 11, '1:00'),
(38, 114, 'Hammermill Center', NULL, 37, 10, 11, '1:00'),
(39, 89, 'Hammermill Center', NULL, 67, 11, 10, '1:15'),
(40, 83, 'Hammermill Center', NULL, 37, 39, 0, '1:00'),
(41, 100, 'Hammermill Center', NULL, 37, 67, 0, '1:00'),
(42, 85, 'Hammermill Center', NULL, 33, 10, 0, ''),
(43, 86, 'Hammermill Center', NULL, 10, 11, 33, ''),
(44, 112, 'Hammermill Center', NULL, 67, 11, 0, '1:00'),
(45, 92, 'Hammermill Center', NULL, 10, 33, 0, ''),
(46, 106, 'Hammermill Center', NULL, 56, 10, 11, '1:15'),
(47, 110, 'Hammermill Center', NULL, 10, 11, 33, ''),
(48, 107, 'Hammermill Center', NULL, 39, 67, 0, '1:15'),
(49, 115, 'Hammermill Center', NULL, 11, 33, 0, ''),
(50, 116, 'Hammermill Center', NULL, 10, 33, 0, ''),
(51, 122, 'Hammermill Center', NULL, 56, 11, 0, '1:00'),
(52, 124, 'Hammermill Center', NULL, 37, 11, 0, '1:30'),
(53, 127, 'Hammermill Center', NULL, 11, 10, 0, ''),
(54, 126, 'Hammermill Center', NULL, 10, 33, 11, ''),
(55, 125, 'Hammermill Center', NULL, 67, 11, 0, '1:00'),
(56, 142, 'Hammermill Center', NULL, 33, 10, 0, ''),
(57, 145, 'Hammermill Center', NULL, 10, 33, 0, ''),
(58, 141, 'Hammermill Center', NULL, 11, 33, 0, ''),
(59, 150, 'Hammermill Center', NULL, 10, 11, 0, ''),
(60, 144, 'Hammermill Center', NULL, 33, 10, 0, ''),
(61, 143, 'Hammermill Center', NULL, 11, 33, 0, ''),
(62, 149, 'Hammermill Center', NULL, 11, 10, 0, '1:15'),
(63, 164, 'Hammermill Center', NULL, 10, 33, 0, ''),
(64, 123, 'Hammermill Center', NULL, 10, 33, 0, ''),
(65, 148, 'Hammermill Center', NULL, 33, 10, 0, ''),
(66, 163, 'Hammermill Center', NULL, 33, 10, 0, ''),
(67, 147, 'Hammermill Center', NULL, 10, 11, 0, ''),
(68, 182, 'Hammermill Center', NULL, 33, 10, 0, ''),
(69, 152, 'Hammermill Center', NULL, 33, 10, 0, ''),
(70, 151, 'Hammermill Center', NULL, 33, 11, 10, ''),
(71, 178, 'Hammermill Center', NULL, 33, 11, 0, ''),
(72, 162, 'Hammermill Center', NULL, 33, 11, 0, ''),
(73, 161, 'Hammermill Center', NULL, 11, 33, 0, ''),
(74, 160, 'Hammermill Center', NULL, 10, 11, 0, ''),
(75, 193, 'Hammermill Center', NULL, 11, 10, 33, ''),
(76, 181, 'Hammermill Center', NULL, 33, 10, 0, ''),
(77, 186, 'Hammermill Center', NULL, 33, 11, 0, ''),
(78, 179, 'Hammermill Center', NULL, 33, 11, 0, ''),
(79, 189, 'Hammermill Center', NULL, 33, 11, 0, ''),
(80, 183, 'Hammermill Center', NULL, 10, 33, 11, ''),
(81, 176, 'Hammermill Center', NULL, 33, 10, 0, ''),
(82, 175, 'Hammermill Center', NULL, 11, 33, 0, ''),
(83, 177, 'Hammermill Center', NULL, 33, 10, 0, ''),
(84, 174, 'Hammermill Center', NULL, 10, 33, 11, ''),
(85, 180, 'Hammermill Center', NULL, 33, 10, 0, ''),
(86, 195, 'Hammermill Center', NULL, 11, 33, 10, ''),
(87, 191, 'Hammermill Center', NULL, 33, 10, 11, ''),
(88, 190, 'Hammermill Center', NULL, 33, 10, 0, ''),
(89, 184, 'Hammermill Center', NULL, 33, 11, 0, ''),
(90, 185, 'Hammermill Center', NULL, 33, 10, 0, ''),
(91, 187, 'Hammermill Center', NULL, 33, 10, 0, ''),
(92, 188, 'Hammermill Center', NULL, 10, 33, 0, ''),
(93, 93, 'Hammermill Center', NULL, 10, 11, 33, '');

-- --------------------------------------------------------

--
-- Table structure for table `posterscoresheets`
--

CREATE TABLE `posterscoresheets` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `judge_id` int(10) UNSIGNED NOT NULL,
  `fineart` tinyint(1) NOT NULL DEFAULT '0',
  `criteria_one` double DEFAULT NULL,
  `criteria_one_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_two` double DEFAULT NULL,
  `criteria_two_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_three` double DEFAULT NULL,
  `criteria_three_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_four` double DEFAULT NULL,
  `criteria_four_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_five` double DEFAULT NULL,
  `criteria_five_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `criteria_six` double DEFAULT NULL,
  `criteria_six_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `general_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `experience` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` double DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `posterscoresheets`
--

INSERT INTO `posterscoresheets` (`id`, `student_id`, `judge_id`, `fineart`, `criteria_one`, `criteria_one_comment`, `criteria_two`, `criteria_two_comment`, `criteria_three`, `criteria_three_comment`, `criteria_four`, `criteria_four_comment`, `criteria_five`, `criteria_five_comment`, `criteria_six`, `criteria_six_comment`, `general_comment`, `experience`, `total`, `remember_token`, `created_at`, `updated_at`) VALUES
(559, 101, 57, 0, 15, '', 15, '', 35, '', 10, '', 10, '', 9, '', '', 'not my area', 94, NULL, NULL, NULL),
(560, 101, 10, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 9, NULL, NULL, 'Area of my experties', 94, NULL, NULL, NULL),
(561, 101, 11, 0, 12, NULL, 15, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 83, NULL, NULL, NULL),
(568, 74, 56, 0, 9, NULL, 12, NULL, 28, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 82, NULL, NULL, NULL),
(569, 74, 11, 0, 12, NULL, 12, NULL, 28, NULL, 10, NULL, 6, NULL, 9, NULL, NULL, 'Area of my experties', 77, NULL, NULL, NULL),
(571, 80, 33, 0, 15, NULL, 12, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 97, NULL, NULL, NULL),
(572, 80, 11, 0, 12, NULL, 12, NULL, 35, NULL, 8, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 89, NULL, NULL, NULL),
(574, 194, 10, 0, 15, NULL, 15, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 93, NULL, NULL, NULL),
(576, 194, 11, 0, 12, NULL, 12, NULL, 21, NULL, 8, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 73, NULL, NULL, NULL),
(577, 70, 33, 0, 15, NULL, 15, NULL, 28, NULL, 10, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 88, NULL, NULL, NULL),
(578, 70, 53, 0, 9, NULL, 12, NULL, 28, NULL, 8, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 77, NULL, NULL, NULL),
(580, 79, 10, 0, 12, NULL, 3, NULL, 28, NULL, 6, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 74, NULL, NULL, NULL),
(581, 79, 33, 0, 9, '', 3, '', 21, 'I got it but it will be difficult to follow depending on the audience. ', 10, '', 10, '', 15, '', 'D T Mughal', 'not my area', 68, NULL, NULL, NULL),
(582, 79, 11, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(607, 105, 11, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 98, NULL, NULL, NULL),
(608, 105, 10, 0, 12, NULL, 12, NULL, 21, NULL, 8, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 73, NULL, NULL, NULL),
(610, 102, 39, 0, 12, NULL, 15, NULL, 28, NULL, 10, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 87, NULL, NULL, NULL),
(611, 102, 11, 0, 15, NULL, 15, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 93, NULL, NULL, NULL),
(613, 99, 57, 0, 9, '', 9, '', 21, '', 10, '', 10, '', 9, '', '', 'not my area', 68, NULL, NULL, NULL),
(614, 99, 56, 0, 9, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 9, NULL, NULL, 'Area of my experties', 68, NULL, NULL, NULL),
(616, 96, 56, 0, 15, NULL, 12, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 97, NULL, NULL, NULL),
(617, 96, 11, 0, 9, NULL, 9, NULL, 21, NULL, 8, NULL, 6, NULL, 9, NULL, NULL, 'Area of my experties', 62, NULL, NULL, NULL),
(619, 121, 53, 0, 12, '', 12, '', 28, '', 6, '', 2, 'not present', 3, '', 'on paper form gave a 0 for the last two categories since presenters were not present', 'expert in allied field', 63, NULL, NULL, NULL),
(620, 121, 10, 0, 15, NULL, 12, NULL, 28, NULL, 10, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 88, NULL, NULL, NULL),
(621, 121, 11, 0, 9, NULL, 3, NULL, 21, NULL, 2, NULL, 6, NULL, 3, NULL, NULL, 'Area of my experties', 44, NULL, NULL, NULL),
(622, 118, 53, 0, 15, '', 12, '', 28, '', 8, '', 2, 'not present', 3, '', 'on paper form gave a 0 for last two items, score should be -5 points', 'expert in allied field', 68, NULL, NULL, NULL),
(623, 118, 57, 0, 15, NULL, 12, NULL, 28, NULL, 8, NULL, 0, NULL, 0, NULL, NULL, 'Area of my experties', 63, NULL, NULL, NULL),
(625, 109, 10, 0, 9, NULL, 12, NULL, 28, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 82, NULL, NULL, NULL),
(626, 109, 11, 0, 12, NULL, 12, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 94, NULL, NULL, NULL),
(627, 109, 33, 0, 15, '', 12, '', 28, '', 10, '', 8, '', 12, '', 'Stroiney', 'not my area', 85, NULL, NULL, NULL),
(628, 104, 10, 0, 9, NULL, 9, NULL, 21, NULL, 8, NULL, 6, NULL, 9, NULL, NULL, 'Area of my experties', 62, NULL, NULL, NULL),
(631, 98, 11, 0, 12, NULL, 12, NULL, 21, NULL, 10, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 77, NULL, NULL, NULL),
(632, 98, 33, 0, 15, NULL, 12, NULL, 35, NULL, 10, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 92, NULL, NULL, NULL),
(633, 98, 10, 0, 15, NULL, 12, NULL, 35, NULL, 8, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 92, NULL, NULL, NULL),
(634, 95, 10, 0, 15, NULL, 15, NULL, 21, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 84, NULL, NULL, NULL),
(635, 95, 11, 0, 15, NULL, 12, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 90, NULL, NULL, NULL),
(640, 117, 57, 0, 9, '', 9, '', 21, '', 10, '', 10, '', 9, '', '', 'not my area', 68, NULL, NULL, NULL),
(641, 117, 11, 0, 9, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 9, NULL, NULL, 'Area of my experties', 68, NULL, NULL, NULL),
(643, 111, 33, 0, 9, NULL, 9, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 88, NULL, NULL, NULL),
(644, 111, 10, 0, 9, NULL, 6, NULL, 7, NULL, 10, NULL, 2, NULL, 3, NULL, NULL, 'Area of my experties', 37, NULL, NULL, NULL),
(645, 111, 11, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(646, 103, 39, 0, 15, NULL, 12, NULL, 28, NULL, 10, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 87, NULL, NULL, NULL),
(647, 103, 11, 0, 15, NULL, 12, NULL, 28, NULL, 8, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 83, NULL, NULL, NULL),
(649, 97, 11, 0, 12, NULL, 12, NULL, 28, NULL, 10, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 85, NULL, NULL, NULL),
(653, 94, 10, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(655, 77, 10, 0, 9, NULL, 12, NULL, 21, NULL, 4, NULL, 8, NULL, 9, NULL, NULL, 'Area of my experties', 63, NULL, NULL, NULL),
(657, 77, 11, 0, 12, NULL, 12, NULL, 35, NULL, 8, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 89, NULL, NULL, NULL),
(658, 81, 33, 0, 12, NULL, 12, NULL, 21, NULL, 8, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 76, NULL, NULL, NULL),
(659, 81, 11, 0, 12, NULL, 6, NULL, 35, NULL, 2, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 80, NULL, NULL, NULL),
(662, 146, 10, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(664, 87, 10, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(665, 87, 33, 0, 12, NULL, 12, NULL, 12, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 71, NULL, NULL, NULL),
(666, 87, 11, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(668, 84, 10, 0, 15, NULL, 15, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 93, NULL, NULL, NULL),
(669, 84, 11, 0, 12, NULL, 12, NULL, 35, NULL, 10, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 89, NULL, NULL, NULL),
(670, 114, 37, 0, 12, 'I was first person to view her poster; I asked a question that took her off her planned order and she had just a bit of trouble getting back.', 9, 'Tables very difficult to view. Some type of summary may have been better for a poster, but I have no experience with cell-level research--so a summary table may not be appropriate for this topic.', 35, 'Excellent work translating lab processes to a non-lab person.', 10, '', 10, '', 15, 'Excellent responses to my clinically-based questions. Excellent at clarifying words, steps when asked.', 'Chose allied field because I have certainly provided nursing care to many patients infected with this bacterium. This was my first exposure to the cellular aspects of the infection,  which provided insight as to its virulence.', 'expert in allied field', 91, NULL, NULL, NULL),
(671, 114, 10, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(672, 114, 11, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(674, 89, 11, 0, 15, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 80, NULL, NULL, NULL),
(675, 89, 10, 0, 15, NULL, 15, NULL, 28, NULL, 10, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 90, NULL, NULL, NULL),
(676, 83, 37, 0, 15, '', 15, 'Excellent choice of images, graphs, and tables. Arranged in a way that allowed multiple references to images as they explained content.', 35, 'Excellent conversation about potential clinical applications and cultural/religious objections to blood transfusion.', 10, '', 10, '', 15, 'Very impressed with trade-off between two presenters; clearly well-rehearsed without sounding rehearsed.', 'Chose allied field because of the eventual clinical application of the study.  Will be interesting to see where this research goes by next year\'s event. ', 'expert in allied field', 100, NULL, NULL, NULL),
(677, 83, 39, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 35, NULL, NULL, 'Area of my experties', 120, NULL, NULL, NULL),
(679, 100, 37, 0, 12, 'Why water/food sample data was on poster was not clear.', 15, '', 28, 'Wanted more information about extent of glyphosate use globally and in US.', 8, 'Needed to clarify tea-drinking definition; well done verbally but not expnot explicit on poster. ', 10, '', 12, 'Went very fast, skipped a lot of content on poster.', 'Chose not my area because, while related to health, this is not an area I have ever worked in or read about in the literature.', 'not my area', 85, NULL, NULL, NULL),
(680, 100, 67, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(682, 85, 33, 0, 15, NULL, 15, NULL, 35, NULL, 8, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 93, NULL, NULL, NULL),
(683, 85, 10, 0, 15, NULL, 12, NULL, 28, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 88, NULL, NULL, NULL),
(688, 112, 67, 0, 12, NULL, 12, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 87, NULL, NULL, NULL),
(689, 112, 11, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(691, 92, 10, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(692, 92, 33, 0, 15, NULL, 9, NULL, 35, NULL, 6, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 90, NULL, NULL, NULL),
(694, 106, 56, 0, 6, NULL, 6, NULL, 14, NULL, 4, NULL, 4, NULL, 6, NULL, NULL, 'Area of my experties', 40, NULL, NULL, NULL),
(695, 106, 10, 0, 12, NULL, 15, NULL, 21, NULL, 10, NULL, 10, NULL, 6, NULL, NULL, 'Area of my experties', 74, NULL, NULL, NULL),
(696, 106, 11, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(700, 107, 39, 0, 9, NULL, 12, NULL, 28, NULL, 10, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 81, NULL, NULL, NULL),
(703, 115, 11, 0, 12, NULL, 15, NULL, 35, NULL, 10, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 95, NULL, NULL, NULL),
(704, 115, 33, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(706, 116, 10, 0, 9, NULL, 9, NULL, 35, NULL, 14, NULL, 14, NULL, 15, NULL, NULL, 'Area of my experties', 96, NULL, NULL, NULL),
(707, 116, 33, 0, 15, NULL, 12, NULL, 35, NULL, 10, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 95, NULL, NULL, NULL),
(709, 122, 56, 0, 12, NULL, 15, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 83, NULL, NULL, NULL),
(710, 122, 11, 0, 9, NULL, 9, NULL, 21, NULL, 6, NULL, 6, NULL, 9, NULL, NULL, 'Area of my experties', 60, NULL, NULL, NULL),
(712, 124, 37, 0, 6, 'Poster does not include answer to the question about future locations of recycling centers. Some maps presented without explanations. ', 9, 'Overall, too little information is included.', 7, 'So, centers not within walking distance of high SES population--but this population also has easy access to transportation. Isn\'t it more important to be within walking distance for low SESSION? Also, what is contribution  of these specific items to total', 4, 'Typing errors noted.', 2, 'Presenters absent.', 3, 'Presenters absent.', 'Arrived just before 2:30; no students present.\r\n\r\nChose allied field as topic is relevant to public health.', 'expert in allied field', 31, NULL, NULL, NULL),
(713, 124, 11, 0, 9, NULL, 12, NULL, 21, NULL, 10, NULL, 10, NULL, 9, NULL, NULL, 'Area of my experties', 71, NULL, NULL, NULL),
(715, 127, 11, 0, 15, NULL, 12, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 97, NULL, NULL, NULL),
(716, 127, 10, 0, 15, NULL, 12, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 90, NULL, NULL, NULL),
(718, 126, 10, 0, 9, NULL, 3, NULL, 21, NULL, 10, NULL, 6, NULL, 9, NULL, NULL, 'Area of my experties', 58, NULL, NULL, NULL),
(719, 126, 33, 0, 12, NULL, 9, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 84, NULL, NULL, NULL),
(720, 126, 11, 0, 12, NULL, 9, NULL, 35, NULL, 6, NULL, 6, NULL, 15, NULL, NULL, 'Area of my experties', 83, NULL, NULL, NULL),
(721, 125, 67, 0, 9, NULL, 12, NULL, 21, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 75, NULL, NULL, NULL),
(722, 125, 11, 0, 15, NULL, 12, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 90, NULL, NULL, NULL),
(725, 142, 10, 0, 6, NULL, 6, NULL, 35, NULL, 4, NULL, 0, NULL, 0, NULL, NULL, 'Area of my experties', 51, NULL, NULL, NULL),
(730, 141, 11, 0, 9, NULL, 9, NULL, 21, NULL, 4, NULL, 4, NULL, 9, NULL, NULL, 'Area of my experties', 56, NULL, NULL, NULL),
(733, 150, 10, 0, 6, NULL, 12, NULL, 14, NULL, 6, NULL, 6, NULL, 9, NULL, NULL, 'Area of my experties', 53, NULL, NULL, NULL),
(734, 150, 11, 0, 6, NULL, 12, NULL, 14, NULL, 6, NULL, 6, NULL, 9, NULL, NULL, 'Area of my experties', 53, NULL, NULL, NULL),
(736, 144, 33, 0, 9, NULL, 12, NULL, 21, NULL, 10, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 74, NULL, NULL, NULL),
(737, 144, 10, 0, 12, NULL, 15, NULL, 28, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 88, NULL, NULL, NULL),
(739, 143, 11, 0, 9, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 74, NULL, NULL, NULL),
(740, 143, 33, 0, 9, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 9, NULL, NULL, 'Area of my experties', 88, NULL, NULL, NULL),
(742, 149, 11, 0, 15, NULL, 15, NULL, 35, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 98, NULL, NULL, NULL),
(743, 149, 10, 0, 15, NULL, 15, NULL, 28, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 91, NULL, NULL, NULL),
(745, 164, 10, 0, 9, NULL, 12, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 84, NULL, NULL, NULL),
(746, 164, 33, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(748, 123, 10, 0, 9, NULL, 9, NULL, 14, NULL, 8, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 62, NULL, NULL, NULL),
(751, 148, 33, 0, 15, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 100, NULL, NULL, NULL),
(752, 148, 10, 0, 15, NULL, 12, NULL, 21, NULL, 10, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 81, NULL, NULL, NULL),
(754, 163, 33, 0, 9, NULL, 9, NULL, 35, NULL, 4, NULL, 4, NULL, 9, NULL, NULL, 'Area of my experties', 70, NULL, NULL, NULL),
(755, 163, 10, 0, 15, NULL, 15, NULL, 21, NULL, 10, NULL, 10, NULL, 9, NULL, NULL, 'Area of my experties', 80, NULL, NULL, NULL),
(757, 147, 10, 0, 12, NULL, 12, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 94, NULL, NULL, NULL),
(758, 147, 11, 0, 15, NULL, 12, NULL, 35, NULL, 10, NULL, 10, NULL, 9, NULL, NULL, 'Area of my experties', 91, NULL, NULL, NULL),
(761, 182, 10, 0, 9, NULL, 9, NULL, 21, NULL, 6, NULL, 10, NULL, 9, NULL, NULL, 'Area of my experties', 64, NULL, NULL, NULL),
(764, 152, 10, 0, 9, NULL, 6, NULL, 35, NULL, 4, NULL, 4, NULL, 9, NULL, NULL, 'Area of my experties', 67, NULL, NULL, NULL),
(767, 151, 11, 0, 9, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 74, NULL, NULL, NULL),
(768, 151, 10, 0, 9, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 74, NULL, NULL, NULL),
(769, 178, 33, 0, 12, NULL, 6, NULL, 14, NULL, 6, NULL, 6, NULL, 12, NULL, NULL, 'Area of my experties', 56, NULL, NULL, NULL),
(770, 178, 11, 0, 9, NULL, 9, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 88, NULL, NULL, NULL),
(773, 162, 11, 0, 12, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 94, NULL, NULL, NULL),
(775, 161, 11, 0, 15, NULL, 15, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 93, NULL, NULL, NULL),
(781, 193, 11, 0, 12, NULL, 12, NULL, 35, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 92, NULL, NULL, NULL),
(782, 193, 10, 0, 9, NULL, 12, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 84, NULL, NULL, NULL),
(783, 193, 33, 0, 12, NULL, 9, NULL, 21, NULL, 8, NULL, 10, NULL, 12, NULL, NULL, 'Area of my experties', 72, NULL, NULL, NULL),
(784, 181, 33, 0, 15, '', 15, '', 28, '', 10, '', 10, '', 15, '', 'Wei', 'not my area', 93, NULL, NULL, NULL),
(785, 181, 10, 0, 15, NULL, 12, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 97, NULL, NULL, NULL),
(787, 186, 33, 0, 12, NULL, 15, NULL, 35, NULL, 12, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 99, NULL, NULL, NULL),
(788, 186, 11, 0, 9, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 74, NULL, NULL, NULL),
(790, 179, 33, 0, 12, '', 9, '', 28, '', 10, '', 10, '', 15, '', 'Wei', 'not my area', 84, NULL, NULL, NULL),
(791, 179, 11, 0, 15, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 80, NULL, NULL, NULL),
(794, 189, 11, 0, 15, NULL, 12, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 83, NULL, NULL, NULL),
(796, 183, 10, 0, 9, NULL, 9, NULL, 35, NULL, 4, NULL, 4, NULL, 9, NULL, NULL, 'Area of my experties', 70, NULL, NULL, NULL),
(797, 183, 33, 0, 15, NULL, 15, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 86, NULL, NULL, NULL),
(798, 183, 11, 0, 15, NULL, 12, NULL, 21, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 81, NULL, NULL, NULL),
(800, 176, 10, 0, 9, NULL, 9, NULL, 21, NULL, 6, NULL, 6, NULL, 15, NULL, NULL, 'Area of my experties', 66, NULL, NULL, NULL),
(802, 175, 11, 0, 9, NULL, 12, NULL, 28, NULL, 8, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 77, NULL, NULL, NULL),
(808, 174, 10, 0, 9, NULL, 12, NULL, 21, NULL, 8, NULL, 4, NULL, 9, NULL, NULL, 'Area of my experties', 63, NULL, NULL, NULL),
(809, 174, 33, 0, 12, NULL, 15, NULL, 21, NULL, 10, NULL, 6, NULL, 12, NULL, NULL, 'Area of my experties', 76, NULL, NULL, NULL),
(810, 174, 11, 0, 12, NULL, 12, NULL, 28, NULL, 6, NULL, 6, NULL, 12, NULL, NULL, 'Area of my experties', 76, NULL, NULL, NULL),
(811, 180, 33, 0, 15, NULL, 15, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 93, NULL, NULL, NULL),
(812, 180, 10, 0, 15, NULL, 9, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 87, NULL, NULL, NULL),
(814, 195, 11, 0, 15, NULL, 9, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 87, NULL, NULL, NULL),
(815, 195, 33, 0, 15, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 80, NULL, NULL, NULL),
(816, 195, 10, 0, 9, NULL, 9, NULL, 14, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 67, NULL, NULL, NULL),
(817, 191, 33, 0, 6, NULL, 9, NULL, 21, NULL, 10, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 69, NULL, NULL, NULL),
(818, 191, 10, 0, 15, NULL, 12, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 97, NULL, NULL, NULL),
(819, 191, 11, 0, 15, NULL, 15, NULL, 28, NULL, 8, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 91, NULL, NULL, NULL),
(820, 190, 33, 0, 15, NULL, 15, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 93, NULL, NULL, NULL),
(821, 190, 10, 0, 15, NULL, 12, NULL, 14, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 76, NULL, NULL, NULL),
(823, 184, 33, 0, 15, NULL, 15, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 86, NULL, NULL, NULL),
(824, 184, 11, 0, 12, NULL, 12, NULL, 28, NULL, 8, NULL, 8, NULL, 12, NULL, NULL, 'Area of my experties', 80, NULL, NULL, NULL),
(826, 185, 33, 0, 12, NULL, 12, NULL, 21, NULL, 10, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 78, NULL, NULL, NULL),
(827, 185, 10, 0, 6, NULL, 9, NULL, 21, NULL, 6, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 67, NULL, NULL, NULL),
(829, 187, 33, 0, 12, NULL, 12, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 80, NULL, NULL, NULL),
(830, 187, 10, 0, 15, NULL, 15, NULL, 28, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 93, NULL, NULL, NULL),
(832, 188, 10, 0, 9, NULL, 15, NULL, 35, NULL, 6, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 90, NULL, NULL, NULL),
(833, 188, 33, 0, 12, NULL, 9, NULL, 21, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 77, NULL, NULL, NULL),
(835, 93, 10, 0, 10, NULL, 15, NULL, 35, NULL, 10, NULL, 10, NULL, 15, NULL, NULL, 'Area of my experties', 95, NULL, NULL, NULL),
(836, 93, 11, 0, 15, NULL, 12, NULL, 28, NULL, 10, NULL, 8, NULL, 15, NULL, NULL, 'Area of my experties', 88, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `proposals`
--

CREATE TABLE `proposals` (
  `id` int(10) UNSIGNED NOT NULL,
  `department_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `advisors_names` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `advisor_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group_member_names` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notified` tinyint(1) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `proposals`
--

INSERT INTO `proposals` (`id`, `department_id`, `category_id`, `student_id`, `title`, `type`, `advisors_names`, `advisor_email`, `file`, `group_member_names`, `status`, `notified`, `remember_token`, `created_at`, `updated_at`) VALUES
(58, 6, 4, 58, 'Design and Fabrication of a universal gripper for children with special needs.', 'PL', 'Dr. Davide Piovesan', NULL, NULL, 'Vijaya Kumar', 'NR', 0, NULL, NULL, NULL),
(59, 7, 4, 59, 'Depression and Quality of Life in Early Onset versus Normal Onset Peope with Parkinson\'s Disease post Deep Brain Stimulation', 'PL', 'Dr. David LeVan', NULL, NULL, 'Ana Flores, Rada Maltseva, Emily Toothman, Jessica Viera-Posterli', 'NR', 0, NULL, NULL, NULL),
(60, 8, 4, 60, 'Improving Quality of Life and Decreasing Fall Risk: an Interdisciplinary Approach', 'PL', 'Julie Hartman', NULL, NULL, 'Michelle Zubasic, Ashley Frederickson', 'NR', 0, NULL, NULL, NULL),
(61, 9, 4, 61, 'Sentiment analysis of ISIS related Tweets using Absolute location Platform', 'PL', 'Sreela Sasi', NULL, NULL, 'Tarun B. Mirani', 'NR', 0, NULL, NULL, NULL),
(62, 10, 4, 62, 'Linking ICF and PCL5', 'PL', 'Kristin Valdes', NULL, NULL, 'Kristin Valdes', 'NR', 0, NULL, NULL, NULL),
(63, 7, 4, 63, 'The Effects of Kinesio Taping on the Recovery of College Athletes Following Shoulder Injuries', 'PL', 'Lynne Oberle', NULL, NULL, 'Brian Hendrickson, Matt Reasinger, Lauren Sherry, Phil Wilcox', 'NR', 0, NULL, NULL, NULL),
(64, 7, 4, 64, 'International Level 1 Fieldwork versus Domestic Level 1 Fieldwork', 'PL', 'Lynne Oberle', NULL, NULL, 'Amanda Rodenbucher, Abigail Wilson', 'NR', 0, NULL, NULL, NULL),
(65, 11, 4, 65, 'Reacher Alterations for the Arthritic and Gerontology Populations', 'PL', 'Anne Schmitz, Davide Piovesan, Julie Hartmann', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(66, 12, 4, 66, 'The Effect of a Short-Term Plyometric Training Intervention on Power and Strength Generation in Hockey Players', 'PL', 'Kory Stauffer, John Mosinski', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(67, 9, 4, 67, 'Knowledge Extraction from Unstructured and Structured Data', 'PL', 'Sreela Sasi', NULL, NULL, 'nonw', 'NR', 0, NULL, NULL, NULL),
(68, 7, 4, 68, 'The Effects of Yoga Intervention on the Memory and Attention of Children', 'PL', 'Jeffrey Boss', NULL, NULL, 'Bryan Rhines, Mary Stephens', 'NR', 0, NULL, NULL, NULL),
(69, 10, 4, 69, 'Medical adherence assessments for adolescents (ages 7-18 ): A systematic review', 'PO', 'Dianna Lunsford OTD, OTR/L CHT & Kristin Valdes, OTD, OTR/L CHT', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(70, 8, 4, 70, 'The relationship between scores on the Life Satifactin Questionnaire-9 and the Stroke Impact Scale item-6 in a sample of community dwellin individuals with chronic stroke or traumatic brain injury', 'PO', 'Beth Gustafson, PT, MSED', NULL, NULL, 'Shona Young, Rachel Meyer', 'NR', 0, NULL, NULL, NULL),
(71, 10, 4, 71, 'What is the experience of a volunteer at a therapeutic riding facility? A Qualitative Study', 'PO', 'John Connelly', NULL, NULL, 'Travis Darrow', 'NR', 0, NULL, NULL, NULL),
(72, 10, 4, 72, 'Identifying Occupations of Homeless Women', 'PO', 'Kristin Valdes, OTD, OT, CHT', NULL, NULL, 'Amy Flores', 'NR', 0, NULL, NULL, NULL),
(73, 10, 4, 73, 'What tools are used to assess cognition in pediatric cancer patients?', 'PO', 'Kristin Valdes, OTD, OT, CHT', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(74, 7, 4, 74, 'The Effects of Yoga on Sitting Posture During Classroom Curriculum', 'PO', 'Karen Probst', NULL, NULL, 'Erica Komanecky, Devan Lynn, Megan Vajda', 'NR', 0, NULL, NULL, NULL),
(75, 10, 4, 75, 'Parent Satifaction in Occupational Therapy Interventions', 'PO', 'Kristin Valdes, OTD, OT, CHT', NULL, NULL, 'Meghan Billick, ', 'NR', 0, NULL, NULL, NULL),
(76, 10, 4, 76, 'What is the experience of a gardening group for individuals with dementia: A qualitative study', 'PO', 'Kristin Valdes, OTD, OT, CHT', NULL, NULL, 'Carly Pollock', 'NR', 0, NULL, NULL, NULL),
(77, 13, 4, 77, 'Underwater Tracking System Based On Camera Space Manipulation: Static Calibration of Gorpro Cameras', 'PO', 'Davide Piovesan', NULL, NULL, 'Sabrina Rider, Felipe Martinez, Ann Schmitz', 'NR', 0, NULL, NULL, NULL),
(78, 7, 4, 78, 'Secondary traumatization of combat post-traumatic stress disorder from parent to child: A scoping review', 'PO', 'Kristin Valdes, OTD, OT, CHT, John Connelly', NULL, NULL, 'Heather L. Hinterberger', 'NR', 0, NULL, NULL, NULL),
(79, 9, 4, 79, 'Multi-Document Summarization and Sentiment Analysis of Web Reviews', 'PO', 'Sreela Sasi', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(80, 7, 4, 80, 'Adaptive Driving Equipment Compliance', 'PO', 'Amy Brzuz', NULL, NULL, 'Sara A. Elifritz, Abby Froman, Douglas J. Deak', 'NR', 0, NULL, NULL, NULL),
(81, 14, 4, 81, 'Switchgrass as a Bio-composite Plastic', 'PO', 'Dr. Bruce Kibler', NULL, NULL, 'Minh Anh Tran, Yidong Yuan', 'NR', 0, NULL, NULL, NULL),
(82, 7, 4, 82, 'Rest Break Interventions for Office Workers: A Systematic Review', 'PO', 'John Connelly', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(83, 15, 1, 83, 'HMA Induces Changes in the Nuclei and Mitochondria of BHK21 Cells in a Caspase3-Independent Manner', 'PO', 'Konieczko', NULL, NULL, ' DL Cambio*, S Goyal*, AM Granata*, NS Greisl*, KE Greissinger*, MJ Judy*, TL Koby*, A I Kruise*, P Maymand*, EA Peterson*, SE Schwartz*, MV Vadali*, ZC Murphy, M.S.', 'NR', 0, NULL, NULL, NULL),
(84, 15, 1, 84, 'The Role of Ent3p in Put4p Trafficking from the trans-Golgi Network to the Plasma membrane', 'PO', 'Aoh', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(85, 16, 1, 85, 'Perception of Straight vs. Gay Victims', 'PO', 'Caswell, Rosielle', NULL, NULL, 'Lillian Peterson', 'NR', 0, NULL, NULL, NULL),
(86, 16, 1, 86, 'The Impact of Media on Body Type Perception and Preference ', 'PO', 'Rosielle', NULL, NULL, 'Kylie Schoen', 'NR', 0, NULL, NULL, NULL),
(87, 15, 1, 87, 'The Role of SCAMP3 in Regulating CXCR4 Trafficking', 'PO', 'Aoh', NULL, NULL, ' Lillian Peterson', 'NR', 0, NULL, NULL, NULL),
(88, 15, 1, 88, 'A Census of the Bat Population on the Campus of Gannon University, Erie, Pennsylvania', 'PL', 'Ropski', NULL, NULL, 'Francesco Nati, Kylie Schoen', 'NR', 0, NULL, NULL, NULL),
(89, 15, 1, 89, 'A Small Mammal Population Census of the Habitat Islands at the Tom Ridge Environmental Center at Presque Isle State Park, Erie Pennsylvania', 'PO', 'Ropski', NULL, NULL, 'Erin Debelak', 'NR', 0, NULL, NULL, NULL),
(90, 6, 1, 90, 'Computational modeling of seasonal circulation patterns for Lake erie', 'PL', 'Gee', NULL, NULL, 'Mahboobe Mahdavi', 'NR', 0, NULL, NULL, NULL),
(91, 6, 1, 91, 'Control of thermal environment using solar power application', 'PL', 'Gee', NULL, NULL, 'Emmanuel Fale, Katie Besselman, Sabrina Kosnik', 'NR', 0, NULL, NULL, NULL),
(92, 17, 1, 92, 'Thermostability Analyses of Broad-Spectrum Antibiotics Cephalexin and Ciprofloxacin via Liquid Chromatography-Mass Spectrometry', 'PO', 'Heerboth', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(93, 43, 1, 93, 'Electroplating Additive Manufacturing Polymers for Biomedical Use', 'PO', 'Piovesan', NULL, NULL, 'Kristin Bates, Mubarak Alhammadi', 'NR', 0, NULL, NULL, NULL),
(94, 13, 1, 94, 'Bubble Size in Reference to Drug Delivery Device ', 'PO', 'Schmitz', NULL, NULL, 'Zachary J. Miller, Nicole L. Richards', 'NR', 0, NULL, NULL, NULL),
(95, 13, 1, 95, 'Limits of SLA Printers', 'PO', 'Schmitz', NULL, NULL, 'Olivia Rose, Rhea Bryan, Matthew Kehoe', 'NR', 0, NULL, NULL, NULL),
(96, 13, 1, 96, 'Testing the Hip Flexion Assist Device', 'PO', 'Schmitz', NULL, NULL, 'Madeline Carnell, Stacy Joseph', 'NR', 0, NULL, NULL, NULL),
(97, 13, 1, 97, 'Designing a Pharmaceutical Cooler', 'PO', 'Schmitz', NULL, NULL, 'G. Sutton, S. Alkhalifah', 'NR', 0, NULL, NULL, NULL),
(98, 13, 1, 98, 'Determining the Accuracy of Gannon’s SLA Printer', 'PO', 'Schmitz', NULL, NULL, 'A. Stahl, G. Sutton, C. Vollmer', 'NR', 0, NULL, NULL, NULL),
(99, 13, 1, 99, 'Accuracy of SLA 3D Printing', 'PO', 'Schmitz', NULL, NULL, 'G. McGrath, R. Red Horse, A. Albunayyih', 'NR', 0, NULL, NULL, NULL),
(100, 15, 1, 100, 'Presence of Glyphosate in Urine Samples', 'PO', 'Liu', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(101, 6, 1, 101, 'Human Powered Medicine Refrigerator', 'PO', 'Schmitz', NULL, NULL, 'T. Alshammari, and A. Alyahya', 'NR', 0, NULL, NULL, NULL),
(102, 13, 1, 102, 'Bicycle Powered Cooling System for Pharmaceuticals', 'PO', 'Schmitz', NULL, NULL, 'Stacy Joseph, Grace McGrath', 'NR', 0, NULL, NULL, NULL),
(103, 13, 1, 103, 'Modeling and Printing Anatomical Models to be used as a Tool for Visualization', 'PO', 'Schmitz', NULL, NULL, 'Brandon Lee, James Mardula', 'NR', 0, NULL, NULL, NULL),
(104, 13, 1, 104, 'Designing Coolers for Pharmaceutical Transportation', 'PO', 'Schmitz', NULL, NULL, 'T. Mahle', 'NR', 0, NULL, NULL, NULL),
(105, 13, 1, 105, 'Analyzing PMMA for Drug Delivery', 'PO', 'Schmitz', NULL, NULL, 'A. Alghanem, Hamido', 'NR', 0, NULL, NULL, NULL),
(106, 18, 1, 106, 'CHErenkov Radiator Payload System', 'PO', 'Lee/Conklin', NULL, NULL, ' T. Batjargal1, A. Ferrero1, S. Karpinsky1, M. MacKellar1, C. Miller1, J. Moukoro, L. Reilly2, D. Starks1, K. Wang', 'NR', 0, NULL, NULL, NULL),
(107, 19, 1, 107, 'Design of a Shoulder Rehabilitation Mechanism', 'PO', 'Piovesan', NULL, NULL, 'Jacob Gorton, William Hendrix, Alysia Klinger', 'NR', 0, NULL, NULL, NULL),
(108, 13, 1, 108, 'Design of a Thumb Strength Testing Unit', 'PO', 'Piovesan', NULL, NULL, 'Brandon Lee, James Mardula', 'NR', 0, NULL, NULL, NULL),
(109, 13, 1, 109, 'Modeling the Consequences of Rapid Warming in Hypothermia Patients', 'PO', 'Tiari', NULL, NULL, ' Brandon Lee, James Mardula', 'NR', 0, NULL, NULL, NULL),
(110, 19, 1, 110, 'Modeling of Heat Loss during Cryotherapy', 'PO', 'Tiari', NULL, NULL, ' Kristin E. Bates', 'NR', 0, NULL, NULL, NULL),
(111, 13, 1, 111, 'Thermally Controlled Insulin Pump', 'PO', 'Schmitz', NULL, NULL, 'Adam Mihalko, Alysia Klinger', 'NR', 0, NULL, NULL, NULL),
(112, 17, 1, 112, 'Effects of Ultrasound on the Digestive Enzyme Pepsin A', 'PO', 'Krise', NULL, NULL, 'Kapp, Rebecca L. Hetz, Steven H. Pham', 'NR', 0, NULL, NULL, NULL),
(113, 17, 1, 113, 'Using Electric Conductivity Measurements to Determine Concentration of Electrolytic Contaminants in Commercial Water-Soluble Polymers', 'PL', 'Krise', NULL, NULL, 'Dylan A. Michalski, Joshua J. Norman', 'NR', 0, NULL, NULL, NULL),
(114, 15, 1, 114, 'Population Frequency of Group I Pilin Producing Pseudomonas aeruginosa in Environmental Samples', 'PO', 'Allison', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(115, 20, 1, 115, 'M.A.R.I.O: Motor Actuated Robot with Integrated Orientation System', 'PO', 'Piovesan', NULL, NULL, ' Alexander Shaffer, Brandon Lawrence, Joshua Ott', 'NR', 0, NULL, NULL, NULL),
(116, 21, 1, 116, 'Examining the Effect of Gene Expression on Morphological Differences in the Bone, cb5, in Sunfish', 'PO', 'Andraso/Grant', NULL, NULL, 'Olivia Rose', 'NR', 0, NULL, NULL, NULL),
(117, 13, 1, 117, 'Underwater Tracking System', 'PO', 'Schmitz/Piovesan', NULL, NULL, ' Sabrina Rider, Felipe Martinez', 'NR', 0, NULL, NULL, NULL),
(118, 13, 1, 118, 'Human Motion Powered Portable Cooler', 'PO', 'Schmitz', NULL, NULL, 'Adel Albunayyih, Hussain Almaskeen', 'NR', 0, NULL, NULL, NULL),
(119, 13, 1, 119, 'LOCOMOTIVE UNDERACTUATED IMPLEMENT GUIDED VIA ELASTIC ELEMENTS (L.U.I.G.E.E): MOTORS PLACING AND ELASTOMERIC SPRINGS', 'PO', 'Piovesan', NULL, NULL, ' Stanley Coram', 'NR', 0, NULL, NULL, NULL),
(120, 13, 1, 120, 'MECHANICAL PROPERTY DETERMINATION OF A STEREOLITHOGRAPHIC RESIN SUBJECTED TO COMPRESSIVE LOADING', 'PO', 'Piovesan', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(121, 13, 1, 121, 'Effects of diaphragm expansion and contraction on refrigeration regulation', 'PO', 'Schmitz', NULL, NULL, 'Tharaa Hisham Bin Bunayyan, Rawan Alshammari', 'NR', 0, NULL, NULL, NULL),
(122, 22, 1, 122, 'An Anti - Waring Problem', 'PO', 'Prier', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(123, 27, 1, 123, 'Effect of Musical Key on Compliance', 'PO', 'Rosielle', NULL, NULL, 'Mackenzie Phillips, Megan Terwilliger', 'NR', 0, NULL, NULL, NULL),
(124, 23, 1, 124, 'Analysis of income, consumption, and accessibility of recycling centers in Erie, PA', 'PO', 'Chris Magno', NULL, NULL, 'D. Munoz', 'NR', 0, NULL, NULL, NULL),
(125, 23, 1, 125, 'Environmental Justice: Concentration of Hazardous Waste vs. Poverty Levels throughout Erie', 'PO', 'Chris Magno', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(126, 23, 1, 126, 'Map of Environmental Data (Snow and Precipitation) for Pennsylvania', 'PO', 'Chris Magno', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(127, 23, 4, 127, 'Walkability and Safety of Gannon Neighborhoods', 'PO', 'Chris Magno', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(128, 24, 2, 128, 'Agency B - Proposed Comprehensive Strategic Promotional Plan \\rfor Gannon Marketing Department\\r', 'PL', 'Anne O\'Neill', NULL, NULL, ' Lizzie Gauriloff, Kelli Kallenborn, Garret Smith, \\rAnne M. O’Neill', 'NR', 0, NULL, NULL, NULL),
(129, 25, 2, 129, 'Advancement of Fire Safety in Response to Industrialization', 'PL', 'Geoff Grundy', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(130, 25, 2, 130, 'Matriarchs of the Midwest…', 'PL', 'Geoff Grundy', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(131, 25, 2, 131, 'Norse Invasion of Scotland and its Surrounding Islands', 'PL', 'Geoff Grundy', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(132, 25, 2, 132, 'The Complicated Face of Anti-Semitism in 1930s Poland and the Evolution of Genocide Studies', 'PL', 'Geoff Grundy', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(133, 25, 2, 133, 'Boxing, Baseball, and Bridles: American Sports and the Great Depression', 'PL', 'Jeff Bloodworth', NULL, NULL, 'Jeff Bloodworth', 'NR', 0, NULL, NULL, NULL),
(134, 15, 2, 134, 'Determination of Heat Shock Proteins in Human Umbilical Veins Endothelial Cells Treated with PBDEs', 'PL', 'Mary Vagula', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(135, 26, 2, 135, 'CFA Institute Research Challenge: Parker Hannifin', 'PL', 'Richard P. Hauser', NULL, NULL, 'Ryan Morris, Jeremy Wagner, John Roberts', 'NR', 0, NULL, NULL, NULL),
(137, 27, 2, 137, 'Plato vs. Democracy; Philosophy Divided', 'PL', 'Dominic Prianti, Dr. Aaron Kerr', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(138, 24, 2, 138, 'Agency A - Proposed Comprehensive Strategic Promotional Plan for Gannon Marketing Department ', 'PL', 'Anne O\'Neill', NULL, NULL, 'Ellise Chase, Alizabeth Leng, Kate Pearson, Abby Zupan, Anne M. O’Neill', 'NR', 0, NULL, NULL, NULL),
(139, 25, 2, 139, 'The truth behind finding WMD’s in Iraq', 'PL', 'Geoff Grundy', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(140, 28, 2, 140, 'Depression Amongst the Elderly', 'PL', 'Sara Lichtenwalter', NULL, NULL, ' Joseph Mokwa', 'NR', 0, NULL, NULL, NULL),
(141, 25, 2, 141, 'Heroin in Kyrgyzstan', 'PO', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(142, 25, 2, 142, 'Afro-Surrealism: The Movement', 'PO', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(143, 27, 2, 143, 'Virtue and Freedom', 'PO', 'Dominic Prianti', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(144, 27, 2, 144, 'CONSCIENCE AND VIRTUE', 'PO', 'Dominic Prianti', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(145, 25, 2, 145, 'Tragedy in Venezula', 'PO', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(146, 15, 2, 146, 'Changes in Gene Expression Linked to Adverse Health Effects of Herbicide Atrazine', 'PO', 'He Liu', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(147, 29, 2, 147, 'Price of Clean Blood: The Legal Kidney Market in Iran', 'PO', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(148, 27, 2, 148, 'Tolkien about Ethics: The philosophy of The Lord of the Rings', 'PO', 'Dominic Prianti', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(149, 27, 2, 149, 'Virtue and Leadership', 'PO', 'Dominic Prianti', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(150, 27, 2, 150, 'Virtues and Climate Change', 'PO', 'Dominic Prianti', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(151, 29, 2, 151, 'The Economic of Chinese Marriage: Changes to the Economy', 'PO', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(152, 29, 2, 152, 'Racial Profiling’s Effect on Islamic Terrorism', 'PO', 'Jennie Vaughn', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(153, 29, 3, 153, 'Zora Neale Hurston: Laying a Foundation for African American English', 'PL', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(154, 30, 3, 154, 'The Effects of Yoga Intervention on the Memory and Attention of Children', 'PL', 'Jeffrey Boss', NULL, NULL, 'Bryan Rhines, Mary Stephens, Jeffrey Boss', 'NR', 0, NULL, NULL, NULL),
(155, 29, 3, 155, 'Short but Powerful: Exploring the Short Story with ZZ Packer’s “Every Tongue Shall Confess”', 'PL', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(156, 29, 3, 156, 'Looking for a POC Hero in Young Adult Fiction', 'PL', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(157, 29, 3, 157, 'Malcolm X & Black Lives Matter', 'PL', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(158, 29, 3, 158, 'Based on a True Story: Historical Veracity in Selma ', 'PL', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(159, 29, 3, 159, '“Where Pathways Meet”: Afrofuturism & African American Fantasy ', 'PL', 'Ann Bomberger', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(160, 31, 3, 160, 'Scapular Spine Fracture', 'PO', 'Rebecca Mokris, Trevor Hartless', NULL, NULL, 'Trevor Hartless, Rebecca Mokris', 'NR', 0, NULL, NULL, NULL),
(161, 31, 3, 161, '21-year-old Soccer Player with Osteochondramatosis: A Case Study', 'PO', 'Rebecca Mokris', NULL, NULL, 'Alissa Miller, Rebecca Mokris', 'NR', 0, NULL, NULL, NULL),
(162, 31, 3, 162, '', 'PO', 'Rebecca Mokris', NULL, NULL, 'Jessica Brunetti, Gary Hanna, Rebecca Mokris', 'NR', 0, NULL, NULL, NULL),
(163, 27, 3, 163, 'Development of Human Virtues and the Mind', 'PO', 'Dominic Prianti', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(164, 27, 3, 164, 'J.K. Rowling Regarding Ethics: Philosophical Insight into Harry Potter', 'PO', 'Dominic Prianti', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(165, 32, 5, 165, 'The Roman Catholic Diocese of Erie: Pastoral Planning Process', 'PL', 'Kalivoda Hersch Hauser Prokop', NULL, NULL, 'Celene Kalivoda, Kurt Hersch, Dr. Richard Hauser, Dr. Rick Prokop', 'NR', 0, NULL, NULL, NULL),
(166, 33, 5, 166, 'Harry Potter Learning Carnival', 'PL', 'Quick Morris', NULL, NULL, 'Dr. Robin Quick, Annelise Hatton, Mrs. Nancy Morris', 'NR', 0, NULL, NULL, NULL),
(167, 34, 5, 167, 'Just Haiti: Intimacy and Solidarity', 'PL', 'Bloodworth Perry Goble', NULL, NULL, 'Madelyn Zurinsky, Cytalia Crosby, Kishan Patel, S. Arron Shiffler, Kendra Walker, Jeff Bloodworth, Rebecca Perry', 'NR', 0, NULL, NULL, NULL),
(168, 34, 5, 168, 'ABST Merida, Yucatán, Mexico: Uno Mas', 'PL', 'Muntean Flores Hubert', NULL, NULL, 'Erin Lipnicky, Sam Griswold, Sara Crandall, Taylor Beggan, Lydia Fennessy, Alex Wood, Parth Shah, Erin Behe, Delaney McMellian', 'NR', 0, NULL, NULL, NULL),
(169, 35, 5, 169, ' “Open Hearts, Open Doors, Open Minds”', 'PL', 'Hubert', NULL, NULL, ' Korey MacIsaac, Jessie Badach-Hubert', 'NR', 0, NULL, NULL, NULL),
(170, 34, 5, 170, 'L’Arche Mexico ABST: Making our Own Lingua Franca', 'PL', 'Nesbitt Ranney Hubert', NULL, NULL, 'Nikhil Ananth, Daniela Alban, Sammy Taylor, Leigh Tischler, Jared Schaaf, John Ranney, and Sara Nesbitt', 'NR', 0, NULL, NULL, NULL),
(171, 44, 5, 171, 'Student Engagement Projects', 'PL', 'Coustillac', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(172, 35, 5, 172, 'The ServeMore Sophomore Experience', 'PL', 'Hubert', NULL, NULL, 'Brittney Callahan, Kassidy Deuber, Bethann Doyno, Hitham Hatatah, Samantha Lee, Hannah Murkens, Charles Stoll, Kendra Walker, Keisha Winger, Dacey Wohlford, Summer Young, Jessica Badach Hubert', 'NR', 0, NULL, NULL, NULL),
(173, 34, 5, 173, 'Reach Out: Alternative Break Service Trip to Guatemala', 'PL', 'Goble ', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(174, 36, 5, 174, 'Our West Bayfront: Adding Renewable Energy Charging Station to Bayview Park', 'PO', 'Vernaza Zhao', NULL, NULL, 'Nathaniel Dickinson2, Sarah Ingerick3, Sabrina Kosnik3, Alicia Massara3, Isaac Merrit4, Alexander Rafeew1, Sam Rubaker3, Charles Williams2, Karinna Vernaza, Lin Zhao', 'NR', 0, NULL, NULL, NULL),
(175, 36, 5, 175, 'Development and Design of a Medical Sterilizer for Mission Hospitals', 'PO', 'Vernaza Zhao', NULL, NULL, ' Anna Barr2, Jason Bensur3, Blake Dantio2, Leilani King3, Sabrina Rider3,4, Alexis Stahl4, Nicholas Williams3 and Dr. Karinna Vernaza3', 'NR', 0, NULL, NULL, NULL),
(176, 36, 5, 176, 'Designing Display Cases for Military Memorabilia', 'PO', 'Brinkman', NULL, NULL, 'Author C. Miller, Author E. Petrosky, Author J. Rullis, Author L. Wasielewski, Author M. Wieczorek, Author M. Yough, Barry Brinkman ', 'NR', 0, NULL, NULL, NULL),
(177, 36, 5, 177, 'Adapting Medical Sterilization Boiler Systems for Use in Developing Nations  ', 'PO', 'Zhao', NULL, NULL, 'Jacob Gorton, James Gruss, Michael Kibbe, Jennifer Moran, Marco Orlando, Thomas Roache, Lin Zhao, Ph.D.', 'NR', 0, NULL, NULL, NULL),
(178, 29, 5, 178, 'Community Partner Our West Bayfront Earth Day Festival Project', 'PO', 'Vaughn', NULL, NULL, 'Tyler Carnegie, Kelli Kallenborn, Dr. Jennie Vaughn', 'NR', 0, NULL, NULL, NULL),
(179, 34, 5, 179, 'Ruskin, FL: Empower, Inspire, Educate', 'PO', 'Nesbitt Allison Leute', NULL, NULL, 'Katie Getson, Karissa Jones, Rachel Loper, Lydia Archinal, Dacey Wohlford, BethAnn Doyno, Katie Allison, & JoAnn Leute ', 'NR', 0, NULL, NULL, NULL),
(180, 37, 5, 180, 'The Reality of Immokalee', 'PO', 'menkhaus', NULL, NULL, 'Kassidy Deuber, Caitlin Ebert, Nick Erbland, Brittany Grabowski, Allie Hepner, Alyssa Inman, Hannah Kitcey, Ashley Kruise, and Dr. Jimmy Menkhaus', 'NR', 0, NULL, NULL, NULL),
(181, 32, 5, 181, 'Sisters of Saint Joseph:  Cultivating Ongoing Relationships', 'PO', 'Hauser Prokop Kalivoda Hersch Wiest', NULL, NULL, 'Dr. Richard Hauser, Dr. Duane Prokop, Mrs. Celine Kalivoda, Mr. Kurt Hersch, Mrs. Betsy Wiest', 'NR', 0, NULL, NULL, NULL),
(182, 29, 5, 182, 'Westlake Middle School: Hairspray Musical', 'PO', 'Vaughn', NULL, NULL, 'Cynthia Cooney, Maria Hays, Dr. Vaughn', 'NR', 0, NULL, NULL, NULL),
(183, 34, 5, 183, 'Mission San Lucas Tolíman – Changing Hearts', 'PO', 'Goble Milliron', NULL, NULL, 'Deanna Peterson, Kelsey Milliron, Laura Goble', 'NR', 0, NULL, NULL, NULL),
(184, 38, 5, 184, 'Community Supported Agriculture', 'PO', 'Kolniak', NULL, NULL, 'Ashley Kolniak', 'NR', 0, NULL, NULL, NULL),
(185, 39, 5, 185, 'Health Professionals G.I.F.T.: Cultural Immersion in Jamaica', 'PO', 'Patterson Moreland Joy', NULL, NULL, 'Tierra L. Johnson, Leslie Konyha, Caitlyn Krolicki,  Abigail Martini, Siarra Shaw, Jordan Tunno, Mary Beth Moreland MSN, Kathleen T Patterson PhD, Cheryl Hettman PhD', 'NR', 0, NULL, NULL, NULL),
(186, 32, 5, 186, 'Just Haiti: Out of the Grey Haitian Coffee', 'PO', 'Kibler', NULL, NULL, ' Shelby Graml, Sean Hupp, Nasimah Ibr Shelby Shields,  Bruce Kibler', 'NR', 0, NULL, NULL, NULL),
(187, 40, 5, 187, 'VITA at Gannon: A Great Learning and Serving Experience', 'PO', 'Holmes Castrigano', NULL, NULL, ' Stephen P. Wagner, Atty. Terry S. Holmes, Dr. Renee Castrigano', 'NR', 0, NULL, NULL, NULL),
(188, 41, 5, 188, 'Cultural Immersion: Healthcare in India 2017', 'PO', 'Joy', NULL, NULL, 'Caryn Duman, Ian Edwards, Dana LaBrasca, Elizabeth Mechling, Nicole Morton, Aries Quintero, Lacey Rovnak, Ashley Sarlo, Abby Wu', 'NR', 0, NULL, NULL, NULL),
(189, 34, 5, 189, 'Say Nice Things About Detroit', 'PO', 'Magno Gray Hubert', NULL, NULL, 'Annmarie Rosa, Chris Magno, Crista Gray, Dean Meah, Hitham Hatatah, Jessica Miller, Jillian Gray, Julianna Mangano, Mariam Alkhafaji, Rachel Nye, Thomas Tripodis ', 'NR', 0, NULL, NULL, NULL),
(190, 38, 5, 190, 'Reaching Out: Wellness List Serve & Social Media', 'PO', 'Faulkner', NULL, NULL, 'Ashley Faulkner', 'NR', 0, NULL, NULL, NULL),
(191, 38, 5, 191, 'Celebrate Gannon: Active Workstations', 'PO', 'Faulkner MJ Taylor', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(192, 7, 6, 192, 'Moving to the Beat of Life: Using Dance and Music to Promote Positive Life Progression for Individuals on the Autism Spectrum ', 'PL', 'Hattjar', NULL, NULL, 'Corinna Ferry, Bridget Kleinhanz, Erin Korn, Carly Skonieczka, Bernadette Hattjar, Dr. OT, M. Ed., OTR/L, CWCE', 'NR', 0, NULL, NULL, NULL),
(193, 32, 6, 193, 'Let Solar Shine in Our Community', 'PO', 'Kibler', NULL, NULL, 'Xinyu Dong, Longtao Liu, Nivetha Pappuraj, Anjina Thapa, Carly VanTassel, and Dr. Bruce Kibler', 'NR', 0, NULL, NULL, NULL),
(194, 8, 6, 194, 'Yoga is for Everybody: Benefits of and process for developing an adaptive yoga program', 'PO', 'Gustafson', NULL, NULL, ' SPT, Beth Gustafson, PT, MSEd', 'NR', 0, NULL, NULL, NULL),
(195, 38, 6, 195, 'Club Fit Engagement: Realistically Significant', 'PO', 'MJ Taylor', NULL, NULL, 'Jessica Walsh-Frazier', 'NR', 0, NULL, NULL, NULL),
(196, 42, 7, 196, 'A Pursuit of Harmony and Balance - The Art of Rewriting Music for Performances', 'PL', 'Yih is a graduate student and director of and musician in the Pep Band.', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(197, 29, 7, 197, 'Square Hole Round Peg', 'PL', 'Berwyn Moore', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(198, 29, 7, 198, 'Eggplant', 'PL', 'Berwyn Moore', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(199, 29, 7, 199, 'Fridays with Frank', 'PL', 'Berwyn Moore', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(200, 29, 7, 200, 'Rave in the Redwoods', 'PL', 'Berwyn Moore', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(201, 29, 7, 201, 'For the Probably Killer of Edwin Drood', 'PL', 'Berwyn Moore', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(202, 29, 7, 202, 'On this Morning', 'PL', 'Berwyn Moore', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(203, 29, 7, 203, 'Anger\'s Journal ', 'PL', 'Berwyn Moore', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL),
(204, 29, 7, 204, 'Dear Future Me', 'PL', 'Carol Hayes', NULL, NULL, 'none', 'NR', 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(10) UNSIGNED NOT NULL,
  `room_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_code`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'zurn 123', NULL, NULL, NULL),
(2, 'R2', NULL, NULL, NULL),
(3, 'R3', NULL, NULL, NULL),
(4, 'R4', NULL, NULL, NULL),
(5, 'R5', NULL, NULL, NULL),
(6, 'R6', NULL, NULL, NULL),
(7, 'R7', NULL, NULL, NULL),
(8, 'R8', NULL, NULL, NULL),
(9, 'R9', NULL, NULL, NULL),
(10, 'R10', NULL, NULL, NULL),
(12, 'new room', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `universityId` double NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `email`, `universityId`, `remember_token`, `created_at`, `updated_at`) VALUES
(58, 'Ajay Kumar', 'vijayak001@knights.gannon.edu', 58, NULL, NULL, NULL),
(59, 'Stephanie Baltes', 'maltseva001@knights.gannon.edu', 59, NULL, NULL, NULL),
(60, 'Sammi Rosswog', 'frederic006@knights.gannon.edu', 60, NULL, NULL, NULL),
(61, 'Tarun B. Mirani', 'Mirani001@knights.gannon.edu', 61, NULL, NULL, NULL),
(62, 'Rae Garvison', 'garvison001@knights.gannon.edu', 62, NULL, NULL, NULL),
(63, 'Emily D\'Amore', 'filipows002@knights.gannon.edu', 63, NULL, NULL, NULL),
(64, 'Amanda Mahoney', 'mahoney012@knights.gannon.edu', 64, NULL, NULL, NULL),
(65, 'Scott Chapell', 'chappell003@knights.gannon.edu', 65, NULL, NULL, NULL),
(66, 'Brennan S. Clouner', 'clouner001@knights.gannon.edu', 66, NULL, NULL, NULL),
(67, 'Ashraf Mahlawi', 'mahlawi001@knights.gannon.edu', 67, NULL, NULL, NULL),
(68, 'Mary Carroll', 'vsttoll027@knights.gannon.edu', 68, NULL, NULL, NULL),
(69, 'Whitney Blankenship', 'blankens003@knights.gannon.edu', 69, NULL, NULL, NULL),
(70, 'Mackenzie Wilkins', 'wilkens004@knights.gannon.edu', 70, NULL, NULL, NULL),
(71, 'Rachel Smith', 'smith317@knights.gannon.edu', 71, NULL, NULL, NULL),
(72, 'Morgan Kirsch', 'philamle001@knights.gannon.edu', 72, NULL, NULL, NULL),
(73, 'Maria Tarbell', 'tarbell004@knights.gannon.edu', 73, NULL, NULL, NULL),
(74, 'Alyssa Jacobson', 'vajda002@knights.gannon.edu', 74, NULL, NULL, NULL),
(75, 'Caitlin Smith', 'smith314@knights.gannon.edu', 75, NULL, NULL, NULL),
(76, 'Jamie Scott', 'pollock008@knights.gannon.edu', 76, NULL, NULL, NULL),
(77, 'Lillian Blum', 'felipinmtz2@gmail.com', 77, NULL, NULL, NULL),
(78, 'Stephany L. Emerson', 'gorgei001@knights.gannon.edu', 78, NULL, NULL, NULL),
(79, 'Alaa Alsaquer', 'alsaqer002@knights.gannon.edu', 79, NULL, NULL, NULL),
(80, 'Katrina Nickerson', 'nickerso006@knights.gannon.edu', 80, NULL, NULL, NULL),
(81, 'Samantha Brueckner', 'brueckne001@knights.gannon.edu', 81, NULL, NULL, NULL),
(82, 'Sebastian Kazmierczak', 'kazmierc001@knights.gannon.edu', 82, NULL, NULL, NULL),
(83, 'BD Book', 'peterson042@knights.gannon.edu', 83, NULL, NULL, NULL),
(84, 'Gabbrielle Acosta', 'acosta006@knights.gannon.edu', 84, NULL, NULL, NULL),
(85, 'Katlyn Walters', 'peterson041@knights.gannon.edu', 85, NULL, NULL, NULL),
(86, 'Katie Miller', 'miller213@knights.gannon.edu', 86, NULL, NULL, NULL),
(87, 'Priscilla Thomas', 'thomas061@knights.gannon.edu', 87, NULL, NULL, NULL),
(88, 'Nick Bengal', 'bengal001@knights.gannon.edu', 88, NULL, NULL, NULL),
(89, 'Yasmine Mamani', 'mamani002@knights.gannon.edu', 89, NULL, NULL, NULL),
(90, 'Sabrina Rider', 'rider004@knights.gannon.edu', 90, NULL, NULL, NULL),
(91, 'David Albrecht', 'albrecht006@knights.gannon.edu', 91, NULL, NULL, NULL),
(92, 'Aerial Pratt', 'pratt008@knights.gannon.edu', 92, NULL, NULL, NULL),
(93, 'Adam Mihalko', 'mihalko001@knights.gannon.edu', 93, NULL, NULL, NULL),
(94, 'Benjamin A. Reed', 'reed033@knights.gannon.edu', 94, NULL, NULL, NULL),
(95, 'Madeline Carnell', 'carnell004@knights.gannon.edu', 95, NULL, NULL, NULL),
(96, 'Grace McGrath', 'carnell004@knights.gannon.edu', 96, NULL, NULL, NULL),
(97, 'E. Petrosky', 'sutton014@knights.gannon.edu', 97, NULL, NULL, NULL),
(98, 'S. Rider', 'sutton014@knights.gannon.edu', 98, NULL, NULL, NULL),
(99, 'S. Joseph', 'joseph018@knights.gannon.edu', 99, NULL, NULL, NULL),
(100, 'Joshuva John', 'john006@knights.gannon.edu', 100, NULL, NULL, NULL),
(101, 'R. Grubbs', 'grubbs003@knights.gannon.edu', 101, NULL, NULL, NULL),
(102, 'Madeline Carnell', 'carnell004@knights.gannon.edu', 102, NULL, NULL, NULL),
(103, 'Kristen Bates', 'mardula001@knights.gannon.edu', 103, NULL, NULL, NULL),
(104, 'M. Yough, C. Vollmer', 'yough001@knights.gannon.edu', 104, NULL, NULL, NULL),
(105, 'M. Yough, A. Alghanem', 'yough001@knights.gannon.edu', 105, NULL, NULL, NULL),
(106, 'K. Babiarz', 'reilly013@knights.gannon.edu', 106, NULL, NULL, NULL),
(107, 'Adam Archacki', 'gorton001@knights.gannon.edu', 107, NULL, NULL, NULL),
(108, 'Christian Fry', 'lee036@knights.gannon.edu', 108, NULL, NULL, NULL),
(109, 'Adam Archacki', 'lee036@knights.gannon.edu', 109, NULL, NULL, NULL),
(110, 'Zachary J. Miller', 'bates020@knights.gannon.edu', 110, NULL, NULL, NULL),
(111, 'Benjamin Reed', 'mihalko001@knights.gannon.edu', 111, NULL, NULL, NULL),
(112, 'Kathryn L. Kapp', 'kapp007@knights.gannon.edu', 112, NULL, NULL, NULL),
(113, 'Levi J. Kalka', 'kalka002@knights.gannon.edu', 113, NULL, NULL, NULL),
(114, 'Samantha Runser ', 'runser003@knights.gannon.edu', 114, NULL, NULL, NULL),
(115, 'Lanise Saunders', 'ott011@knights.gannon.edu', 115, NULL, NULL, NULL),
(116, 'Rebecca Red Horse', 'redhors001@knights.gannon.edu', 116, NULL, NULL, NULL),
(117, 'Lillian Blum', 'rider004@knights.gannon.edu', 117, NULL, NULL, NULL),
(118, 'Billy Colbert', 'colbert004@knights.gannon.edu', 118, NULL, NULL, NULL),
(119, 'Christian Fry', 'fry011@knights.gannon.edu', 119, NULL, NULL, NULL),
(120, 'Christian Fry', 'fry011@knights.gannon.edu', 120, NULL, NULL, NULL),
(121, 'Emmanuel Fale', 'fale001@knights.gannon.edu', 121, NULL, NULL, NULL),
(122, 'Paul Levan', 'levan006@knights.gannon.edu', 122, NULL, NULL, NULL),
(123, 'Amanda MacNeil', 'macneil001@knights.gannon.edu', 123, NULL, NULL, NULL),
(124, 'Holly Dill, D. Munoz', 'dill012@knights.gannon.edu', 124, NULL, NULL, NULL),
(125, 'Matthew Loughner', 'loughner002@knights.gannon.edu', 125, NULL, NULL, NULL),
(126, 'Jacob Norton', 'norton007@knights.gannon.edu', 126, NULL, NULL, NULL),
(127, 'Sandeep R Kasu', 'kasu002@knights.gannon.edu', 127, NULL, NULL, NULL),
(128, 'Grace Donner', 'donner001@knights.gannon.edu', 128, NULL, NULL, NULL),
(129, 'Nicholas Fuga', 'fuga001@knights.gannon.edu', 129, NULL, NULL, NULL),
(130, 'Madelyn Zurinsky', 'zurinsky001@knights.gannon.edu', 130, NULL, NULL, NULL),
(131, 'Valerie Prindle', 'prindle003@knights.gannon.edu', 131, NULL, NULL, NULL),
(132, 'Nathan Venesky', 'venesky005@knights.gannon.edu', 132, NULL, NULL, NULL),
(133, 'Kate Robb', 'robb004@knights.gannon.edu ', 133, NULL, NULL, NULL),
(134, 'Austin Grist', 'grist001@knights.gannon.edu', 134, NULL, NULL, NULL),
(135, 'Michael S. Squeglia', 'squeglia007@knights.gannon.edu', 135, NULL, NULL, NULL),
(137, 'Kyle Rodewald', 'rodewald001@knights.gannon.edu', 137, NULL, NULL, NULL),
(138, 'Anwar Al Quraish', 'alqurais005@knights.gannon.edu', 138, NULL, NULL, NULL),
(139, 'Robert J. Helsey', 'helsley009@knights.gannon.edu', 139, NULL, NULL, NULL),
(140, 'Anna Swick', 'swick007@knights.gannon.edu', 140, NULL, NULL, NULL),
(141, 'Sabrina Kosnik', 'kosnik002@knights.gannon.edu', 141, NULL, NULL, NULL),
(142, 'Becky Schmidt', 'schmidt023@knights.gannon.edu', 142, NULL, NULL, NULL),
(143, 'Waylon Duncan', 'duncan012@knights.gannon.edu', 143, NULL, NULL, NULL),
(144, 'Anubondem Awungnkeng', 'manubondem@icloud.com', 144, NULL, NULL, NULL),
(145, 'Lydia Lukomski', 'lukomski002@knights.gannon.edu', 145, NULL, NULL, NULL),
(146, 'Anthony Concilla', 'concilla003@knights.gannon.edu', 146, NULL, NULL, NULL),
(147, 'Alex Stauff', 'conantst001@knights.gannon.edu', 147, NULL, NULL, NULL),
(148, 'Kevin Eggert', 'eggert001@knights.gannon.edu', 148, NULL, NULL, NULL),
(149, 'Joseph W. Tokasz', 'tokasz001@knights.gannon.edu', 149, NULL, NULL, NULL),
(150, 'Nasimah Ibrahim', 'ibrahim005@knights.gannon.edu', 150, NULL, NULL, NULL),
(151, 'Julianne Baraona', 'baraona001@knights.gannon.edu', 151, NULL, NULL, NULL),
(152, 'Eleni Vlachos', 'vlachos001@knights.gannon.edu', 152, NULL, NULL, NULL),
(153, 'Meagan McHugh', 'mchugh002@gannon.edu', 153, NULL, NULL, NULL),
(154, 'Mary Carroll', 'carroll027@knights.gannon.edu', 154, NULL, NULL, NULL),
(155, 'Taylor Roth', 'roth020@knights.gannon.edu', 155, NULL, NULL, NULL),
(156, 'Lindsay Brewster', 'brewster004@knights.gannon.edu', 156, NULL, NULL, NULL),
(157, 'Jake Murzynski', 'jmurz7676@gmail.com', 157, NULL, NULL, NULL),
(158, 'Jeanette Long', 'long034@knights.gannon.edu', 158, NULL, NULL, NULL),
(159, 'Stephen P. Craig', 'craig033@knights.gannon.edu ', 159, NULL, NULL, NULL),
(160, 'Stephanie Owens', 'owens018@knights.gannon.edu', 160, NULL, NULL, NULL),
(161, 'James Mostard-Smith', 'jmostard13@gmail.com', 161, NULL, NULL, NULL),
(162, 'Rebecca Straub', 'brunetti001@knights.gannon.edu', 162, NULL, NULL, NULL),
(163, 'Sarah Al-Asady ', 'alasady001@knights.gannon.edu', 163, NULL, NULL, NULL),
(164, 'Patrick Strycharz', 'strychar001@knights.gannon.edu', 164, NULL, NULL, NULL),
(165, 'Timothy Grunzel', 'grunzel001@knights.gannon.edu', 165, NULL, NULL, NULL),
(166, 'Clara Drake', 'hatton002@knights.gannon.edu', 166, NULL, NULL, NULL),
(167, 'Melia Gasbarre', 'gasbarre004@knights.gannon.edu', 167, NULL, NULL, NULL),
(168, 'Joe Tokasz', 'lipnicky001@knights.gannon.edu', 168, NULL, NULL, NULL),
(169, 'Lydia Archinal', 'macisaac004@knights.gannon.edu', 169, NULL, NULL, NULL),
(170, 'Zack Witt', 'tischler002@knights.gannon.edu', 170, NULL, NULL, NULL),
(171, 'Kendra Walker', 'walker054@knights.gannon.edu', 171, NULL, NULL, NULL),
(172, 'Daniela Alban', 'murkens001@knights.gannon.edu', 172, NULL, NULL, NULL),
(173, 'graml', 'graml003@knights.gannon.edu', 173, NULL, NULL, NULL),
(174, 'Chad Barrick', 'Massara001@knights.gannon.edu', 174, NULL, NULL, NULL),
(175, 'Kaitlyn Babiarz', 'barr018@knights.gannon.edu', 175, NULL, NULL, NULL),
(176, 'Author C. Devine', 'yough001@knights.gannon.edu', 176, NULL, NULL, NULL),
(177, 'Justin Albrethsen', 'gorton001@knights.gannon.edu', 177, NULL, NULL, NULL),
(178, 'Morgan Brundage', 'kallenbo002@knights.gannon.edu', 178, NULL, NULL, NULL),
(179, 'Katlyn Unger', 'doyno001@knights.gannon.edu', 179, NULL, NULL, NULL),
(180, 'Shawn Czerwinski', 'menkhaus001@knights.gannon.edu', 180, NULL, NULL, NULL),
(181, 'Taralyn Ishman', 'ishman003@knights.gannon.edu', 181, NULL, NULL, NULL),
(182, 'Kaylee Hartman', 'hartman009@knights.gannon.edu', 182, NULL, NULL, NULL),
(183, 'Brandon Feikles', 'feikles002@knights.gannon.edu', 183, NULL, NULL, NULL),
(184, 'Shelby Graml', 'graml003@knights.gannon.edu', 184, NULL, NULL, NULL),
(185, 'Ahmed Almaghrabi', 'johnson158@knights.gannon.edu', 185, NULL, NULL, NULL),
(186, 'Margaret Chido', 'graml003@knights.gannon.edu', 186, NULL, NULL, NULL),
(187, 'Bathiry A. Thera', 'thera001@knights.gannon.edu', 187, NULL, NULL, NULL),
(188, 'Elysha Chrzanowski', 'quintero001@knights.gannon.edu', 188, NULL, NULL, NULL),
(189, 'Amanda Granata', 'rosa003@knights.gannon.edu', 189, NULL, NULL, NULL),
(190, 'Maggie Rutkowski', 'rutkowsk007@knights.gannon.edu', 190, NULL, NULL, NULL),
(191, 'Cole Cable', 'cable003@knights.gannon.edu', 191, NULL, NULL, NULL),
(192, 'Alexa Archambeault', 'kleinhan002@knights.gannon.edu', 192, NULL, NULL, NULL),
(193, 'Caity Crawford', 'crawford023@knights.gannon.edu', 193, NULL, NULL, NULL),
(194, 'Miranda Bender', 'bender012@knights.gannon.edu', 194, NULL, NULL, NULL),
(195, 'Kaitlyn Falk', 'falk004@knights.gannon.edu', 195, NULL, NULL, NULL),
(196, 'Yih Tsao', 'tsao002@gannon.edu', 196, NULL, NULL, NULL),
(197, 'Leigh Tischler', 'tischler002@knights.gannon.edu ', 197, NULL, NULL, NULL),
(198, 'Yih Tsao', 'fulton004@knights.gannon.edu', 198, NULL, NULL, NULL),
(199, 'Leigh Tischler', 'ghering001@knights.gannon.edu', 199, NULL, NULL, NULL),
(200, 'Yih Tsao', 'hunter032@knights.gannon.edu', 200, NULL, NULL, NULL),
(201, 'Leigh Tischler', 'headley003@knights.gannon.edu', 201, NULL, NULL, NULL),
(202, 'Yih Tsao', 'wieczore@knights.gannon.edu', 202, NULL, NULL, NULL),
(203, 'Leigh Tischler', 'fagen001@knights.gannon.edu', 203, NULL, NULL, NULL),
(204, 'Yih Tsao', 'rankin008@knights.gannon.edu', 204, NULL, NULL, NULL),
(205, 'ahmed alanazi', 'ala@lal.com', 12111, NULL, NULL, NULL),
(207, 'omar', 'omar@mjjmm.com', 123123123, NULL, NULL, NULL),
(208, 'Ahmed', 'ahmed@hotmail.com', 123333838, NULL, NULL, NULL),
(209, 'ahmed', 'ahmed@hdotmail.com', 1111111111, NULL, NULL, NULL),
(210, 'ahmed', 'ajj@mfoofj.com', 545455454, NULL, NULL, NULL),
(211, 'Jessica Lynn', 'hartnett004@gannon.edu', 123456789, NULL, NULL, NULL),
(212, 'wael Jefry', 'waelaljefry@gmail.com', 3039445, NULL, NULL, NULL),
(214, 'dddddd', 'ddd@md.com', 1298290809, NULL, NULL, NULL),
(215, 'omar', 'omaf@mm.com', 123388383, NULL, NULL, NULL),
(216, 'shada8a', 'shada@da.com', 1222929292, NULL, NULL, NULL),
(219, 'saaed', 'saeed@saed.com', 1288288, NULL, NULL, NULL),
(220, 'Ahmed', 'ah@h.com', 12211, NULL, NULL, NULL),
(221, 'Gag', 'ggg@g.com', 119292828, NULL, NULL, NULL),
(222, 'saeed', 'sdd@dmc.om', 12292922, NULL, NULL, NULL),
(223, 'Ashraf Mahlawi', 'almohalwi22@hotmail.com', 304983201, NULL, NULL, NULL),
(224, 'Steph', 'aa@aa.com', 1234567800, NULL, NULL, NULL),
(225, 'Stephen Craig', 'scraig14@outlook.com', 231231231, NULL, NULL, NULL),
(226, 'saeed', 'saeed@mm.com', 12727272, NULL, NULL, NULL),
(228, 'jdhjkh', 'jhdjkhkj@jkh.com', 198989822, NULL, NULL, NULL),
(230, 'Steven Rowland', 'rowland005@knights.gannon.edu', 3042116, NULL, NULL, NULL),
(231, 'Grant Folgate', 'folgate001@knights.gannon.edu', 99119911, NULL, NULL, NULL),
(232, 'Kevin Kauffman', 'kauffman004@knights.gannon.edu', 529631, NULL, NULL, NULL),
(233, 'omar', 'omar.f.h.a.f@gmail.com', 305681601, NULL, NULL, NULL),
(234, 'Stephen Haywiser', 'haywiser001@knights.gannon.edu', 2811831, NULL, NULL, NULL),
(235, 'Stephen Yarnell', 'yarnell001@knights.gannon.edu', 3043616, NULL, NULL, NULL),
(236, 'Glenn', 'sweithel001@knights.gannon.edu', 304290701, NULL, NULL, NULL),
(237, 'Korey', 'shugerts003@knights.gannon.edu', 2869954, NULL, NULL, NULL),
(238, 'Ryan ', 'strauss002@knights.gannon.edu', 2870912, NULL, NULL, NULL),
(240, 'omar', 'omar@mm.com', 12277272772, NULL, NULL, NULL),
(241, 'arm001', 'arm001@knights.gannon.edu', 12345678, NULL, NULL, NULL),
(242, 'arm002', 'arm002@knights.gannon.edu', 12345679, NULL, NULL, NULL),
(244, 'abdullah', 'abdullah@gannon.com', 55454545, NULL, NULL, NULL),
(246, 'jdkjlk', 'jkjlkj@lkjkl.com', 5456564, NULL, NULL, NULL),
(253, 'fjfjj', 'lkjdkjlk@fk.com', 45646456, NULL, NULL, NULL),
(254, 'fkfjlkj', 'kjkkl@mm.com', 545456456, NULL, NULL, NULL),
(265, 'k;lk;k', 'klkl@hh.com', 544656, NULL, NULL, NULL),
(270, 'wael Jefry', 'jefry001@knights.gannon.edu', 30039445, NULL, NULL, NULL),
(271, 'Saad Alotaibi', 's-otb@hotmail.com', 305330801, NULL, NULL, NULL),
(272, 'ioj', 'oijmm@kdk.com', 1289829, NULL, NULL, NULL),
(273, 'Joe Smith', 'smith006@gannon.edu', 12344556, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `department_id` int(10) UNSIGNED NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `user_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `appPass` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`, `category_id`, `department_id`, `status`, `user_type`, `remember_token`, `created_at`, `updated_at`, `appPass`) VALUES
(4, 'Kate', 'MacPhedran', 'k@m.com', '$2y$10$2YVailF4kNuDksmzsHISMumtVLqlIZ07Lw4u9/zOgOx.67U5VIL4W', 1, 1, 0, 'Coordinator', 'AQnj9FvzHCJMNgNAnObsgZL0XRlEHXLvRbogJ2FPbJeC7tfgSQYSJxkLO5at', '2017-02-28 00:55:01', '2017-04-13 19:15:19', ''),
(5, 'Lisa', 'Quinn', 'l@q.com', '$2y$10$fhzq8V8IEHA99Ak/hL6NJ.kOspN5ryTKYdiZZjdB/Rafy4lYHQUe6', 1, 1, 0, 'Coordinator', 'OwnqzsKNw6sVciiFwSWhQif8MkkSX10gIpZoYhnMRbgvTbwD00DV8QOUPNcy', '2017-02-28 00:56:00', '2017-02-28 00:56:05', ''),
(6, 'Jessie', 'Hubert', 'j@h.com', '$2y$10$bjIiL3tJuGKyKRuepRxylu8qlyDtlxzuIw/HFxdptJF5z70yy6Ux6', 1, 1, 0, 'Coordinator', 'TLYZhyoXDi6bOhRkwKPiF1OyGrm2HCDVIgIXdXEDRqjkHCRTAEbxV9Y131mm', '2017-02-28 00:56:35', '2017-02-28 03:35:54', ''),
(7, 'Lori', 'Steadman', 'l@s.com', '$2y$10$p1idtu4WlCwCCpDk.O2FTOgxngY0gacURYavoQ1DcZ6Qe7PBUCKv.', 1, 1, 0, 'Coordinator', 'FODTtoCLzHQOCHWFCX4a03Ym5B6DzrE6wFirQlRHetSkS1fyslvlULfrgP4F', '2017-02-28 00:57:17', '2017-02-28 00:57:20', ''),
(8, 'Jax', 'Vadney', 'j@v.com', '$2y$10$alo.2chNKs.RJLTyBWwDLONFFqkUffUmisRKzTu7HBa1/O4deeYUS', 1, 1, 0, 'Coordinator', 'dswkRYjQ1T4sHA0E5hzIAgH76qbOkC44cs7RX1FL5XQ12CaiDpje86nFPUn2', '2017-02-28 00:57:54', '2017-02-28 00:57:57', ''),
(9, 'Carol', 'Hayes', 'c@h.com', '$2y$10$.6OcUCIiI0him3XniRQ3UOMcMBBcqS8J7VNKjcqPbB.jxkF/QP4Ym', 1, 1, 0, 'Coordinator', 'D4VYR4SRJNNcp5q6wAWmrCOQq9J7REsE77Vu3a87CtMuecAkOmRsygJgQe5S', '2017-02-28 00:58:27', '2017-03-29 16:45:04', ''),
(10, 'ju1', 'ju1', 'j1@ju.com', '$2y$10$ltO/NBP5BKTlCu9p.BIg/OOjQhmBnNNG8/.AYqvBodshy4gOfRA0O', 1, 1, 0, 'Judge', '49ES6S6e2n7jgYBGBCTcGDWruXEPoUcokuqkIzv2qgLfJzXMsK7f4yZCgPTu', '2017-03-01 20:12:29', '2017-04-21 21:08:36', ''),
(11, 'ju2', 'ju2', 'j2@ju.com', '$2y$10$jpSReJ5ewSZ8bKJj.Uc60uqDR32i0SREWO4pFZ8Jq5of8smSJsjPa', 1, 1, 1, 'Judge', 'm3fgdk2tPewc6dbSJU1o9dTQobOwChan9K1i5I2rm4ZbuPJ47EcUa880iWLj', '2017-03-01 20:12:56', '2017-04-21 20:58:08', ''),
(31, 'chair', 'man', 'chair@man.com', '$2y$10$nqqPydQg7.9N/33vjLh6LuB5vDGEeCTOPlIfpPFu3W3GRQXlAmwCW', 1, 1, 0, 'Chairman', 'UfumJERWGR8p1VxkJwHzFpMvZz2n4P5cZXn9zl4kSaE8zZkU3dTFJL1WbXlK', '2017-03-26 00:48:30', '2017-04-21 21:09:19', '48058e0c99bf7d689ce71c360699a14ce2f99774'),
(32, 'ahmed', 'alanazi', 'aaala@lal.com', '$2y$10$4FZm4/4rpj.d7P6gDc5sp.1dEDAR127EA1CmXqM4FbEthPmMgArIO', 0, 0, 0, 'Coordinator', '400HoP80HN8B0TKHp2kyW6nV8BRsXdw9z3Am8LYN60iA5bujOI7xGu6Lmg2F', NULL, '2017-04-12 08:02:50', '48058e0c99bf7d689ce71c360699a14ce2f99774'),
(33, 'Mei-Huei', 'Tang', 'tang002@gannon.edu', '$2y$10$hXQpvNQxMwR/w2xca3IrEOim3fnQNwlkb/GU39iSdPHa9MDOvIgae', 1, 1, 0, 'Judge', 'SI8g2SplL2ATjpFGwWN3vfHDpNmmzubLZy15xX5sJjKRy3plLsaMlnf1qGiN', '2017-03-28 22:27:14', '2017-04-21 23:20:58', 'b6420c8e4f8bea98e3795c81a393b206f3bf2b52'),
(34, 'Matt', 'Heerboth', 'm@h.com', '$2y$10$y1NIib2aoXO2rnrPxlF/teu4cL43fLh1AcWoOjez3k6nDKgfUFTG2', 1, 1, 0, 'Coordinator', 'cx0ymqxxCGQdO5MCeoelBv84f8tcxr1JikNzSziqeQ7o4MYuCPPHhTL86T7N', '2017-03-29 16:38:33', '2017-04-06 15:13:22', '7c4a8d09ca3762af61e59520943dc26494f8941b'),
(36, 'Jessica', 'Hartnett', 'hartnett004@gannon.edu', '$2y$10$PEDSFigc59CufxEZWwnfGOA.A2imEjJEAX8uj4bGPJdpHPyW8EarO', 1, 1, 0, 'Judge', '7FuV3PASSDTaNE5VT1svvQGJ5Rv6dtxf2scuut7xZ8bkDCL493a2OaUL5lyY', '2017-03-29 17:27:36', '2017-04-20 17:41:27', '3834c8ea33a3bddbed3115836dc7da51c41cde7a'),
(37, 'Lisabeth', 'Searing', 'searing001@gannon.edu', '$2y$10$p1jXLl8w3c1JZ.41TVs83.2jpsYKvrIqCoqx14j6reCkkYh72iwoS', 1, 1, 0, 'Judge', 'Az9bgHYhg2JhhnsyGj8dDbTKTSMZ2tazW5eDnoSO5Qw2fM9JubH3hEwAIyoK', '2017-03-29 17:35:53', '2017-04-20 00:02:14', '911331c487ce43b0e6233b246cfea95ec203b9f6'),
(38, 'Anne', 'Schmitz', 'schmitz005@gannon.edu', '$2y$10$asOq68/IgkMIc7nwKTboY.gZWSdYL8C34Z0rM9XTy/tAq2pwWBYi6', 1, 1, 0, 'Judge', NULL, '2017-03-29 17:38:00', '2017-03-29 17:38:00', 'be2b71ae32eafa44f9381826eefbde0cf82472d0'),
(39, 'Debra', 'Stroiney', 'stroiney001@gannon.edu', '$2y$10$Olw7l1REg6hj0mNOU8NCJOV/14SCoywEBZ8UuV3KLl5mW805cdTd6', 1, 1, 0, 'Judge', NULL, '2017-03-29 23:48:53', '2017-03-29 23:48:53', '812ee46fa8af7c70ffd028f4cd23c38cddf10305'),
(40, 'Jennifer', 'Allen Catellier', 'allenca001@gannon.edu', '$2y$10$ZDWqL1qsR3emBr/yb1alfeXD0kdRXN5k1aWBngCTOQNu5oUKGsXOe', 1, 1, 0, 'Judge', '1KiE1ptdZ2gjEz8iu7y9t8Xi7nz3n6BOLLl1EWuoe7q4xuVo7TAi6CCnHmNO', '2017-03-30 23:34:44', '2017-04-12 21:45:36', '650d4b0388aad3646ba2048e07a47d6be0e93678'),
(42, 'omar', 'abufara', 'o.m.h.a.b@hotmail.com', '$2y$10$agJNCZwf9f7.8JxBD4dZ/OLhffY9mC.1KeTZ2U6SWa3mC1B.WOd6e', 1, 1, 0, 'Judge', 'xMyag3nOpUIsNNuuti6BEklBPr2ZCGo3cxOBNLkR5hH6MznANLmm3NPJDChN', '2017-04-07 17:35:54', '2017-04-16 01:48:46', 'e5caa1080607f77eeb7b3ca0f99710a2df1b16d9'),
(43, 'Alnasser', 'Al3alami', 'aalghanmi@hotmail.com', '$2y$10$wNkY58/YnIglmEDkg8GyxOCUIaAd3BhpXqXI4Fv7h1eLI9kfDdr9y', 1, 1, 0, 'Judge', 'aYLAmBjCSunnkMEgE2TQRdNUYJp4OsnBH9sCfw2LqGhu7jD5wS8DaPK7nuZU', '2017-04-07 19:58:22', '2017-04-11 00:39:54', 'afbdd6a420cafdd0c006cf7df1c7adfffc7e217c'),
(44, 'Ahmed', 'Alanazi', 'alanazi033@knights.gannon.com', '$2y$10$v8HGDO5oakoKK29M2xDd..O38am5.caoNDc/eNxEW6Rt4/D8lnOCm', 1, 1, 0, 'Judge', 'bIHpq57ZRablsr6p6hkrB3OnbRXKNdjn7f8Wg5p5tJ5aVEoubI4iFO1aLzwn', '2017-04-07 20:34:07', '2017-04-12 08:55:25', '5a43afa43f7747575b19c40d6ef760ca1dd4290c'),
(45, 'Wael', 'Jefry', 'jefry001@knights.gannon.edu', '$2y$10$poOum4BCCk.iVFCjSMcAs.PQSS.sjyOJZFppTDOI9YSoTNGse2IrO', 1, 1, 0, 'Judge', 'Cer4X3GsC3gsPDltlmCBDrbxm1AUyUYwzK4XTqul1zhPaSeGXRUdm6hMFI13', '2017-04-07 20:35:31', '2017-04-12 03:15:43', '0e1682e0baea2fdc5ae5450839a8f61971fac8a6'),
(46, 'Muhannad', 'Alhuwayshan', 'alhuways001@knights.gannon.edu', '$2y$10$972fGteTz8YK1JnO.r268eufA6hmoet1vyouzZ/FbO1.HrrF6i7Oq', 1, 1, 0, 'Judge', NULL, '2017-04-08 02:42:27', '2017-04-08 02:42:27', 'c3e32768a14f6c76bae413384fbe741903b6c349'),
(47, 'Waleed', 'Aldweesh', 'aldweesh001@knights.gannon.edu', '$2y$10$3tz6QqV3xk2H1TAQvkuGpOPeuqC4WenHTaefZ7P9ZGFHdLAN.ilI6', 1, 1, 0, 'Judge', 'wzjeZLvpBRifFnlWDZZwOHG0G97BTUIBPwTnlwGBhtopDhdOtKz1b0XH870Z', '2017-04-08 03:19:17', '2017-04-08 03:19:32', '55f3883809a622150755b0ef1ef2c5599b8ab9ab'),
(48, 'Ayman', 'Alotaibi', 'alotaibi024@knoghts.gannon.edu', '$2y$10$9s8g8xxtybCs0Tfuq4V7ve8wkyPTV9cZ18zwMTS6idSrWJ3xLvcWu', 1, 1, 0, 'Judge', 'dT0yc404Oq3qfrNnU13B60sUt377TqBAj2FTWRR9hNiS3Cvi8zov4Qa3Uhsl', '2017-04-08 03:21:54', '2017-04-12 09:03:11', '28dca2f0983493ef46131fadbbb6f53b7e85dc3b'),
(49, 'Ahmed ', 'Alhumaidi', 'alhumaid002@knights.gannon.edu', '$2y$10$5tbYOrBdbp.YgVd/8PL45.GRNgpEIy1cL1ReXhJ8XtAo9H9e.ILFC', 1, 1, 0, 'Judge', 'LrTc4U9M53FjJ4decu1G3MCBFQnsold7nMvq5mrTMHuKQM2dmmWFXuNwZeC1', '2017-04-08 04:08:18', '2017-04-11 01:27:43', '0fddbb82a95e3de97427e014945ae4d5015fbbc7'),
(50, 'HULAYYIL', 'ALSHAMMARI', 'hlf-2@hotmail.com', '$2y$10$8KCHjDubEJGn/ik6XB8xkOVNAHRQxNJDeeGfpPe/BN/2W1DSAOvvq', 1, 1, 0, 'Judge', 'fk0nnDoG5y9b7b42m8AiguGyDO7CR4LAuvHM9D4yJhiFzfZdYSy1NCJZbzYH', '2017-04-08 13:31:26', '2017-04-12 09:47:50', 'e98f2b104a9630c56df4e2b67434d4a6c909066b'),
(51, 'Amro', 'Huldar', 'huldar001@knights.gannon.edu', '$2y$10$j6PUR2DFDQtdlGgWZ4lcXeYhzRFdRN8RHXByNP1T3T/LwKhvNDUUe', 1, 1, 0, 'Judge', 'GX4IGT0VZPcxSgFTZV6WRThhwigOxeNhsezu2aX5kGheETN8GmlTHUEi6LiG', '2017-04-09 01:00:33', '2017-04-11 17:15:04', '6a86eb1983ccaf171aa17fb59156b57564872e5a'),
(52, 'Mashfi', 'Alshammari', 'alshamma008@knights.gannon.edu', '$2y$10$9NLMvKaHyhxEiK5wQBnNDutLBuIetcOZNDHYCma9aFA2btBhZAIa2', 1, 1, 0, 'Judge', 'R5IObFAPi9vqvKa6ETJb77nq4bsN75qKmIfY2T8RANCeOo4N7iNBhkmp8QLl', '2017-04-10 01:25:37', '2017-04-10 01:25:50', 'a5df7fcf26ae3c6463443e2091d26c0135e55048'),
(53, 'Jeffrey', 'Boss', 'boss001@gannon.edu', '$2y$10$ZY40EHSiAKLoOIzGHOnANOKpyf77wGAbREFgkKp0cs7LRqA5Ms/AO', 1, 1, 0, 'Judge', 'hIeiEU6JeRMBffysG4mMiHEDdHe8gRUhu4kjSDwySwFa9Q7AWo8UT3qp7cCa', '2017-04-12 19:04:54', '2017-04-21 23:50:36', '02674c79d3f6b4dd363a782e2c1780c856d1b144'),
(54, 'room', 'coordinator', 'room@cooridnator.com', '$2y$10$lCIWrHxi7QCpcLG/bpnpje5zs.gVheoBiAcUq9WFhDFQBm12fdg7u', 1, 1, 0, 'RoomCoordinator', 'hcMGLZIembF6QMVSJCczonDLUcnPiZrOMeTDJG6XEfceOEvO32FUFVHdCOiM', '2017-04-13 19:04:07', '2017-04-18 21:01:55', '48058e0c99bf7d689ce71c360699a14ce2f99774'),
(56, 'Narveen', 'Jandu', 'jandu001@gannon.edu', '$2y$10$Q9KgO5ELE0kOb8d7r04Hu.VtRZuxEDwdRYYAwtxlIOQoorBmZl1sS', 1, 1, 0, 'Judge', 'beggtKozbZLStNLwGskhq6mU6UoVbuImLB4t8H5MCXoDMhjehUHnoNd0Pr8k', '2017-04-19 18:05:44', '2017-04-19 18:06:40', 'a1bffc8419af21ef7bc54631f5602d942903c5cf'),
(57, 'Joshua', 'Nwokeji', 'Nwokeji001@gannon.edu', '$2y$10$d2JxroiSwVh.0pzacepEpei5fV3JnukHnqr4ftRHMLgp/Wi817sd6', 1, 1, 0, 'Judge', 'DYDn0OEmO1dp1zhUi6sUpsPe47LcBxVAn3ZC4uzykrlAoviILP1EeDGJ1d0o', '2017-04-19 21:35:28', '2017-04-21 23:10:21', 'ea788620641a30585552d2d1f967b40a0031bce5'),
(67, 'Lin', 'Zhao', 'zhao001@gannon.edu', '$2y$10$b.4zMHyjnnf4QpUTkcCdwez8d5M8xfQ155/Sdc4wnwt8SjZf9qoHi', 1, 1, 0, 'Judge', NULL, '2017-04-20 21:22:41', '2017-04-20 21:22:41', '774fb974495c2a6ba7d9c0b93834919bf62f37a1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approvedproposals`
--
ALTER TABLE `approvedproposals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `approvedproposals_student_id_foreign` (`student_id`),
  ADD KEY `approvedproposals_category_id_foreign` (`category_id`),
  ADD KEY `approvedproposals_department_id_foreign` (`department_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_name_unique` (`name`);

--
-- Indexes for table `category_coordinator`
--
ALTER TABLE `category_coordinator`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_coordinator_category_id_foreign` (`category_id`),
  ADD KEY `category_coordinator_coordinator_id_foreign` (`coordinator_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eventtimes`
--
ALTER TABLE `eventtimes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eventtimes_user_id_foreign` (`user_id`);

--
-- Indexes for table `eventtime_judge`
--
ALTER TABLE `eventtime_judge`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eventtime_judge_eventtime_id_foreign` (`eventtime_id`),
  ADD KEY `eventtime_judge_judge_id_foreign` (`judge_id`);

--
-- Indexes for table `finalgrades`
--
ALTER TABLE `finalgrades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `finalgrades_category_id_foreign` (`category_id`),
  ADD KEY `finalgrades_department_id_foreign` (`department_id`),
  ADD KEY `finalgrades_student_id_foreign` (`student_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `platformSchedule`
--
ALTER TABLE `platformSchedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `platformschedule_approvedproposals_id_foreign` (`approvedproposals_id`),
  ADD KEY `platformschedule_eventtimes_id_foreign` (`eventtimes_id`),
  ADD KEY `platformschedule_judge_one_foreign` (`judge_one`),
  ADD KEY `platformschedule_judge_two_foreign` (`judge_two`),
  ADD KEY `platformschedule_judge_three_foreign` (`judge_three`);

--
-- Indexes for table `platformscoresheets`
--
ALTER TABLE `platformscoresheets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `platformscoresheets_student_id_foreign` (`student_id`),
  ADD KEY `platformscoresheets_judge_id_foreign` (`judge_id`);

--
-- Indexes for table `posterSchedule`
--
ALTER TABLE `posterSchedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posterschedule_approvedproposals_id_foreign` (`approvedproposals_id`),
  ADD KEY `posterschedule_eventtimes_id_foreign` (`eventtimes_id`),
  ADD KEY `posterschedule_judge_one_foreign` (`judge_one`),
  ADD KEY `posterschedule_judge_two_foreign` (`judge_two`),
  ADD KEY `posterschedule_judge_three_foreign` (`judge_three`);

--
-- Indexes for table `posterscoresheets`
--
ALTER TABLE `posterscoresheets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posterscoresheets_student_id_foreign` (`student_id`),
  ADD KEY `posterscoresheets_judge_id_foreign` (`judge_id`);

--
-- Indexes for table `proposals`
--
ALTER TABLE `proposals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proposals_student_id_foreign` (`student_id`),
  ADD KEY `proposals_category_id_foreign` (`category_id`),
  ADD KEY `proposals_department_id_foreign` (`department_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `students_universityid_unique` (`universityId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_category_id_foreign` (`category_id`),
  ADD KEY `users_department_id_foreign` (`department_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approvedproposals`
--
ALTER TABLE `approvedproposals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `category_coordinator`
--
ALTER TABLE `category_coordinator`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `eventtimes`
--
ALTER TABLE `eventtimes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `eventtime_judge`
--
ALTER TABLE `eventtime_judge`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `finalgrades`
--
ALTER TABLE `finalgrades`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `platformSchedule`
--
ALTER TABLE `platformSchedule`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `platformscoresheets`
--
ALTER TABLE `platformscoresheets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=319;
--
-- AUTO_INCREMENT for table `posterSchedule`
--
ALTER TABLE `posterSchedule`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `posterscoresheets`
--
ALTER TABLE `posterscoresheets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=838;
--
-- AUTO_INCREMENT for table `proposals`
--
ALTER TABLE `proposals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;
--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=274;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `approvedproposals`
--
ALTER TABLE `approvedproposals`
  ADD CONSTRAINT `approvedproposals_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `approvedproposals_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `approvedproposals_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `category_coordinator`
--
ALTER TABLE `category_coordinator`
  ADD CONSTRAINT `category_coordinator_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `category_coordinator_coordinator_id_foreign` FOREIGN KEY (`coordinator_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `eventtimes`
--
ALTER TABLE `eventtimes`
  ADD CONSTRAINT `eventtimes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `eventtime_judge`
--
ALTER TABLE `eventtime_judge`
  ADD CONSTRAINT `eventtime_judge_eventtime_id_foreign` FOREIGN KEY (`eventtime_id`) REFERENCES `eventtimes` (`id`),
  ADD CONSTRAINT `eventtime_judge_judge_id_foreign` FOREIGN KEY (`judge_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `finalgrades`
--
ALTER TABLE `finalgrades`
  ADD CONSTRAINT `finalgrades_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `finalgrades_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `finalgrades_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `platformSchedule`
--
ALTER TABLE `platformSchedule`
  ADD CONSTRAINT `platformschedule_approvedproposals_id_foreign` FOREIGN KEY (`approvedproposals_id`) REFERENCES `approvedproposals` (`id`),
  ADD CONSTRAINT `platformschedule_eventtimes_id_foreign` FOREIGN KEY (`eventtimes_id`) REFERENCES `eventtimes` (`id`);

--
-- Constraints for table `platformscoresheets`
--
ALTER TABLE `platformscoresheets`
  ADD CONSTRAINT `platformscoresheets_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `posterSchedule`
--
ALTER TABLE `posterSchedule`
  ADD CONSTRAINT `posterschedule_approvedproposals_id_foreign` FOREIGN KEY (`approvedproposals_id`) REFERENCES `approvedproposals` (`id`),
  ADD CONSTRAINT `posterschedule_eventtimes_id_foreign` FOREIGN KEY (`eventtimes_id`) REFERENCES `eventtimes` (`id`);

--
-- Constraints for table `posterscoresheets`
--
ALTER TABLE `posterscoresheets`
  ADD CONSTRAINT `posterscoresheets_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `proposals`
--
ALTER TABLE `proposals`
  ADD CONSTRAINT `proposals_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `proposals_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  ADD CONSTRAINT `proposals_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
